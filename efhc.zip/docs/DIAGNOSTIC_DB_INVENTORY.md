# DIAGNOSTIC: Инвентаризация схем/таблиц/маршрутов (SSOT = текущий efhc.zip)

Дата: 2026-02-28 (UTC)

> Статус документа: **диагностика / ревизия**, не канон.

## 1) Схемы БД (как сейчас в коде)

- Ядро (конфиг): `DB_SCHEMA_CORE = "UNKNOWN"` (файл `backend/app/core/config_core.py`)
- Поля `DB_SCHEMA_ADMIN` в конфиге: **НЕТ**
- В миграции 0001 создаются схемы: efhc_admin, efhc_core

Файлы, где встречаются `DB_SCHEMA_ADMIN`/`SCHEMA_ADMIN` (факт, по коду):
- backend/app/routes/deposit_routes.py
- backend/app/services/admin/admin_bank_service.py
- backend/app/services/admin/admin_logging.py
- backend/app/services/admin/admin_lotteries_service.py
- backend/app/services/admin/admin_notifications.py
- backend/app/services/admin/admin_rbac.py
- backend/app/services/admin/admin_sale_packages_service.py
- backend/app/services/admin/admin_settings.py
- backend/app/services/admin/admin_stats_service.py
- backend/app/services/admin/admin_withdrawals_service.py

**Вывод:** `efhc_core` закреплена ядром, а `efhc_admin` сейчас не канонизирована в конфиге и может жить через fallback/строки.

## 2) Таблицы, которые требует код через ORM (уникальные `__tablename__`)

Всего уникальных таблиц по моделям: **30**.

### 2.1. Список 30 (имя → где объявлена/класс)

- **achievements** — Achievement (achievements_models.py)
- **admin_action_log** — AdminActionLog (admin_models.py)
- **admin_bank_config** — AdminBankConfig (bank_models.py)
- **admin_role** — AdminRole (admin_models.py)
- **admin_whitelist** — AdminWhitelist (admin_models.py)
- **ads** — Ad (ads_models.py)
- **app_settings** — AppSetting (settings_models.py)
- **bank_state** — BankState (bank_models.py)
- **efhc_transfers_log** — EfhcTransferLog (transactions_models.py)
- **idempotency_key** — IdempotencyKey (admin_models.py)
- **lotteries** — Lotteries (lotteries_models.py)
- **lotteries_nft_claims** — LotteriesNFTClaim (lotteries_models.py)
- **lotteries_results** — LotteriesResult (lotteries_models.py)
- **lotteries_tickets** — LotteriesTicket (lotteries_models.py)
- **lotteries_user_stats** — LotteriesUserStat (lotteries_models.py)
- **panels** — Panel (panels_models.py)
- **ranks_snapshots** — RanksSnapshot (ranks_models.py)
- **ranks_top_cache** — RanksTopCache (ranks_models.py)
- **referral_links** — ReferralLink (referral_models.py)
- **shop_items** — ShopItem (shop_models.py)
- **shop_orders** — ShopOrder (order_models.py), ShopOrder (shop_models.py)
- **task_submissions** — TaskSubmission (tasks_models.py)
- **tasks** — Task (tasks_models.py)
- **ton_inbox_logs** — TonInboxLog (ton_logs_models.py)
- **user_cosmetics** — UserCosmetics (skins_models.py)
- **user_skins** — UserSkin (skins_models.py)
- **users** — User (user_models.py)
- **wallet_bindings** — WalletBinding (wallets_models.py)
- **withdraw_requests** — WithdrawRequest (withdraw_models.py)
- **withdrawals** — Withdrawal (withdraw_models.py)

### 2.2. Дубликаты ORM-дефиниций (логистический дефект)

- **shop_orders** объявлена в: backend/app/models/order_models.py (class ShopOrder), backend/app/models/shop_models.py (class ShopOrder)

## 3) Что создаёт миграция 0001 (факт из `backend/migrations/versions/0001_init.py`)

- Схемы, которые создаёт 0001: efhc_admin, efhc_core
- Таблиц, которые вызывает `ensure_table_with_basics(...)`: **30**

Список (таблица → schema):
- **users** → IMPLICIT(search_path)
- **wallet_bindings** → IMPLICIT(search_path)
- **withdraw_requests** → IMPLICIT(search_path)
- **withdrawals** → IMPLICIT(search_path)
- **panels** → IMPLICIT(search_path)
- **achievements** → IMPLICIT(search_path)
- **efhc_transfers_log** → IMPLICIT(search_path)
- **ton_inbox_logs** → IMPLICIT(search_path)
- **shop_items** → IMPLICIT(search_path)
- **shop_orders** → IMPLICIT(search_path)
- **ads** → IMPLICIT(search_path)
- **tasks** → IMPLICIT(search_path)
- **task_submissions** → IMPLICIT(search_path)
- **app_settings** → IMPLICIT(search_path)
- **bank_state** → IMPLICIT(search_path)
- **idempotency_key** → IMPLICIT(search_path)
- **referral_links** → IMPLICIT(search_path)
- **ranks_snapshots** → IMPLICIT(search_path)
- **ranks_top_cache** → IMPLICIT(search_path)
- **user_skins** → IMPLICIT(search_path)
- **user_cosmetics** → IMPLICIT(search_path)
- **lotteries** → IMPLICIT(search_path)
- **lotteries_tickets** → IMPLICIT(search_path)
- **lotteries_results** → IMPLICIT(search_path)
- **lotteries_user_stats** → IMPLICIT(search_path)
- **lotteries_nft_claims** → IMPLICIT(search_path)
- **admin_action_log** → IMPLICIT(search_path)
- **admin_bank_config** → IMPLICIT(search_path)
- **admin_role** → IMPLICIT(search_path)
- **admin_whitelist** → IMPLICIT(search_path)

### 3.1. Дифф: модели (30) vs 0001

- Модельные таблицы, которых **нет** в 0001 (кол-во 0):
- (нет)

- Таблицы, которые **есть** в 0001, но **нет** среди моделей (кол-во 0):
- (нет)

## 4) Что проверяют sanity-проверки (то, что валит сборку)

### 4.1. `backend/migrations/env.py` (после alembic)

Проверяет `to_regclass()` для (уникальных): **0**
- (не найдено)

### 4.2. `backend/migrations/versions/0001_init.py` (в конце upgrade())

Проверяет `to_regclass()` для (по списку `required = [...]`): **30**
- efhc_core.users
- efhc_core.wallet_bindings
- efhc_core.withdraw_requests
- efhc_core.withdrawals
- efhc_core.panels
- efhc_core.achievements
- efhc_core.efhc_transfers_log
- efhc_core.ton_inbox_logs
- efhc_core.shop_orders
- efhc_core.shop_items
- efhc_core.ads
- efhc_core.tasks
- efhc_core.task_submissions
- efhc_core.app_settings
- efhc_core.bank_state
- efhc_core.idempotency_key
- efhc_core.referral_links
- efhc_core.ranks_snapshots
- efhc_core.ranks_top_cache
- efhc_core.user_skins
- efhc_core.user_cosmetics
- efhc_core.lotteries
- efhc_core.lotteries_tickets
- efhc_core.lotteries_results
- efhc_core.lotteries_user_stats
- efhc_core.lotteries_nft_claims
- efhc_admin.admin_action_log
- efhc_admin.admin_bank_config
- efhc_admin.admin_role
- efhc_admin.admin_whitelist

## 5) Schema-qualified имена таблиц, которые реально встречаются в коде (`efhc_core.*` / `efhc_admin.*`)

Всего уникальных schema-qualified имён найдено: **35**.

### 5.1. Полный список (имя → где встречается)

- **efhc_admin.admin_action_log** — backend/migrations/env.py:186; backend/migrations/versions/0001_init.py:435
- **efhc_admin.admin_bank_config** — backend/migrations/env.py:187; backend/migrations/versions/0001_init.py:435
- **efhc_admin.admin_role** — backend/migrations/env.py:188; backend/migrations/versions/0001_init.py:435
- **efhc_admin.admin_whitelist** — backend/migrations/env.py:189; backend/migrations/versions/0001_init.py:435
- **efhc_admin.bank_balances** — backend/app/routes/admin_routes.py:231
- **efhc_admin.efhc_sale_packages** — backend/app/services/payment_intents_service.py:208
- **efhc_core.achievements** — backend/migrations/env.py:165; backend/migrations/versions/0001_init.py:433
- **efhc_core.admin_nft_whitelist** — backend/app/deps.py:468; backend/app/deps.py:513
- **efhc_core.ads** — backend/migrations/env.py:170; backend/migrations/versions/0001_init.py:433
- **efhc_core.app_settings** — backend/migrations/env.py:173; backend/migrations/versions/0001_init.py:433
- **efhc_core.bank_state** — backend/migrations/env.py:174; backend/migrations/versions/0001_init.py:433
- **efhc_core.efhc_transfers_log** — backend/app/routes/admin_routes.py:375; backend/app/routes/admin_routes.py:382; backend/migrations/env.py:166; backend/migrations/versions/0001_init.py:433
- **efhc_core.idempotency_key** — backend/migrations/env.py:175; backend/migrations/versions/0001_init.py:433
- **efhc_core.lotteries** — backend/migrations/env.py:181; backend/migrations/versions/0001_init.py:433
- **efhc_core.lotteries_nft_claims** — backend/migrations/env.py:185; backend/migrations/versions/0001_init.py:433
- **efhc_core.lotteries_results** — backend/migrations/env.py:183; backend/migrations/versions/0001_init.py:433
- **efhc_core.lotteries_tickets** — backend/migrations/env.py:182; backend/migrations/versions/0001_init.py:433
- **efhc_core.lotteries_user_stats** — backend/migrations/env.py:184; backend/migrations/versions/0001_init.py:433
- **efhc_core.panels** — backend/migrations/env.py:164; backend/migrations/versions/0001_init.py:433
- **efhc_core.processed_external_events** — backend/app/deps.py:245; backend/app/deps.py:294
- **efhc_core.ranks_snapshots** — backend/migrations/env.py:177; backend/migrations/versions/0001_init.py:433
- **efhc_core.ranks_top_cache** — backend/migrations/env.py:178; backend/migrations/versions/0001_init.py:433
- **efhc_core.referral_links** — backend/migrations/env.py:176; backend/migrations/versions/0001_init.py:433
- **efhc_core.scheduler_task_log** — backend/app/scheduler/check_ton_inbox.py:117
- **efhc_core.shop_items** — backend/migrations/env.py:169; backend/migrations/versions/0001_init.py:433
- **efhc_core.shop_orders** — backend/migrations/env.py:168; backend/migrations/versions/0001_init.py:433
- **efhc_core.task_submissions** — backend/migrations/env.py:172; backend/migrations/versions/0001_init.py:433
- **efhc_core.tasks** — backend/migrations/env.py:171; backend/migrations/versions/0001_init.py:433
- **efhc_core.ton_inbox_logs** — backend/app/routes/admin_routes.py:357; backend/app/routes/admin_routes.py:366; backend/migrations/env.py:167; backend/migrations/versions/0001_init.py:433
- **efhc_core.user_cosmetics** — backend/migrations/env.py:180; backend/migrations/versions/0001_init.py:433
- **efhc_core.user_skins** — backend/migrations/env.py:179; backend/migrations/versions/0001_init.py:433
- **efhc_core.users** — backend/app/models/tasks_models.py:260; backend/app/routes/admin_routes.py:200; backend/app/routes/admin_routes.py:390; backend/migrations/env.py:160; backend/migrations/versions/0001_init.py:433
- **efhc_core.wallet_bindings** — backend/migrations/env.py:161; backend/migrations/versions/0001_init.py:433
- **efhc_core.withdraw_requests** — backend/migrations/env.py:162; backend/migrations/versions/0001_init.py:433
- **efhc_core.withdrawals** — backend/migrations/env.py:163; backend/migrations/versions/0001_init.py:433

### 5.2. Вне ORM-списка 30 (по совпадению имени таблицы без схемы)

Вне списка 30 (`schema.table`, где `table` отсутствует среди ORM `__tablename__`): **5**
- efhc_admin.bank_balances
- efhc_admin.efhc_sale_packages
- efhc_core.admin_nft_whitelist
- efhc_core.processed_external_events
- efhc_core.scheduler_task_log

Классификация:
- Только комментарии/докстринги (не требует таблиц реально): efhc_core.admin_nft_whitelist, efhc_core.processed_external_events
- Реально встречается вне deps/doc: efhc_admin.bank_balances, efhc_admin.efhc_sale_packages, efhc_core.scheduler_task_log

## 6) Маршруты API (FastAPI) — полный реестр

Всего маршрутов: **87**.

- GET    /admin/ads/providers  (admin_ads_routes.py)
- GET    /admin/bank/balance  (admin_routes.py)
- POST   /admin/bank/burn  (admin_routes.py)
- POST   /admin/bank/mint  (admin_routes.py)
- GET    /admin/logs/transfers  (admin_logs_routes.py)
- GET    /admin/lotteries/history  (admin_routes.py)
- GET    /admin/lotteries/nft-claims  (admin_routes.py)
- POST   /admin/lotteries/nft-claims/{claim_id}/mark-sent  (admin_routes.py)
- POST   /admin/lotteries/{lotteries_id}/auto-lotteries  (admin_routes.py)
- PATCH  /admin/panels/{panel_id}/activate  (admin_panels_routes.py)
- PATCH  /admin/panels/{panel_id}/deactivate  (admin_panels_routes.py)
- GET    /admin/reports/overview  (admin_routes.py)
- POST   /admin/sale-packages/{package_id}/toggle  (admin_sale_packages_routes.py)
- POST   /admin/shop/items/set-price  (admin_shop_routes.py)
- GET    /admin/shop/orders  (admin_shop_routes.py)
- POST   /admin/ton/reconcile  (admin_routes.py)
- POST   /admin/transfer  (admin_routes.py)
- GET    /admin/users/search  (admin_users_routes.py)
- GET    /admin/users/{tg_id}  (admin_users_routes.py)
- PATCH  /admin/users/{tg_id}/active  (admin_users_routes.py)
- PATCH  /admin/users/{tg_id}/vip  (admin_users_routes.py)
- POST   /admin/users/{tg_id}/wallet/reset  (admin_users_routes.py)
- POST   /admin/withdrawals/{request_id}/approve  (admin_withdrawals_routes.py)
- POST   /admin/withdrawals/{request_id}/reject  (admin_withdrawals_routes.py)
- POST   /ads/callback/{provider}  (ads_routes.py)
- GET    /ads/slot  (ads_routes.py)
- POST   /api/admin/referrals/manual-bonus  (admin_referral_routes.py)
- POST   /api/admin/referrals/reassign  (admin_referral_routes.py)
- GET    /api/admin/referrals/summary  (admin_referral_routes.py)
- POST   /api/admin/submissions/{submission_id}/moderate  (admin_tasks_routes.py)
- GET    /api/admin/tasks  (admin_tasks_routes.py)
- POST   /api/admin/tasks  (admin_tasks_routes.py)
- DELETE /api/admin/tasks/{task_id}  (admin_tasks_routes.py)
- GET    /api/admin/tasks/{task_id}  (admin_tasks_routes.py)
- PATCH  /api/admin/tasks/{task_id}  (admin_tasks_routes.py)
- GET    /api/admin/tasks/{task_id}/subs  (admin_tasks_routes.py)
- GET    /api/lotteries  (lotteries_routes.py)
- GET    /api/lotteries/history  (lotteries_routes.py)
- GET    /api/lotteries/{lotteries_id}  (lotteries_routes.py)
- POST   /api/lotteries/{lotteries_id}/buy  (lotteries_routes.py)
- GET    /api/lotteries/{lotteries_id}/my-tickets  (lotteries_routes.py)
- GET    /api/v1/me  (me_routes.py)
- GET    /cron/tick  (system_routes.py)
- POST   /deposit/efhc  (deposit_routes.py)
- GET    /deposit/packages  (deposit_routes.py)
- POST   /exchange/convert/{tg_id}  (exchange_routes.py)
- GET    /exchange/history/{tg_id}  (exchange_routes.py)
- GET    /exchange/preview/{tg_id}  (exchange_routes.py)
- GET    /health  (system_routes.py)
- GET    /health/db  (system_routes.py)
- GET    /health/db-schema  (system_routes.py)
- GET    /nft/has_vip  (nft_routes.py)
- POST   /panels/buy/{tg_id}  (panels_routes.py)
- GET    /panels/{tg_id}/active  (panels_routes.py)
- GET    /panels/{tg_id}/archive  (panels_routes.py)
- GET    /panels/{tg_id}/summary  (panels_routes.py)
- GET    /payment-intents/{intent_id}  (payment_intents_routes.py)
- GET    /ranks/my-plus-top  (ranks_routes.py)
- GET    /ranks/top  (ranks_routes.py)
- GET    /referrals/active  (referrals_routes.py)
- GET    /referrals/counters  (referrals_routes.py)
- GET    /referrals/inactive  (referrals_routes.py)
- GET    /shop/catalog  (shop_routes.py)
- POST   /shop/order-external  (shop_routes.py)
- GET    /shop/orders  (shop_routes.py)
- POST   /shop/purchase-efhc  (shop_routes.py)
- POST   /skins/activate/{skin_id}  (skins_routes.py)
- POST   /skins/buy/{skin_id}  (skins_routes.py)
- GET    /skins/catalog  (skins_routes.py)
- GET    /skins/my  (skins_routes.py)
- POST   /sync/user/{tg_id}  (sync_routes.py)
- GET    /tasks/catalog  (tasks_routes.py)
- POST   /tasks/claim/{tg_id}  (tasks_routes.py)
- GET    /tasks/my/{tg_id}  (tasks_routes.py)
- POST   /tg/webhook  (system_routes.py)
- GET    /user/me  (user_routes.py)
- GET    /user/{tg_id}/exchange/preview  (user_routes.py)
- GET    /user/{tg_id}/me  (user_routes.py)
- GET    /user/{tg_id}/panels-summary  (user_routes.py)
- POST   /wallets/connect  (wallets_routes.py)
- GET    /wallets/me  (wallets_routes.py)
- DELETE /wallets/{wallet_id}  (wallets_routes.py)
- POST   /wallets/{wallet_id}/make-primary  (wallets_routes.py)
- GET    /withdraw/list  (withdraw_routes.py)
- POST   /withdraw/request  (withdraw_routes.py)
- GET    /withdraw/{request_id}  (withdraw_routes.py)
- POST   /withdraw/{request_id}/cancel  (withdraw_routes.py)

## 7) Ключевые наблюдения (без лечения)

1) В моделях **30 уникальных таблиц**, но есть дубль `shop_orders` (двойное ORM-объявление) — это нужно устранять отдельно.
2) 0001 сейчас вызывает создание **30 таблиц**, но sanity в конце 0001 проверяет **30** fq-имён; при этом большинство `ensure_table_with_basics` вызывается без `schema=...` → таблицы создаются по `search_path`.
3) В коде найдено **35** schema-qualified ссылок; часть из них не соответствует ORM-списку 30 (см. раздел 5.2).

