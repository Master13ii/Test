Audit-Id: AUD-2026-02-28-DB-INVENTORY-003
Date: 2026-02-28
Version: EFHC_Bot_v149_16_add_registry_audits
Topic: db-inventory
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация ORM-моделей (schema.table, класс, file:line).
Sources: PDF: _raw/2026-02-28_db-inventory_v149_16__orm_inv.pdf
Owner: Мастер
Confidence: HIGH

## Executive Summary
Реестр ORM-моделей: schema.table, класс и file:line.

## Findings (FACTS)
- Всего моделей: 31 (по PDF). [[EV-001]]
- Уникальных schema.table: 31 (по PDF). [[EV-001]]
- schema=None для всех записей (по PDF). [[EV-001]]

## Evidence Index
EV-001 | DOC | see files.raw | - | see Appendix | PDF

## Decisions (SSOT)
- PDF-реестр считать первичным источником фактов по ORM. [[EV-001]]
- Расхождения ORM↔0001 фиксировать отдельным audit topic db-ssot.
- [[EV-001]]

## Actions (P0/P1/P2)
### P0
- Проверить и устранить физические дубли ORM (если есть). [[EV-001]]

### P1
- Сверить ORM-реестр с 0001_init.py по именам таблиц. [[EV-001]]

### P2
- Автоматизировать генерацию ORM-реестра в CI. [[EV-001]]

## Impact & Risks
- Реестр нужен для воспроизводимости аудита и привязки фактов к
доказательствам. [[EV-001]]

## Verification
- Сверить указанные file:line/сводные показатели с PDF и репозиторием.
  [[EV-001]]

## Appendix: Raw Extract (optional)
```text
Counts:
-
Всего
моделей:
31
-
Уникальных
schema.table:
31
-
```
