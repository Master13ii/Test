# Аудит кода 1

Source: Аудит кода 1.pdf
Scope: Код EFHC Bot (backend/frontend) и базовые риски
Date: unknown
Status: SUPERSEDED
Superseded by: Аудит кода 2.md

## Findings (FACTS)

- Усиление `ops/canon_guard.py` (SSOT/запреты/пакетность/проверки перед
  сборкой).
- Миграции Alembic: корректный `alembic.ini`, deterministic-check
  существования таблиц/схем, порядок шагов CI.
- Pytest/pytest-asyncio: корректная конфигурация `pytest.ini`, фикстуры
  уровня session, стабильность CI.
- Схемы БД (DB_SCHEMA/search_path/multi-schema) и риски
  рассинхронизации.
- Канон идентификатора пользователя `tg_id` (единый идентификатор).

## Actions (DECISIONS)

- P0: Привести 0001 и Alembic-конфиг к детерминированной схеме: schema
  на уровне таблиц, проверки to_regclass.
- P1: Стабилизировать pytest/pytest-asyncio: фикстуры уровня session,
  Postgres-only, без pip -U.
- P0: Зафиксировать tg_id как единственный идентификатор во всех слоях
  (routes/services/models/docs).
- P0: Централизовать имена схем в Settings (DB_SCHEMA_CORE,
  DB_SCHEMA_ADMIN) и запретить хардкоды.

## Appendix: Raw Extract (optional)

- > Ниже — короткие фрагменты из извлечённого текста PDF вокруг ключевых
  терминов (могут содержать артефакты PDF-экстракции).
- - arded_allow_ips` задан как `" * "` вместо `"*"`, что может ломать
  корректное определение реального IP/ протокола за прокси.  - **CI
  падает** из ‑ за: - строгого лимита 72 символа на строку (5 строк ‑
  нарушителей), - `ops/canon_guard.py` не принимает н...
- - ate.tg_id` (initData) и/или отдельный ключ | | C1 | **Критично** |
  `tests/test_no_placeholders.py` | `rglob(" * ")` вместо `rglob("*")` |
  Тест “пропускает” TODO/FIXME/PLACEHOLDER в shipping ‑ коде | Исправить
  glob на `"*"` | | D1 | **Высоко** | `ops/canon_guard.py`,
  `ops/canon_ru...
- - задачах использовать **отдельные** `AsyncSession` | | F2 |
  **Высоко** | `tests/conftest.py`, CI | Таблицы/схемы “не существуют” в
  ряде тестов | Нестабильность: тесты завязаны на внешний шаг миграций |
  Добавить session ‑ fixture, которая гарантирует `alembic upgrade head`
  перед DB...
- - ync_sqlalchemy_url(url) + + +@pytest.fixture(scope="session") +def
  db_migrated() -> None: + repo = Path(__file__).resolve().parents[1] +
  backend_dir = repo / "backend" + # Alembic использует
  SYNC_DATABASE_URL (sync driver). + p = subprocess.run( + ["alembic",
  "-c", "alembic.ini",...
- - око** | `tests/conftest.py`, CI | Таблицы/схемы “не существуют” в
  ряде тестов | Нестабильность: тесты завязаны на внешний шаг миграций |
  Добавить session ‑ fixture, которая гарантирует `alembic upgrade head`
  перед DB ‑ тестами | | G1 | **Средне** | `pytest.ini`,
  `pyproject.toml` ...
- - : тесты завязаны на внешний шаг миграций | Добавить session ‑
  fixture, которая гарантирует `alembic upgrade head` перед DB ‑ тестами
  | | G1 | **Средне** | `pytest.ini`, `pyproject.toml` | Маркеры
  `smoke/unit` объявлены в `pyproject`, но применяется `pytest.ini` →
  warnings | Шум/с...
- - grade", "head"], + cwd=str(backend_dir), + capture_output=True, +
  text=True, + ) + if p.returncode != 0: + msg = "alembic upgrade head
  failed:\n" + (p.stdout or p.stderr) + raise RuntimeError(msg) @@
  @pytest.fixture -async def db_clean(async_engine, schema_core: str,
  schema_admin...
- - cwd=str(backend_dir), + capture_output=True, + text=True, + ) + if
  p.returncode != 0: + msg = "alembic upgrade head failed:\n" +
  (p.stdout or p.stderr) + raise RuntimeError(msg) @@ @pytest.fixture
  -async def db_clean(async_engine, schema_core: str, schema_admin: str)
  -> AsyncIter...
- ## Рекомендации (обобщённо)
