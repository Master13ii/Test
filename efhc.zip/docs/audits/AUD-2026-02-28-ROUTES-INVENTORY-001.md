Audit-Id: AUD-2026-02-28-ROUTES-INVENTORY-001
Date: 2026-02-28
Version: EFHC_Bot_v149_14
Topic: routes-inventory
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация/аудит по теме; фиксация фактов и решений.
Sources:
  - DOC: docs/audits/_raw/AUD-2026-02-28-ROUTES-INVENTORY-001.raw.md
Owner: Мастер
Confidence: MEDIUM

## Executive Summary

Свод: обнаружено 87 маршрутов; сгруппированы admin/user/cron.

## Findings (FACTS)

- Обнаружено 87 маршрутов backend (admin/user/cron) [[EV-001]].

## Evidence Index

EV-001 | CODE | backend/app/routes/** | - | Сканирование маршрутов
FastAPI даёт 87 endpoint'ов. | В проекте 87 маршрутов.

## Decisions (SSOT)

- Список маршрутов фиксируется в аудитах; новые маршруты обязаны иметь
  явную привязку к таблицам/сервисам [[EV-001]].

## Actions (P0/P1/P2)

- P0: добавить mapping routes→services→tables в отдельный аудит при
  следующем рефакторинге [[EV-001]].

## Impact & Risks

- Риск: без mapping сложно доказательно менять БД/таблицы.

## Verification

- Проверить: генерация списка маршрутов должна быть воспроизводима
  скриптом аудита [[EV-001]].

## Appendix: Raw Extract (optional)

See: /tmp/efhc_v149_14_1jfqo2i_/docs/audits/_raw/AUD-2026-02-28-ROUTES-
INVENTORY-001.raw.md
