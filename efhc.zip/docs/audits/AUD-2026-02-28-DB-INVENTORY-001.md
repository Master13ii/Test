Audit-Id: AUD-2026-02-28-DB-INVENTORY-001
Date: 2026-02-28
Version: EFHC_Bot_v149_14
Topic: db-inventory
Status: SUPERSEDED
Superseded-By: AUD-2026-02-28-DB-INVENTORY-002
Scope: Инвентаризация/аудит по теме; фиксация фактов и решений.
Sources:
  - DOC: docs/audits/_raw/AUD-2026-02-28-DB-INVENTORY-001.raw.md
Owner: Мастер
Confidence: MEDIUM

## Executive Summary

Свод: ORM 30 имён, 0001 создаёт 20, sanity 2/8, routes 87.

## Findings (FACTS)

- ORM определяет 30 уникальных таблиц [[EV-001]].
- 0001 создаёт 2 схемы и 20 таблиц (часть имён вне ORM) [[EV-002]].
- Sanity в CI проверяет core/admin таблицы через to_regclass [[EV-003]].

## Evidence Index

EV-001 | CODE | backend/app/models/** | - | В моделях обнаружено 30
уникальных __tablename__. | Код ожидает минимум 30 таблиц.
EV-002 | MIGRATION | backend/migrations/versions/0001_init.py | - | В
0001 создаются efhc_core и efhc_admin и 20 таблиц. | Миграция не
покрывает все модельные таблицы.
EV-003 | CI | logs_58886229272.zip | - | Sanity после alembic: missing
efhc_core.users/.../efhc_admin.efhc_sale_packages. | CI фиксирует
отсутствие таблиц в ожидаемых схемах.

## Decisions (SSOT)

- До фиксации канона имён запрещено вводить новые таблицы без
  обоснования и evidence [[EV-001]].
- Выравнивание: один словарь имён (модели ↔ миграции ↔ raw SQL) должен
  стать SSOT [[EV-001]] [[EV-002]].

## Actions (P0/P1/P2)

- P0: составить diff (ORM vs 0001 vs raw SQL) и выбрать канон имен
  таблиц [[EV-001]] [[EV-002]].
- P1: привести 0001 к канону (без 0002+) и обновить sanity список таблиц
  [[EV-002]] [[EV-003]].

## Impact & Risks

- Риск: пока рассинхрон не закрыт, CI будет ловить разные стоп-краны
  (schema/table missing) [[EV-003]].

## Verification

- Проверить: alembic upgrade head + sanity to_regclass на обязательные
  таблицы [[EV-002]] [[EV-003]].

## Appendix: Raw Extract (optional)

See: /tmp/efhc_v149_14_1jfqo2i_/docs/audits/_raw/AUD-2026-02-28-DB-
INVENTORY-001.raw.md
