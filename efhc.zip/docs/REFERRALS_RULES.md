# Referrals Rules

Реферальный бонус выплачивается только из банка EFHC.
События фиксируются в efhc_transfers_log с типом операции
`referral_bonus`.
