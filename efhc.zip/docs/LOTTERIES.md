# Lotteries SSOT

Этот документ — каноническая спецификация подсистемы **Lotteries**
в EFHC Bot.

## 0) Принципы

- Слова: только **Lotteries** (слово `l o t t e r y` запрещено).
- Нет таймеров. Триггер розыгрыша — **продажа последнего билета**.
- Два активных розыгрыша всегда одновременно:
  - **Lotteries 100 EFHC** (200 билетов)
  - **Lotteries VIP NFT EFHC** (1000 билетов)
- Все суммы/цены — **d8 строка** (`1.00000000`).
- Покупка билетов: списание **BONUS -> MAIN** (bonus-first).
- Пользовательские балансы не уходят в минус (жёстко).
- BANK_EFHC может уходить в минус (призы не блокируются).

## 1) ENV

Общие:

- `LOTTERIES_MAX_TICKETS_PER_USER=10`

EFHC:

- `LOTTERIES_EFHC_TOTAL_TICKETS=200`
- `LOTTERIES_EFHC_TICKET_PRICE_D8=1.00000000`
- `LOTTERIES_EFHC_PRIZE_BONUS_D8=100.00000000`

VIP NFT:

- `LOTTERIES_VIP_TOTAL_TICKETS=1000`
- `LOTTERIES_VIP_TICKET_PRICE_D8=1.00000000`
- `LOTTERIES_VIP_PRIZE_NFT_CODE=VIP_EFHC`

## 2) Лимиты и покупка

### 2.1 Лимит 10 билетов

- `max 10` применяется **на один draw**.
- В новом draw лимит обнуляется.

### 2.2 Списание балансов

При покупке билетов списание выполняется строго:

1) EFHC BONUS
2) EFHC MAIN

Недостаточно средств (BONUS+MAIN < cost) => покупка запрещена.

### 2.3 Недостаток билетов

Если в draw осталось меньше билетов, чем `qty`:

- если осталось 0: 409 sold out
- если осталось >0: покупаем **только остаток** (partial fill)

Фронт должен ограничивать `qty` по `remaining`, чтобы не ловить 409
в нормальном потоке.

### 2.4 Идемпотентность

POST buy — денежная операция, обязателен `Idempotency-Key`.

Канон:
- повтор с тем же ключом возвращает **тот же результат** (ticket_ids),
  без повторного списания и без дублей билетов.

## 3) Авто-розыгрыш и цикл

Момент:
- После продажи последнего билета draw **проводится сразу**,
  фиксируется победитель, draw закрывается, и **создаётся новый draw**.

Ключевое:
- выбор победителя выполняется **в атомарном серверном потоке**
  sold-out покупки (без таймеров/воркеров).

## 4) Вероятности

- 1 билет = 1 шанс.
- Для 200-ticket draw: 1 билет = 0.5%, 10 билетов = 5%.
- Для 1000-ticket draw: 1 билет = 0.1%, 10 билетов = 1%.

UI может не показывать шанс. Достаточно: `My tickets: M/10`.

## 5) Winners и хранение истории

### 5.1 Что показываем

В Winners показываем:

- `draw_id` (lotteries_id)
- `winner_tg_id`
- `winner_username`
- `winning_ticket_number` (1..200 / 1..1000)

### 5.2 Сколько храним

- Храним историю **последних 1000 завершённых draw**.
- Старше 1000 — **удаляем** (забвение).

## 6) VIP NFT: кошелёк и заявки

### 6.1 Истина кошелька

Кошелёк берём как **текущий привязанный к tg_id** на момент покупки
(VIP tickets). Покупка без кошелька запрещена.

UX:
- при нажатии кнопок фронт запускает привязку кошелька (TonConnect),
  после успешной привязки повторная попытка — покупка.

### 6.2 Claim на каждый билет

Канон:

- **каждый купленный VIP билет создаёт 1 claim** на выдачу NFT
  (для админ-панели).
- claim создаётся сразу при покупке билета.

Смена кошелька:
- выдача ориентируется на **текущий кошелёк в профиле**,
  claim хранит snapshot для аудита.

Минимальные поля claim (админка):

- `claim_id`
- `draw_id`
- `tg_id`
- `username`
- `ticket_number`
- `wallet_address_current`
- `wallet_address_snapshot`
- `created_at_utc`
- `status` (PENDING/ISSUED/REJECTED/CANCELED)
- `admin_comment`
- `nft_code=VIP_EFHC`

## 7) Приз EFHC (100 bonus)

Проводка приза:

- BANK_EFHC (MAIN) debit => user (BONUS) credit
  на `100.00000000`.

Банк может уйти в минус — приз выдаётся всегда.

## 8) API (минимум)

Коды ошибок (фиксируем):

- sold out: 409
- max per user exceeded: 409
- insufficient funds: 409
- wallet required (VIP): 409
- idempotency replay: 200 (тот же результат)

Эндпоинты (префикс `/api`):

- `GET /api/Lotteries` (лист, активные)
- `GET /api/Lotteries/{id}/my-tickets`
- `POST /api/Lotteries/{id}/buy`
- `GET /api/Lotteries/winners/latest`

Ответ buy должен содержать:

- ticket_ids
- debit_bonus_efhc, debit_main_efhc
- meta.partial_fill (если qty уменьшили по remaining)
