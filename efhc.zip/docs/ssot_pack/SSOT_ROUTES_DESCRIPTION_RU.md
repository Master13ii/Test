# SSOT: Маршруты — что это и как использовать

## Истина
Истина поведения маршрутов — **код handler → service → ORM/SQL**.
SSOT фиксирует:
1) где объявлен маршрут (file:line),
2) что он делает (суть),
3) какие таблицы читает/пишет,
4) доказательства (evidence file:line),
5) статус (P0/P1/P2).

## SSOT-файлы по маршрутам
- `SSOT_ROUTES.csv` — реестр маршрутов (method/path/file/line).
- `SSOT_ROUTES_NUMBERED.csv` — реестр с нумерацией `n`.
- `SSOT_ROUTE_TABLE_MAP.csv` — привязка маршрута к таблицам + evidence + статус.
- `SSOT_ROUTES_TABLES_MIGRATIONS.csv` — полный join: маршрут → таблицы → проверка, что таблицы создаёт `0001`.

## Каноничный формат обзора (пример)
Ниже — пример строки обзора (по канону):
**Маршрут | Суть | Таблицы | Статус**

| № | Маршрут | Суть | Таблицы | Статус |
|---:|---|---|---|---|
| 76 |  |  |  | NEED_TRACE |
| 77 |  |  |  | NEED_TRACE |
| 78 |  |  |  | NEED_TRACE |
| 79 |  |  |  | NEED_TRACE |
| 80 |  |  |  | NEED_TRACE |


## Статусы
- **Mapped (P2)** — таблицы доказаны и привязаны evidence, критичных дефектов нет.
- **P1** — требуется улучшение (например, консистентность, пагинация, редирект пути).
- **P0** — критично: запись без commit, несовпадение статусов/constraint, NEED_TRACE, денежная операция вне transactions_service.

## Экономическое правило
Любые денежно-опасные операции (hold/refund/commit, списания/начисления, запись `efhc_transfers_log`) — **только через `transactions_service`**.

## Канон direction (admin/transfer и efhc_transfers_log)
- Для админ-корректировок используется direction: **credit|debit**.
- Семантика двойной записи:
  - user credit ⇒ bank debit
  - user debit  ⇒ bank credit
- Поле efhc_transfers_log.direction — только **credit|debit**;
  контекст операции хранится в reason/meta.

## Текущее состояние (канон на этот ZIP)
- Маршрутов (SSOT_ROUTES_NUMBERED): 91.
- Нумерация маршрутов является каноном для ручных правок.
- Маршруты NO_DB допускают пустые read/write, но evidence обязателен.
