# SSOT_DUPLICATES_AND_ADMIN_EXTERNAL
## ORM physical duplicates
- None detected in current HEAD (v149_18).

## Logical duplicates / name mismatches (ORM vs 0001 migration)
### ORM tables missing in 0001 migration
- `efhc_core.admin_action_log`
- `efhc_core.admin_role`
- `efhc_core.admin_whitelist`
- `efhc_core.ads`
- `efhc_core.app_settings`
- `efhc_core.bank_state`
- `efhc_core.idempotency_key`
- `efhc_core.lotteries`
- `efhc_core.lotteries_nft_claims`
- `efhc_core.lotteries_results`
- `efhc_core.lotteries_tickets`
- `efhc_core.lotteries_user_stats`
- `efhc_core.ranks_snapshots`
- `efhc_core.ranks_top_cache`
- `efhc_core.shop_items`
- `efhc_core.task_submissions`
- `efhc_core.tasks`
- `efhc_core.user_cosmetics`
- `efhc_core.user_skins`

### 0001 tables not present in ORM models
- `efhc_admin.bank_balances`
- `efhc_admin.efhc_sale_packages`
- `efhc_core.admin_actions_log`
- `efhc_core.lotteries_rounds`
- `efhc_core.lotteries_winners`
- `efhc_core.panel_issuance`
- `efhc_core.payment_intents`
- `efhc_core.scheduler_task_log`
- `efhc_core.unmatched_incoming`
- `efhc_core.wallet_connect_idempotency`

## Admin external tables passports (schema-qualified raw SQL)
These tables are referenced via raw SQL as `efhc_admin.*` but
are not defined as ORM models in current HEAD.

### `efhc_admin.admin_logs`
- Writers: 1
  - backend/app/services/admin/admin_logging.py:109
- Readers: 1
  - backend/app/services/admin/admin_logging.py:183
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.admin_notifications`
- Writers: 1
  - backend/app/services/admin/admin_notifications.py:108
- Readers: 0
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.admin_users`
- Writers: 0
- Readers: 1
  - backend/app/services/admin/admin_rbac.py:130
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.bank_balances`
- Writers: 3
  - backend/app/services/admin/admin_bank_service.py:223
  - backend/app/services/admin/admin_bank_service.py:340
  - backend/app/services/admin/admin_bank_service.py:479
- Readers: 7
  - backend/app/routes/admin_routes.py:231
  - backend/app/services/admin/admin_bank_service.py:200
  - backend/app/services/admin/admin_bank_service.py:265
  - backend/app/services/admin/admin_bank_service.py:347
  - backend/app/services/admin/admin_bank_service.py:464
  - backend/app/services/admin/admin_stats_service.py:284
  - backend/app/services/admin/admin_stats_service.py:642
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.bonus_awards`
- Writers: 4
  - backend/app/services/admin/admin_lotteries_service.py:923
  - backend/app/services/admin/admin_withdrawals_service.py:861
  - backend/app/services/admin/admin_withdrawals_service.py:889
  - backend/app/services/admin/admin_withdrawals_service.py:979
- Readers: 5
  - backend/app/services/admin/admin_lotteries_service.py:54
  - backend/app/services/admin/admin_withdrawals_service.py:30
  - backend/app/services/admin/admin_withdrawals_service.py:723
  - backend/app/services/admin/admin_withdrawals_service.py:793
  - backend/app/services/admin/admin_withdrawals_service.py:958
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.efhc_mint_burn`
- Writers: 2
  - backend/app/services/admin/admin_bank_service.py:353
  - backend/app/services/admin/admin_bank_service.py:487
- Readers: 2
  - backend/app/services/admin/admin_bank_service.py:309
  - backend/app/services/admin/admin_bank_service.py:437
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.efhc_sale_packages`
- Writers: 2
  - backend/app/services/admin/admin_sale_packages_service.py:110
  - backend/app/services/admin/admin_sale_packages_service.py:67
- Readers: 5
  - backend/app/routes/deposit_routes.py:51
  - backend/app/services/admin/admin_sale_packages_service.py:30
  - backend/app/services/payment_intents_service.py:208
  - backend/migrations/versions/0001_init.py:1271
  - backend/migrations/versions/0001_init.py:146
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.nft_check_cache_ton`
- Writers: 1
  - backend/app/services/nft_check_service.py:211
- Readers: 2
  - backend/app/services/nft_check_service.py:139
  - backend/app/services/nft_check_service.py:180
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.prize_claims`
- Writers: 3
  - backend/app/services/admin/admin_lotteries_service.py:964
  - backend/app/services/admin/admin_withdrawals_service.py:1131
  - backend/app/services/admin/admin_withdrawals_service.py:1167
- Readers: 4
  - backend/app/services/admin/admin_lotteries_service.py:60
  - backend/app/services/admin/admin_withdrawals_service.py:1057
  - backend/app/services/admin/admin_withdrawals_service.py:1114
  - backend/app/services/admin/admin_withdrawals_service.py:31
- Decision: TBD (keep/merge/remove) after SSOT selection.

### `efhc_admin.system_settings`
- Writers: 1
  - backend/app/services/admin/admin_settings.py:264
- Readers: 3
  - backend/app/services/admin/admin_settings.py:165
  - backend/app/services/admin/admin_settings.py:217
  - backend/app/services/admin/admin_settings.py:9
- Decision: TBD (keep/merge/remove) after SSOT selection.
