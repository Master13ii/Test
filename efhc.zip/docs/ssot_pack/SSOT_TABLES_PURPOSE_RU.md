# Назначение таблиц EFHC Bot

Истина: ORM (`backend/app/models/**`, `Base.metadata`).
Цель: согласование «код → таблицы → миграции» (Postgres-only).

## efhc_core.achievements
Достижения/прогресс пользователя.

## efhc_core.admin_action_log
Аудит действий админа (кто/что/когда/детали).

## efhc_core.admin_bank_config
Конфиги банка EFHC (параметры эмиссии/лимиты).

## efhc_core.admin_role
Роли админов и права.

## efhc_core.admin_whitelist
Белый список админов/ключей доступа.

## efhc_core.ads
Рекламные события/провайдеры/слоты (для выдачи заданий/просмотров).

## efhc_core.app_settings
Техническая таблица EFHC Bot (назначение уточнить по ORM-модели и usage
в сервисах).

## efhc_core.bank_state
Техническая таблица EFHC Bot (назначение уточнить по ORM-модели и usage
в сервисах).

## efhc_core.efhc_transfers_log
Журнал EFHC d8: direction=credit

## efhc_core.idempotency_key
Ключи идемпотентности для денежных/опасных операций и внешних событий.

## efhc_core.lotteries
Лотереи (конфиг, состояние, параметры розыгрыша).

## efhc_core.lotteries_nft_claims
Заявки на NFT-выдачу по результатам лотерей (pending/approved/rejected).

## efhc_core.lotteries_results
Результаты розыгрыша (победители, суммы/награды).

## efhc_core.lotteries_tickets
Билеты лотереи (кто купил, сколько, когда).

## efhc_core.lotteries_user_stats
Агрегированная статистика пользователя в лотереях.

## efhc_core.panels
Солнечные панели пользователя (активные/архив), параметры генерации.

## efhc_core.payment_intents
Намерения/интенты оплаты (создание, статус, привязка к заказу/пакету).

## efhc_core.processed_external_events
Дедупликация внешних событий (например Telegram webhook), чтобы не
обрабатывать повторно.

## efhc_core.ranks_snapshots
Техническая таблица EFHC Bot (назначение уточнить по ORM-модели и usage
в сервисах).

## efhc_core.ranks_top_cache
Кэш топа рангов для быстрого чтения.

## efhc_core.referral_bonus_ledger
Учёт начисленных реферальных бонусов (ledger).

## efhc_core.referral_codes
Стабильные реф-коды (генерация/хранение).

## efhc_core.referral_links
Реферальные связи/ссылки (кто кого пригласил).

## efhc_core.scheduler_task_log
Очередь/лог задач планировщика (например ресинк энергии).

## efhc_core.shop_items
Товары магазина (пакеты, цены, доступность).

## efhc_core.shop_orders
Заказы магазина (статусы, состав, суммы).

## efhc_core.task_submissions
Отправки/прохождение заданий пользователями (статус, доказательства,
модерация).

## efhc_core.tasks
Каталог заданий (описание, награды, сроки, активность).

## efhc_core.ton_inbox_logs
Логи входящих транзакций TON/USDT (для reconciliation).

## efhc_core.user_cosmetics
Активные косметические настройки пользователя (текущий skin и т.п.).

## efhc_core.user_skins
Скины пользователя (купленные/доступные).

## efhc_core.users
Профили пользователей: идентификация (tg_id), VIP/NFT флаги, кошелёк,
статусы.

## efhc_core.wallet_bindings
Привязки TON-кошельков к tg_id (гейтинг для операций).

## efhc_core.withdraw_requests
Заявки на вывод EFHC (статусы/переходы).

## efhc_core.withdrawals
Техническая таблица EFHC Bot (назначение уточнить по ORM-модели и usage
в сервисах).
