# EFHC Project Specification

Статус: DERIVED (производный документ).
SSOT-якоря: docs/SSOT_INDEX.md, docs/EFHC_CANON.md,
docs/TERMS_GLOSSARY.md,
docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md.

Правило: этот документ не вводит новых норм.
Если есть конфликт с NORM-документами, приоритет у SSOT.

## 1. Общие правила и параметры

## 1.1 UI канон (DERIVED)

- Глобальный хедер отображается на всех вкладках:
  аватар, username, LVL, общий баланс Total (main+bonus),
  кнопки + и Shop.
- Нижняя навигация (Bottom Nav) содержит ровно 6 вкладок в порядке:
  Energy | Panels | Exchange | Tasks | Referrals | Ranks.
- Energy использует "живое" обновление E(t) от server_now_iso и
  gen_per_sec_effective (2–4 обновления UI в секунду) и шкалу 12 уровней
  по порогам kWh.

SSOT-якоря:
- docs/UI_PAGES_ACHIEVEMENTS_RU.md (DERIVED),
- docs/EFHC_CANON.md (NORM),
- docs/ARCHITECTURAL_LOCKS.md (NORM).

- Генерация панелей фиксированная, только в секундах:
  - `GEN_PER_SEC_BASE_KWH = 0.00000692` кВт/сек
  - `GEN_PER_SEC_VIP_KWH  = 0.00000741` кВт/сек
- Флаг **VIP** меняется внешним процессом ежедневно в 00:00 по наличию
- NFT.
- Флаг **ACTIVE** включается при первой покупке панели (навсегда).
- Денежная точность — 8 знаков после запятой (округление вниз).
- Обменник: EXCHANGE_ALL kWh → EFHC MAIN 1:1.
  Зеркало: available = max(total_generated - exchanged, 0).
  SSOT: docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md.
- Все списания у пользователей идут в банк (tg_id из ENV).
- Лимит панелей: 1000 (минус архивные).
- Реф-бонус:
  - Разовый 0.1 EFHC за первую панель у реферала.
  - Пороговые бонусы: 10→1 EFHC, 100→10 EFHC, 1000→100 EFHC, 3000→300
    EFHC, 10000→1000 EFHC.

---

## 2. Валюты и операции
- Пользователь может платить: **TON**, **USDT**, **EFHC**.
- Вывод возможен **только EFHC**.
- EFHC-пакеты покупаются за TON/USDT.
- VIP NFT выдается вручную админом по заявке (TON / USDT / EFHC).
- Все товары магазина имеют уникальный `custom_memo` для валидации
  транзакции.

---

## 3. Магазин и MEMO
- MEMO формируется по SSOT ton_memo.
- Пользователь не выбирает сумму вручную — фиксируется `expected_amount`
  + `expected_currency` + `expected_memo`.
- Проверка входящей транзакции:
  - Если всё совпало:
    - `efhc_pack_*` → заказ completed, EFHC начислены пользователю.
    - `vip_nft_*`   → заказ pending (ожидает выдачи NFT админом).
  - Если не совпало → заказ canceled (с диагностикой).

---

## 4. Cron-задачи
- **00:00 UTC** — проверка VIP-NFT (установка `vip_active`).
- **00:30 UTC** — начисление kWh по активным панелям.
- **01:00 UTC** — архивирование панелей.
- **01:30 UTC** — чистка логов и reconcile за последние 72 часа
  (APScheduler).

---

## 5. Логирование
### EFHC-транзакции
- `shop_buy_efhc` — покупка EFHC (банк → user)
- `shop_panel_bonus` — списание бонусных EFHC (user → банк)
- `shop_panel_efhc` — списание EFHC при покупке панели (user → банк)
- `exchange_kwh_to_efhc` — обмен kWh→EFHC
- `withdraw_lock` — блокировка EFHC при выводе
- `withdraw_refund` — возврат при отказе
- `prize_ticket_buy` — покупка билета (призовые события)
- `task_reward` — награда за задание

### Реф-бонусы
- `first_panel` — 0.1 EFHC при первой панели у реферала.
- `threshold` — бонусы за пороги активных рефералов.

---

## 6. API
- `POST /api/auth/webapp-init` — валидация initData, профиль/роли
- `GET /api/user/profile` — профиль, балансы, VIP, кошелёк
- `GET /api/panels` — активные и архивные панели
- `POST /api/panels/buy` — покупка панелей
- `POST /api/exchange/convert` — обмен kWh→EFHC
- `GET /api/ranks/global` — общий рейтинг
- `GET /api/ranks/referral` — рейтинг по рефералам
- `GET /api/referrals` — дерево рефералов
- `GET /api/shop/config` — адреса TON/USDT, NFT-маркет, auto-memo
- `POST /api/shop/buy` — создание заказа
- `POST /api/shop/check-payment` — ручная проверка транзакции
- `GET /api/admin/*` — банк EFHC, выводы, товары, заказы, логи

---

## 7. Watcher (TON)
- Фоновая задача: каждые 10-30 сек `process_incoming_payments()`.
- EFHC депозит:
  - MEMO: `EFHC:<tg_id>`
  - EFHC начисляются пользователю 1:1 с банка.
- Покупка пакета EFHC за TON/USDT:
  - MEMO: `BUY:EFHC:<qty>:TG:<tg_id>[:OID:<order_id>]`
  - Вотчер проверяет, что сумма на блокчейне совпала с ценой пакета.
  - Затем начисляет ровно `<qty>` EFHC пользователю с банка.
- Reconcile:
  - Ручной (`POST /admin/shop/reconcile`)
  - Авто в 01:30 UTC

---

## 8. Логика покупок
### Покупка за EFHC
- Пользователь → Банк
- EFHC списываются у пользователя, зачисляются Банку.
- `shop_items.stock` уменьшается.
- Создаётся order.

### Покупка за TON / USDT
- Пользователь оплачивает внешне.
- Банк → Пользователь
- EFHC начисляются пользователю (`credit_user_from_bank`).
- `shop_items.stock` уменьшается.
- Создаётся order.
