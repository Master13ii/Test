# EVENTS_MATRIX (EFHC) — Матрица событий и обязательные details

Статус: NORM (нормативный документ).
Якорь SSOT: docs/SSOT_INDEX.md

Цель:
- Единая матрица событий для аудита, аналитики и отладки.
- Единый формат details, пригодный для хранения и проверки.

Правила:
1) Любое событие обязано иметь event_name и details.
2) В details нельзя писать произвольный текст вместо структуры.
3) Где логично и допустимо, в details обязателен tg_id.
4) Для операций, меняющих баланс/статусы, обязателен idempotency_key.
5) Запрещён silent-pass: ошибки логируются и дают событие error.*.

Структура события:
- event_name: str
- details: object
  - at: ISO-8601 datetime (UTC)
  - source: "api" | "scheduler" | "admin" | "worker"
  - request_id: str | null
  - correlation_id: str | null
  - tg_id: int | null
  - actor_tg_id: int | null  # для админ-действий
  - idempotency_key: str | null

---

## 1) core

### core.startup
details:
- at, source
- version: str
- env: str

### core.shutdown
details:
- at, source
- reason: str

### core.error
details:
- at, source
- error_code: str
- message: str
- where: str

---

## 2) users

### users.profile_read
details:
- at, source, tg_id

### users.profile_updated
details:
- at, source, tg_id
- changed_fields: list[str]
- actor_tg_id: int | null

---

## 3) energy

### energy.state_read
details:
- at, source, tg_id

### energy.generated
details:
- at, source, tg_id
- kwh_delta: str  # Decimal as string
- rate_kwh_per_sec: str
- period_sec: int

---

## 4) panels

### panels.buy_requested
details:
- at, source, tg_id
- panels_qty: int
- price_efhc: str
- idempotency_key

### panels.buy_applied
details:
- at, source, tg_id
- panels_qty: int
- balance_before: str
- balance_after: str
- bank_delta: str
- idempotency_key

### panels.buy_rejected
details:
- at, source, tg_id
- error_code: str
- message: str
- idempotency_key

---

## 5) bank

### bank.balance_read
details:
- at, source
- actor_tg_id: int | null

### bank.op_posted
details:
- at, source
- op_id: str
- tg_id: int | null
- amount_efhc: str
- direction: "credit" | "debit"
- reason: str
- details: object  # доменные поля причины
- idempotency_key: str | null

### bank.op_error
details:
- at, source
- op_id: str | null
- error_code: str
- message: str

---

## 6) transactions

### transactions.created
details:
- at, source
- tx_id: str
- tg_id
- amount_efhc: str
- reason: str
- meta: object

### transactions.reverted
details:
- at, source
- tx_id: str
- tg_id
- revert_reason: str
- meta: object

---

## 7) shop

### shop.items_read
details:
- at, source

### shop.purchase_requested
details:
- at, source, tg_id
- item_id: str
- qty: int
- total_price: str
- idempotency_key

### shop.purchase_confirmed
details:
- at, source, tg_id
- order_id: str
- payment_kind: "ton" | "usdt" | "internal"
- payment_ref: str | null
- idempotency_key

### shop.purchase_rejected
details:
- at, source, tg_id
- error_code: str
- message: str
- idempotency_key

---

## 8) withdrawals

### withdrawals.requested
details:
- at, source, tg_id
- withdraw_id: str
- amount_efhc: str
- destination: str
- idempotency_key

### withdrawals.status_changed
details:
- at, source
- withdraw_id: str
- tg_id
- from_status: str
- to_status: str
- actor_tg_id
- comment: str | null

### withdrawals.paid
details:
- at, source
- withdraw_id: str
- tg_id
- payment_ref: str
- actor_tg_id

### withdrawals.rejected
details:
- at, source
- withdraw_id: str
- tg_id
- reason_code: str
- actor_tg_id

---

## 9) nft

### nft.check_started
details:
- at, source
- tg_id: int | null

### nft.check_result
details:
- at, source
- tg_id
- has_vip_nft: bool
- collection: str

---

## 10) watcher

### watcher.tick
details:
- at, source
- job: str

### watcher.error
details:
- at, source
- job: str
- error_code: str
- message: str

---

## 11) tasks

### tasks.created
details:
- at, source
- task_id: str
- tg_id
- kind: str

### tasks.completed
details:
- at, source
- task_id: str
- tg_id
- result: str

---

## 12) ads

### ads.view_registered
details:
- at, source
- tg_id
- provider: str
- reward_efhc: str
- idempotency_key

### ads.reward_applied
details:
- at, source
- tg_id
- amount_efhc: str
- idempotency_key

---

## 13) prizes (UI) / lotteries (кодовая подсистема)

Примечание:
- В UI и документах используем термин prizes.
- В коде допускается модульное имя lotteries как историческое.

### prizes.participation_requested
details:
- at, source, tg_id
- campaign_id: str
- stake_efhc: str
- idempotency_key

### prizes.selection_completed
details:
- at, source
- campaign_id: str
- winners: list[object]
  - tg_id: int
  - prize: str
- actor_tg_id: int | null

### prizes.grant_applied
details:
- at, source
- campaign_id: str
- tg_id
- prize: str
- amount_efhc: str | null
- idempotency_key: str | null

---

## 14) admin

### admin.action
details:
- at, source
- actor_tg_id
- action: str
- target_tg_id: int | null
- meta: object

### admin.access_denied
details:
- at, source
- actor_tg_id: int | null
- required_role: str
- endpoint: str
