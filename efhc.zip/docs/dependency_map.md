# EFHC Bot — Dependency Map (Canon v2.8)

Дата: 2026-01-23

Этот документ фиксирует **зависимости (pip)** и их **точки
использования** в репозитории, чтобы:
- быстро локализовать «лишние» библиотеки,
- понимать, что критично для продакшена (serverless),
- не ломать инварианты Канона при апдейтах.

## 1) Runtime-критичные зависимости (прод)

### FastAPI / ASGI
- **fastapi** — HTTP API, Webhook Telegram (`backend/app/main.py`,
- `backend/app/routes/*`)
- **uvicorn** — ASGI сервер (локально/контейнер), не используется
- напрямую в коде
- **orjson** — быстрый JSON ответ/парсинг (где включено)

### Pydantic v2
- **pydantic**, **pydantic-settings** — типизация + конфигурация
- (`backend/app/core/config_core.py`)

### Database
- **SQLAlchemy (async)** — ORM/транзакции (`backend/app/database.py`,
- `backend/app/models/*`, `backend/app/crud/*`)
- **asyncpg** — драйвер для приложения (runtime)
- **alembic** — миграции (`backend/migrations/*`)
- **psycopg2-binary** — sync драйвер **только для alembic** (миграции),
- приложение его не использует

### Telegram
- **aiogram 3.x** — Telegram bot framework:
  - Dispatcher + Routers (`backend/app/bot/bot.py`,
  - `backend/app/bot/handlers/*`)
  - Middlewares (`backend/app/bot/middlewares.py`)
  - Webhook вход (`backend/app/routes/system_routes.py` →
  - `bot.process_update()`)

### HTTP клиент
- **httpx** — внешние интеграции (TON / NFT / GetGems / подтверждения
- платежей) (`backend/app/services/*`)

## 2) Важные вспомогательные зависимости

- **python-dotenv** — локальная разработка (подхват .env), в prod может
- не использоваться
- **tenacity** (если подключено) — ретраи для сетевых вызовов (лучше
- использовать точечно, где реально надо)
- **python-dateutil** — удобные даты (если используется в
- задачах/сервисах)

## 3) Опциональные / dev-only (не должны быть критичны в prod)
- **pytest, ruff, mypy** — тесты/линт (если есть в dev-requirements)

## 4) Инварианты Канона, которые завязаны на зависимости
- Pydantic **строго v2** (нельзя смешивать с v1).
- Денежные поля в БД: **Numeric(18,8)** + округление **DOWN** —
- соблюдается на уровне сервисов (Decimal).
- Telegram webhook обязан ходить в **Dispatcher** (aiogram), а не в
- ручные httpx-вызовы Telegram API.

