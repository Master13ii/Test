# DB_SCHEMA (SSOT)

## Общие правила
- Основная схема: `efhc_core` (см. `DB_SCHEMA_CORE` в настройках
  окружения).
  Другие пространства данных (например, журналы) оформляются отдельными
  таблицами/схемами по канону терминов.
- Все денежные поля: `NUMERIC(30,8)` и округление вниз (ROUND_DOWN).
- Любая денежная операция должна иметь:
  - idempotency key (где применимо),
  - неизменяемый лог,
  - связку с бизнес-сущностью (withdraw/order/prize/...)

---

## Таблицы (по моделям)
Ниже перечислены ключевые таблицы (источник: `backend/app/models/*`).

### users
Хранит пользователей. Ключевой внешний идентификатор — `tg_id`.

### app_settings
Системные настройки.

### idempotency_key
Хранилище Idempotency-Key (дедупликация денежно-опасных POST).

### bank_state
Состояние «банка EFHC» и конфигурация.

### admin_action_log
Аудит админ-действий.

### efhc_transfers_log
Единый журнал внутренних EFHC-транзакций (переводы/списания/начисления).

### withdraw_requests / withdrawals
Контур заявок на вывод и их жизненный цикл.

### shop_items / shop_orders
Витрина и заказы магазина.

### panels
Панели (генерация энергии в игре).

### tasks / task_submissions
Задания и попытки/выполнения.

### referral_links
Реферальные ссылки и учёт.

### ton_inbox_logs
Логи входящих событий TON (для расследований и сверок).

### prize subsystem (tickets / results / user stats)
Подсистема призов и билетов (см. модели lotteries).

---

## Минимальные индексы (рекомендация)
- `users(tg_id)` UNIQUE
- `withdraw_requests(status, created_at)`
- `efhc_transfers_log(tg_id, created_at)`
- `ton_inbox_logs(tx_hash)` или `event_id` если есть
- индекс по билетам: (lotteries_id, owner_tg_id, ticket_id)

---

## Запрещено
- «Править руками» деньги SQL-UPDATE без сервисного контура.
- Обходить идемпотентность на денежных POST.
