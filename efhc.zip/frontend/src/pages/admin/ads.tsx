import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

export default function AdminAdsPage() {
  const t = useT();
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<any>(
        "/admin/ads/providers",
        "GET",
      );
      setProviders(Array.isArray(res) ? res : []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("admin.ads")}</h1>
        <Link href="/admin">
          <Button className="bg-white text-black">
            {t("admin.back")}
          </Button>
        </Link>
      </div>

      <Card title={t("admin.ads_providers")}>
        <div className="flex items-center gap-2 mb-3">
          <Button
            className="bg-white text-black"
            onClick={load}
            disabled={loading}
          >
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
        </div>
        {error ? (
          <div className="text-sm text-red-500 mb-2">{error}</div>
        ) : null}

        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-3">{t("admin.code")}</th>
                <th className="py-2 pr-3">{t("admin.title")}</th>
                <th className="py-2 pr-3">{t("admin.active")}</th>
              </tr>
            </thead>
            <tbody>
              {providers.map((p) => (
                <tr key={p.code} className="border-b">
                  <td className="py-2 pr-3">{p.code}</td>
                  <td className="py-2 pr-3">{p.title}</td>
                  <td className="py-2 pr-3">
                    {p.is_active ? "ON" : "OFF"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
