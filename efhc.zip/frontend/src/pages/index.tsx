import React, {
  memo,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import { Card } from "../components/ui/Card";
import { LayoutContext } from "../components/Layout";
import { KwhIcon } from "../components/icons/KwhIcon";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { clamp, format8, formatFixedDown } from "../lib/format";

const SCALE = 8;
const LIVE_TICK_MS = 333;
const SMOOTH_RESET_MS = 800;

function toScaled(v: string | number | null | undefined): bigint {
  const s0 = formatFixedDown(v, SCALE);
  const neg = s0.startsWith("-");
  const raw = neg ? s0.slice(1) : s0;
  const parts = raw.split(".");
  const intPart = parts[0] || "0";
  const frac = (parts[1] || "").padEnd(SCALE, "0");
  const digits = `${intPart}${frac}`.replace(/^0+(?=\d)/, "");
  const bi = BigInt(digits || "0");
  return neg ? -bi : bi;
}

function fromScaled(v: bigint): string {
  const neg = v < 0n;
  const raw = (neg ? -v : v).toString();
  const pad = raw.padStart(SCALE + 1, "0");
  const intPart = pad.slice(0, -SCALE);
  const frac = pad.slice(-SCALE);
  const out = `${intPart}.${frac}`;
  return neg ? `-${out}` : out;
}

function readStr(
  obj: any,
  path: string[],
  fallback: string,
): string {
  let cur: any = obj;
  for (const p of path) {
    if (cur && typeof cur === "object" && p in cur) cur = cur[p];
    else return fallback;
  }
  if (cur === null || cur === undefined) return fallback;
  return String(cur);
}

function readIntStr(
  obj: any,
  path: string[],
  fallback: string,
): string {
  let cur: any = obj;
  for (const p of path) {
    if (cur && typeof cur === "object" && p in cur) cur = cur[p];
    else return fallback;
  }
  if (cur === null || cur === undefined) return fallback;
  const s = String(cur).trim();
  if (!s) return fallback;
  return /^\d+$/.test(s) ? s : fallback;
}

type LiveBlockProps = {
  server_now_iso: string | null;
  lifetime_kwh: string;
  gen_per_sec_effective: string;
  thresholds_scaled: bigint[];
  level_names: string[];
  hide_balances: boolean;
};

const LiveEnergyHeroAndProgress = memo(
  function LiveEnergyHeroAndProgress(props: LiveBlockProps) {
    const e0ScaledRaw = useMemo(() => toScaled(props.lifetime_kwh), [
      props.lifetime_kwh,
    ]);
    const vScaledRaw = useMemo(
      () => toScaled(props.gen_per_sec_effective),
      [props.gen_per_sec_effective],
    );
    const vScaled = vScaledRaw < 0n ? 0n : vScaledRaw;

    const stateRef = useRef<{
      base_scaled: bigint;
      base_client_ms: number;
      smooth_delta: bigint;
      smooth_start_ms: number;
    }>(
      {
        base_scaled: 0n,
        base_client_ms: Date.now(),
        smooth_delta: 0n,
        smooth_start_ms: 0,
      },
    );
    const [tick, setTick] = useState(0);

    useEffect(() => {
      const now = Date.now();
      const st = stateRef.current;
      const dtMs = Math.max(0, now - st.base_client_ms);
      const cur = st.base_scaled + (vScaled * BigInt(dtMs)) / 1000n;
      const curSafe = cur < 0n ? 0n : cur;

      const target = e0ScaledRaw < curSafe ? curSafe : e0ScaledRaw;
      const delta = target - curSafe;

      st.base_scaled = curSafe;
      st.base_client_ms = now;
      st.smooth_delta = delta;
      st.smooth_start_ms = delta > 0n ? now : 0;
      setTick((x) => x + 1);
    }, [e0ScaledRaw, props.server_now_iso, vScaled]);

    useEffect(() => {
      if (!props.server_now_iso) return;
      if (vScaled === 0n) {
        if (stateRef.current.smooth_delta === 0n) return;
      }
      const id = window.setInterval(() => {
        setTick((x) => x + 1);
      }, LIVE_TICK_MS);
      return () => window.clearInterval(id);
    }, [props.server_now_iso, vScaled]);

    const eLiveScaled = useMemo(() => {
      const now = Date.now();
      const st = stateRef.current;
      const dtMs = Math.max(0, now - st.base_client_ms);
      const add = (vScaled * BigInt(dtMs)) / 1000n;
      let out = st.base_scaled + add;
      if (st.smooth_delta > 0n && st.smooth_start_ms > 0) {
        const t01 = clamp(
          (now - st.smooth_start_ms) / SMOOTH_RESET_MS,
          0,
          1,
        );
        const eased =
          (st.smooth_delta * BigInt(Math.floor(t01 * 1000))) / 1000n;
        out += eased;
      }
      return out < 0n ? 0n : out;
    }, [props.server_now_iso, tick, vScaled]);

    const level = useMemo(() => {
      const th12 = props.thresholds_scaled[11] ?? 0n;
      if (eLiveScaled >= th12) return 12;
      let lv = 1;
      for (let i = 2; i <= 11; i += 1) {
        const th = props.thresholds_scaled[i - 1];
        if (th !== undefined && th < eLiveScaled) lv = i;
      }
      return lv;
    }, [eLiveScaled, props.thresholds_scaled]);

    const startScaled = useMemo(() => {
      return props.thresholds_scaled[level - 1] ?? 0n;
    }, [level, props.thresholds_scaled]);

    const endScaled = useMemo(() => {
      if (level >= 12) return null;
      return props.thresholds_scaled[level] ?? null;
    }, [level, props.thresholds_scaled]);

    const progressPct = useMemo(() => {
      if (level >= 12) return 100;
      if (!endScaled) return 0;
      const span = endScaled - startScaled;
      if (span <= 0n) return 0;

      let num = eLiveScaled - startScaled;
      if (num < 0n) num = 0n;
      if (num > span) num = span;

      const pct = (num * 100n) / span;
      const v = parseInt(pct.toString(), 10);
      if (!Number.isFinite(v)) return 0;
      return v < 0 ? 0 : v > 100 ? 100 : v;
    }, [eLiveScaled, endScaled, level, startScaled]);

    const prefersReducedMotion = useMemo(() => {
      if (typeof window === "undefined") return true;
      const q = "(prefers-reduced-motion: reduce)";
      return window.matchMedia(q).matches;
    }, []);

    const [displayPct, setDisplayPct] = useState(0);

    useEffect(() => {
      if (prefersReducedMotion) {
        setDisplayPct(progressPct);
        return;
      }
      setDisplayPct(0);
      const id = window.requestAnimationFrame(() => {
        setDisplayPct(progressPct);
      });
      return () => window.cancelAnimationFrame(id);
    }, [prefersReducedMotion, progressPct]);

    const fillClassName = prefersReducedMotion
      ? "efhc-energy-progress-fill efhc-no-motion"
      : "efhc-energy-progress-fill";

    const progressInLevel = useMemo(() => {
      if (level >= 12) return "MAX";
      if (!endScaled) return "0.00000000";
      const span = endScaled - startScaled;
      const raw = eLiveScaled - startScaled;
      const v = raw < 0n ? 0n : raw > span ? span : raw;
      return fromScaled(v);
    }, [eLiveScaled, endScaled, level, startScaled]);

    const remainingKwh = useMemo(() => {
      if (level >= 12) return "MAX";
      if (!endScaled) return "0.00000000";
      const raw = endScaled - eLiveScaled;
      const v = raw < 0n ? 0n : raw;
      return fromScaled(v);
    }, [eLiveScaled, endScaled, level]);

    const heroText = useMemo(
      () => fromScaled(eLiveScaled),
      [eLiveScaled],
    );

    const heroFontPx = useMemo(() => {
      const len = heroText.length;
      const base = 52;
      const cut = Math.max(0, len - 14) * 2;
      return clamp(base - cut, 28, 52);
    }, [heroText]);

    return (
      <>
        <div className="efhc-energy-hero p-5">
          <div className="text-sm efhc-text-muted">Energy</div>
          <div className="mt-3 flex items-center gap-3">
            <div
              className={
                "w-10 h-10 rounded-2xl efhc-pill flex items-center "
                + "justify-center border"
              }
            >
              <span className="text-lg efhc-energy-accent">
                <KwhIcon size={18} />
              </span>
            </div>
            <div
              className={
                "font-extrabold tracking-wide efhc-energy-accent "
                + "tabular-nums whitespace-nowrap"
              }
              style={{
                fontSize: `${heroFontPx}px`,
                lineHeight: 1.05,
              }}
            >
              {props.hide_balances ? "••••••••" : heroText}
            </div>
          </div>
          <div className="mt-1 text-xs efhc-text-muted2">
            Total generated · kWh
          </div>
        </div>

        <Card className="p-4" highlight="energy">
          <div
            className={
              "flex items-center justify-between text-xs "
              + "efhc-text-muted2"
            }
          >
            <span>Progress</span>
            <span
              className={
                "tabular-nums efhc-energy-accent font-semibold"
              }
            >
              {props.hide_balances ? "••••••••" : progressInLevel}
              <span className="efhc-text-muted2">
                {progressInLevel === "MAX" ? "" : " kWh"}
              </span>
            </span>
          </div>

          <div className="mt-2 efhc-energy-progress-track">
            <div
              className={fillClassName}
              style={{
                width: `${displayPct}%`,
              }}
            />
          </div>

          <div
            className={
              "mt-2 flex items-center justify-between text-xs "
              + "efhc-text-muted2 tabular-nums"
            }
          >
            <span>{format8(fromScaled(startScaled))}</span>
            {endScaled ? (
              <span>{format8(fromScaled(endScaled))}</span>
            ) : null}
          </div>

          <div className="mt-2">
            <div className="text-sm font-semibold efhc-energy-accent">
              LVL {level}/12
            </div>
            <div className="text-xs efhc-text-muted2">
              {props.level_names[level - 1] ?? ""}
            </div>
          </div>

          <div className="mt-2 text-xs efhc-text-muted2 tabular-nums">
            Осталось: {props.hide_balances ? "••••••••" : remainingKwh}
            <span className="efhc-text-muted2">
              {remainingKwh === "MAX" ? "" : " kWh"}
            </span>
          </div>
        </Card>
      </>
    );
  },
);

export default function EnergyPage(
  props: {
    tg_id: number | null;
    snap: SyncSnapshot | null;
  },
) {
  const t = useT();
  const td = useTD();
  const { settings } = useContext(LayoutContext);
  const s = props.snap;

  const thresholdsKwh = useMemo(
    () => [
      "0",
      "100",
      "300",
      "600",
      "1000",
      "2000",
      "3500",
      "5000",
      "7500",
      "10000",
      "15000",
      "20000",
    ],
    [],
  );

  const levelNames = useMemo(
    () => [
      "Eco Initiate",
      "Hope Bringer",
      "Energy Seeker",
      "Nature's Voice",
      "Earth Ally",
      "Climate Fighter",
      "Green Sentinel",
      "Planet Defender",
      "Eco Champion",
      "Planet Saver",
      "Green Commander",
      "Guardian of Earth",
    ],
    [],
  );

  const thresholdsScaled = useMemo(() => {
    return thresholdsKwh.map((x) => toScaled(`${x}.00000000`));
  }, [thresholdsKwh]);

  const exchangedKwh = useMemo(() => {
    const direct = readStr(s, ["profile", "exchanged_kwh_total"], "");
    if (direct) return direct;
    const total = toScaled(s?.profile?.total_generated_kwh ?? "0");
    const avail = toScaled(s?.profile?.available_kwh ?? "0");
    const raw = total - avail;
    const v = raw < 0n ? 0n : raw;
    return fromScaled(v);
  }, [s]);

  const mask = (v: any) => {
    return settings.hide_balances ? "••••••••" : format8(v);
  };

  if (!props.tg_id) {
    return (
      <Card title={t("energy.title")}>
        <div className="text-sm efhc-text-muted">
          {td("desc.common.need_telegram_webapp")}
        </div>
      </Card>
    );
  }

  return (
    <div className="grid gap-4">
      <LiveEnergyHeroAndProgress
        server_now_iso={s?.meta?.server_now_iso ?? null}
        lifetime_kwh={
          readStr(
            s,
            ["profile", "lifetime_generated_kwh"],
            s?.profile?.total_generated_kwh ?? "0",
          )
        }
        gen_per_sec_effective={readStr(
          s,
          ["meta", "gen_per_sec_effective"],
          "0",
        )}
        thresholds_scaled={thresholdsScaled}
        level_names={levelNames}
        hide_balances={settings.hide_balances}
      />

      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4">
          <div className="text-xs efhc-text-muted2">
            Total Generation Rate
          </div>
          <div className="mt-1 text-lg font-semibold tabular-nums">
            {mask(s?.meta?.gen_per_sec_effective)}
            <span className="text-xs efhc-text-muted2"> kWh/s</span>
          </div>
        </Card>

        <Card className="p-4">
          <div className="text-xs efhc-text-muted2">
            Exchanged total
          </div>
          <div className="mt-1 text-lg font-semibold tabular-nums">
            {settings.hide_balances
              ? "••••••••"
              : format8(exchangedKwh)}
            <span className="text-xs efhc-text-muted2"> kWh</span>
          </div>
        </Card>
      </div>

      <Card className="p-4">
        <div className="text-xs efhc-text-muted2">Panels</div>
        <div className="mt-1 flex items-baseline gap-2">
          <div className="text-2xl font-semibold tabular-nums">
            {readIntStr(s, ["panels", "active_count"], "0")}
          </div>
          <div className="text-xs efhc-text-muted2">active</div>
          <div className="ml-3 text-xs efhc-text-muted2">·</div>
          <div className="text-xs efhc-text-muted2 tabular-nums">
            {readIntStr(s, ["panels", "archived_count"], "0")}
          </div>
          <div className="text-xs efhc-text-muted2">archived</div>
        </div>
      </Card>
    </div>
  );
}
