import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "../lib/api";

export type SyncSnapshot = {
  profile: {
    tg_id: number;
    username?: string | null;
    is_vip: boolean;
    main_balance: string;
    bonus_balance: string;
    available_kwh: string;
    total_generated_kwh: string;
    gen_per_sec_base: string;
    gen_per_sec_vip: string;
    daily_generation_base?: string;
    daily_generation_vip?: string;
  };
  panels: {
    active_count: number;
    total_generated_by_panels: string;
    nearest_expire_at?: string | null;
  };
  exchange_preview: {
    ok: boolean;
    available_kwh: string;
    max_exchangeable_kwh: string;
    rate_kwh_to_efhc: string;
    detail: string;
  };
  meta: {
    server_now_iso: string;
    gen_per_sec_effective: string;
    next_scheduler_eta_sec: number;
    fallback_task_id?: number | null;
  };
};

export function useSnapshot(tg_id: number | null) {
  const q = useQuery({
    queryKey: ["syncSnapshot", tg_id],
    enabled: Boolean(tg_id),
    // Снимок нужен для главной. Делаем кэш + фоновые обновления,
    // без дергания на каждый переход между вкладками.
    staleTime: 30_000,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
    queryFn: async () => {
      if (!tg_id) throw new Error("tg_id required");
      return await apiRequest<SyncSnapshot>(
        `/sync/user/${tg_id}?fresh=1`,
        "POST",
      );
    },
  });

  return {
    snap: q.data ?? null,
    loading: q.isFetching,
    error: q.error ? String(q.error) : null,
    refresh: q.refetch,
  };
}
