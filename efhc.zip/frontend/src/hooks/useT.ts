import { useContext } from "react";
import { LayoutContext } from "../components/Layout";

// UI labels are English for all languages; language selection affects
// descriptions only.
export function useT() {
  return useContext(LayoutContext).t;
}
