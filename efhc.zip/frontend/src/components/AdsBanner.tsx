import React from "react";
import { Card } from "./ui/Card";

export function AdsBanner() {
  return (
    <Card title="Ads">
      Ротация рекламы подключается через /api/ads
    </Card>
  );
}
