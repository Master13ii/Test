import React from "react";

export function Modal(
  props: React.PropsWithChildren<{
    open: boolean;
    onClose: () => void;
    title: string;
  }>,
) {
  if (!props.open) return null;
  return (
    <div
      className="fixed inset-0 efhc-modal-overlay flex items-center"
      aria-modal="true"
      role="dialog"
      onClick={props.onClose}
    >
      <div
        className="efhc-modal w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="text-lg font-semibold mb-2">{props.title}</div>
        {props.children}
      </div>
    </div>
  );
}
