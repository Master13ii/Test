import React from 'react';

type Props = {
  size?: number;
  className?: string;
};

const BASE = '/assets/efhc';

function pickBaseSrc(size: number) {
  if (size <= 56) return `${BASE}/efhc_coin_56.png`;
  if (size <= 72) return `${BASE}/efhc_coin_64.png`;
  if (size <= 112) return `${BASE}/efhc_coin_96.png`;
  if (size <= 192) return `${BASE}/efhc_coin_128.png`;
  return `${BASE}/efhc_coin_256.png`;
}

export function EfhcCoinIcon({ size = 24, className = '' }: Props) {
  const src = pickBaseSrc(size);
  const srcSet = [
    `${BASE}/efhc_coin_56.png 56w`,
    `${BASE}/efhc_coin_64.png 64w`,
    `${BASE}/efhc_coin_96.png 96w`,
    `${BASE}/efhc_coin_128.png 128w`,
    `${BASE}/efhc_coin_256.png 256w`,
  ].join(', ');

  return (
    <img
      src={src}
      srcSet={srcSet}
      sizes={`${size}px`}
      width={size}
      height={size}
      className={className}
      alt=""
      aria-hidden="true"
      draggable={false}
      style={{ display: 'block' }}
    />
  );
}

export const EfhcCoin = EfhcCoinIcon;
