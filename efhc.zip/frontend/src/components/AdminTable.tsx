import React from 'react';
import { Card } from './ui/Card';
export function AdminTable() {
  return <Card title="Admin Table">Table</Card>;
}
