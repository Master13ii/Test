import React from "react";
import { Card } from "./ui/Card";

export function ReferralsTabs() {
  return (
    <Card title="Referrals">
      Реферальная статистика будет подключена через /api/referrals
    </Card>
  );
}
