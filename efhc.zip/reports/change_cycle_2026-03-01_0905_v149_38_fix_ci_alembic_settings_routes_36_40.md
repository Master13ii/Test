# Change report — v149_38

Источник истины по падениям: GitHub Actions logs.
- logs_58935568518.zip: Alembic upgrade head (Postgres-only) падал на ImportError (settings).

## Что упало → Root cause
1) Alembic upgrade head
- Root cause: `backend/app/models/admin_models.py` импортировал `settings` из `backend.app.core.config_core`, но `config_core.py` не экспортировал `settings` (экспортировал только `get_settings`). Это приводило к ImportError в миграции 0001 (импорт моделей для Base.metadata).

## Что исправлено
### Код
- backend/app/core/config_core.py
  - Добавлен экспорт `settings = get_settings()` и включён в __all__ для совместимости импорта.

- backend/app/services/tasks_service.py
  - Исправлена сигнатура `admin_list_submissions`: теперь принимает `task_id` и `status`, как требует `admin_tasks_routes.py`.

### SSOT
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
  - Заполнены tables/evidence для маршрутов №36–№40 (admin tasks): /api/admin/tasks*.

## Кеш/мусор перед упаковкой
- Удалены: __pycache__, *.pyc, .pytest_cache, .mypy_cache, .ruff_cache, node_modules, .next и прочие caches.

## Следующий шаг
- Дождаться новых logs_*.zip для подтверждения CI по v149_38.
