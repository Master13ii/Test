# Change report — v149_41

## Основание (logs)
- logs_58938125974.zip: Alembic падал на ModuleNotFoundError: No module named 'backend' из app.core.system_locks (импорты backend.app.* в окружении `cd backend`).

## Изменения

### 1) Fix Alembic/import chain (app.core)
- backend/app/core/*.py: удалены импорты `backend.app.*`, заменены на `app.*` (или локальные эквиваленты).
  Цель: alembic upgrade head работает из `extracted/backend` без пакета `backend`.

### 2) SSOT паспорта №51–№55 (tables + evidence)
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv: заполнены read/write/evidence_refs:
  - 51 GET /exchange/history/{tg_id}
  - 52 GET /exchange/preview/{tg_id}
  - 53 GET /health
  - 54 GET /health/db
  - 55 GET /health/db-schema

## Наблюдения
- В проекте остаются legacy-импорты `backend.app.*` в прикладных модулях (routes/services). Они допустимы при запуске от корня репозитория, но для Alembic (cwd=backend) критично, чтобы импорт-цепочка моделей/ядра была чисто `app.*`.

## Артефакты
- EFHC_Bot_v149_41_fix_core_imports_ssot_routes_51_55.zip
