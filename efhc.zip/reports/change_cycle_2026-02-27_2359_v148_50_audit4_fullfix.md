# EFHC Bot — Change Report (v148_50)

Дата/время (UTC): 2026-02-27 23:59

Основание: «Полный аудит EFHC Bot #4» + logs_58835186075.zip.

## Выполнено (100% по аудиту #4)

### CI/pytest stack (SSOT)
- docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml: убран `pip install -U` для pytest-стека.
- Установка зависимостей описана через `requirements*.txt` (предсказуемость).

### Pytest asyncio strict: маркеры
- Добавлены `@pytest.mark.asyncio` на async-тесты:
  - tests/test_panels_180_days.py
  - tests/test_panels_active_archive.py
  - tests/test_panels_global_id.py
  - tests/test_panels_idempotent_create.py
  - tests/test_payment_intents_lifecycle_double_payments.py

### IncomingTx test
- tests/test_unmatched_incoming_recording.py: IncomingTx создаётся сразу с обязательными полями.

### Alembic 0001_init.py
- payment_intents.id: включён autoincrement (sequence/identity для Postgres).
- sanity required list расширен (core+admin минимумы).
- op.create_foreign_key: добавлены source_schema/referent_schema (multi-schema).

### SSOT ENERGY mirror
- users.available_kwh: сделан Computed (mirror) от lifetime/exchanged.
- Убраны все UPDATE available_kwh из energy_service и transactions_service.
- Тесты: исправлены подготовительные INSERT/UPDATE в concurrency exchange.

## Проверка
- python -m compileall backend -q: PASS
- python -m compileall tests -q: PASS
