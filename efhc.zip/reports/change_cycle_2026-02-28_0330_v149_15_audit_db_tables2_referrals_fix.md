# Change Cycle 2026-02-28_0330 v149_15

Audit-Id: AUD-2026-02-28-DB-INVENTORY-002

## Что исправлено

- Исправлены имена колонок ReferralLink: inviter_tg_id/invitee_tg_id.
- Добавлена ORM-модель ReferralBonusLedger (таблица referral_bonus_ledger).
- 0001_init.py:
  - исправлен referral_links (таблица/колонки/FK на users.tg_id)
  - добавлена referral_bonus_ledger + FK
  - добавлена efhc_admin.bank_balances
  - убран запрещённый schema kw внутри sa.Column у efhc_sale_packages

## Проверки

- python -m compileall backend -q: PASS
- audits_index_lint.py / audits_md_lint.py: PASS
