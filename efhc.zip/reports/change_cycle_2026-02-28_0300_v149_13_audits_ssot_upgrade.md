# Change Report — v149_13_audits_ssot_upgrade

## Scope
Минимальный апгрейд audit-md в формат SSOT-актива:
метаданные, секции Findings/Actions, очищенный Appendix, 72 символа.

## Changes
- docs/audits/*.md: добавлена шапка метаданных
  (Source/Scope/Date/Status/
Superseded by).
- docs/audits/*.md: заменён раздел «Извлечённые фрагменты» на:
  - Findings (FACTS)
  - Actions (DECISIONS)
  - Appendix: Raw Extract (optional)
- docs/audits/*.md: raw-вставки очищены от служебных токенов и
  ограничены
по длине.
- docs/audits/README.md: добавлены статус и 1-строчный итог по каждому
аудиту.
- Все audit-md приведены к ограничению 72 символа в строке.

## Verification
- Markdown: структура единообразна, ссылки на файлы сохранены.
- ZIP-to-ZIP guard: диагностические файлы не удалялись.
