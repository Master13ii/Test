# EFHC Bot — Change Cycle Report

**Cycle:** 2026-03-01_0335 (UTC)

**Version:** EFHC_Bot_v149_30_fix_ci_schema_and_routes_11_15

## What failed (from GitHub Actions logs)
- **Alembic upgrade head** failed with: `schema "efhc_lotteries" does not exist` while creating `efhc_lotteries.lotteries`.

## Where
- `backend/migrations/env.py` created only `DB_SCHEMA_CORE` before running migrations.
- `backend/app/models/lotteries_models.py` uses table-level schema `efhc_lotteries`.

## Root cause
On a clean CI Postgres database, non-core schemas (`efhc_lotteries`, `efhc_admin`) are absent.
When `0001_init` executes `Base.metadata.create_all`, creation of the first table in a missing schema fails.

## Fixes in this cycle

### 1) CI / migrations — create required schemas before running migrations (P0)
- `backend/migrations/env.py` (online mode): create schemas:
  - `DB_SCHEMA_CORE` (default `efhc_core`)
  - `DB_SCHEMA_ADMIN` (default `efhc_admin`)
  - `DB_SCHEMA_LOTTERIES` (default `efhc_lotteries`)

### 2) Routes №11–№12 (admin panels activate/deactivate) — missing commit (P0)
- `backend/app/routes/admin_panels_routes.py`
  - Added `await db.commit()` after panel UPDATE + AdminLogger.write.
  - Without commit, both the panel update and admin log insert could be lost.

### 3) Routes №14–№15 (admin sale packages) — canonical path + admin auth (P0)
- `backend/app/routes/admin_sale_packages_routes.py`
  - Canonicalized paths to trailing slash: `/admin/sale-packages/` for GET/POST.
  - Added `require_admin` dependency to all handlers.
  - Added Idempotency-Key requirement to toggle endpoint as well (change endpoint).

### 4) SSOT pack alignment (routes registry/table map)
- `docs/ssot_pack/SSOT_ROUTES.csv`
  - Updated paths to match canon:
    - `GET /admin/panels/`
    - `GET/POST /admin/sale-packages/`
- `docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv`
  - Updated mapping for:
    - `/admin/panels/` (read: `efhc_core.panels`)
    - `/admin/panels/{panel_id}/activate` (write: `efhc_core.panels; efhc_admin.admin_logs`)
    - `/admin/panels/{panel_id}/deactivate` (write: `efhc_core.panels; efhc_admin.admin_logs`)
    - `/admin/sale-packages/` (read/write `efhc_admin.efhc_sale_packages` with evidence)

## Files changed
- `backend/migrations/env.py`
- `backend/app/routes/admin_panels_routes.py`
- `backend/app/routes/admin_sale_packages_routes.py`
- `docs/ssot_pack/SSOT_ROUTES.csv`
- `docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv`
- `reports/REPORTS_INDEX.md`
- `reports/change_cycle_2026-03-01_0335_v149_30_fix_ci_schema_and_routes_11_15.md`
