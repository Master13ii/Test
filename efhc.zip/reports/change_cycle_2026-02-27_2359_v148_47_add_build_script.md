# Change report: v148_47 — build script для efhc.zip

Дата/время: 2026-02-27 23:59 (Europe/Uzhgorod)

## Цель
Закрепить канон сборки `efhc.zip` с обязательной чисткой и pre/post-pack guard,
чтобы в артефакт не попадали кэши/мусор (`__pycache__`, `*.pyc`, `node_modules`,
`*.new*`) и чтобы сборка ломалась до CI при нарушении якорей SSOT.

## Сделано
- Добавлен скрипт: `ops/build_efhc_zip.sh`
  - CLEAN: удаляет только генерируемый мусор/кэши
  - PRE-PACK GUARD: `python ops/canon_guard.py`
  - BUILD: собирает FLAT `efhc.zip`
  - POST-PACK: проверяет наличие якорей и отсутствие мусора

## Проверка
- Скрипт предназначен для запуска из корня репозитория:
  - `bash ops/build_efhc_zip.sh`

## Изменённые файлы
- ops/build_efhc_zip.sh (новый)
- docs/SSOT_INDEX.md (добавлен пункт про скрипт и порядок сборки)
