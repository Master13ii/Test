# Change cycle v149_04 — DB SSOT: 2 схемы / 30 таблиц (0001 rewrite)

Дата/время: 2026-02-28 11:35 (Europe/Uzhgorod)

## Что упало
- CI sanity после alembic: отсутствуют требуемые таблицы в efhc_core/efhc_admin.
- Отдельно фиксировалось падение Alembic при `schema` внутри `sa.Column(...)`.

## Root cause
- Несоответствие: модели кода требуют 30 таблиц, а миграция 0001 создаёт меньше и с другими именами.
- Sanity проверял другой набор (2/8/3), что не отражало истину проекта.

## Исправление
1) Добавлен SSOT-документ: `docs/SSOT_DB_SCHEMAS_TABLES.md` (2 схемы, 30 таблиц).
2) Полностью переписана миграция `backend/migrations/versions/0001_init.py`:
   - создаёт `efhc_core` и `efhc_admin`
   - создаёт 30 таблиц (имена 1:1 с моделями)
   - sanity внутри 0001: проверяет 30 `to_regclass(schema.table)`
3) Обновлён Alembic sanity в `backend/migrations/env.py` на проверку 30 `to_regclass(schema.table)`.
4) Добавлен скрипт `ops/ci_verify_db_objects.py` для CI-шага «до уничтожения временной БД».

## Изменённые файлы
- `docs/SSOT_DB_SCHEMAS_TABLES.md` (NEW)
- `backend/migrations/env.py`
- `backend/migrations/versions/0001_init.py`
- `ops/ci_verify_db_objects.py` (NEW)
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
- `reports/change_cycle_2026-02-28_1135_v149_04_db_ssot_30tables.md`
- `reports/REPORTS_INDEX.md`

## Проверка (локально на распакованном ZIP)
- `python -m compileall backend -q` — PASS

## Как включить в CI (workflow)
- Добавить шаг **после** `alembic upgrade head` и **перед** завершением job:
  `PSYCOPG_URL=postgresql://... python ops/ci_verify_db_objects.py`
