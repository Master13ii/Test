# Аудит изменений по чату (SSOT)

Дата: 2026-02-27 (Europe/Uzhgorod, UTC+02)

Источник: история задач/версий в этом чате + CI-логи logs_*.zip,
которые были загружены в чат.

## Принцип
- Время фиксируем по старту CI-run из `0_canon.txt` внутри logs_*.zip.
- Если точное время ручных действий в чате отсутствует — привязка идёт
  к ближайшему CI-run.

---

## Таймлайн CI-run (привязка времени)

- 2026-02-27 12:30:45 — `logs_58784595777.zip` (UTC 10:30:45)
- 2026-02-27 12:58:37 — `logs_58787230823.zip` (UTC 10:58:37)
- 2026-02-27 15:07:42 — `logs_58798929066.zip` (UTC 13:07:42)
- 2026-02-27 16:43:15 — `logs_58808841834.zip` (UTC 14:43:15)

---

## Изменения по циклам (по порядку)

### Цикл A — v148_32 (точка перед серией фиксов)

- Исправления pytest collection: добавлен `freezegun` в requirements
  и `sys.path` фиксация на import-time в `tests/conftest.py`.

### Цикл B — v148_33

- Добавлены артефактные якоря через SSOT `ops/canon_rules.yaml` и guard.
- Удалён pytest-тест артефакта сборки (по требованию), проверка перенесена
  в guard/ops.


### Цикл C — v148_34

- Пакет исправлений по Audit #1: CORS `" * "`->`"*"`,
  `forwarded_allow_ips` `" * "`->`"*"`.
- Исправлен `test_no_placeholders` (реальный обход),
  исправлен `ops/canon_guard` (artifact_anchors + 72 chars).
- Исправлен NameError `_get_async_db_url` в тестах.
- Исправлены конкурентные тесты: каждый task использует отдельный
  `AsyncSession`.


### Цикл D — v148_35 (Variant A)

- Admin auth: убрано доверие к `X-Admin-Id`, добавлен `ADMIN_API_KEY`
  через `hmac.compare_digest`.
- DB-тесты: добавлен `db_migrated` (alembic upgrade head) и включён
  loop scope session в pytest-конфиг.
- Pre-commit: исправлен entry на существующие тесты.


### Цикл E — v148_36 (Audit #2)

- Исправлены `IndentationError` в двух concurrency-тестах.
- SchedulerService: исправлен backoff (job не умирает навсегда).
- System routes: секреты сравниваются через `hmac.compare_digest`.
- Pytest SSOT: удалён `[tool.pytest.ini_options]` из `pyproject.toml`,
  SSOT = `pytest.ini`.


### Цикл F — v148_37 и откат v148_38

- Попытка backfill CI-логов в папку `.local_artifacts/logs/` отменена по
  требованию пользователя; текущая база = v148_38.
