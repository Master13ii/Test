# Change cycle — 2026-03-01 07:30 — v149_35

## Scope
- Routes №21–№25 (admin users): паспорта/tables/evidence + P0 фиксы.
- Harmonization: code → route → table → migrations (admin logs aligned to ORM table).

## Fixes
1) backend/app/routes/admin_users_routes.py
- PATCH /admin/users/{tg_id}/vip: added `await db.commit()` after AdminLogger.write (P0 write-without-commit).
- PATCH /admin/users/{tg_id}/active: added `await db.commit()` after AdminLogger.write (P0).
- POST /admin/users/{tg_id}/wallet/reset: added `await db.commit()` after AdminLogger.write (P0).

2) backend/app/services/admin/admin_logging.py
- Canon alignment: write/list now use `efhc_core.admin_action_log` (ORM table) instead of legacy `efhc_admin.admin_logs`.
- Insert writes to columns: admin_id, action, target_type, target_id, details_json.
- list_logs maps target_type→entity, target_id→entity_id, created_at→timestamp, details_json→details.

3) backend/app/models/admin_models.py
- Canon alignment for 0001 ORM-only: `ADMIN_SCHEMA = settings.DB_SCHEMA_CORE` (admin ORM tables live in efhc_core).

## SSOT updates
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv: filled read/write tables + evidence for routes №21–№25.
  - write routes include efhc_core.admin_action_log (via AdminLogger.write evidence).

## Notes
- CI status is not asserted in this report (truth only via logs_*.zip from GitHub Actions).
