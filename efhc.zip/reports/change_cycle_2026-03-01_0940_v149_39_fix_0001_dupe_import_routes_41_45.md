# EFHC Bot — Change cycle report

- Date: 2026-03-01
- Version: v149_39
- Base ZIP: EFHC_Bot_v149_38_fix_ci_settings_tasks_routes_36_40.zip
- Evidence logs: logs_58936111325.zip (Alembic upgrade head failed)

## Что упало (по logs)
- Alembic upgrade head: sqlalchemy.exc.InvalidRequestError: Table 'efhc_core.admin_whitelist' is already defined for this MetaData instance.
  Причина: один и тот же модуль моделей загружался дважды под разными именами пакетов (backend.app.* и app.*), что приводило к повторному определению ORM-класса и Table.

## Исправления

### 1) 0001_init.py — устранение двойного импорта моделей (P0 CI)
- Файл: backend/migrations/versions/0001_init.py
- Изменение:
  - импорт моделей переведён на пакет app.models (CWD=backend в CI) и исключён импорт backend.app.models
  - добавлен детерминированный импорт всех *_models.py через pkgutil/importlib в рамках app.models
  - sanity to_regclass: не дублирует схему, если ключ MetaData уже schema.table

### 2) SSOT_ROUTE_TABLE_MAP — заполнены маршруты №41–№45 (lotteries public)
- Файл: docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
- Добавлено:
  - read_tables/write_tables + evidence_refs для:
    - GET /api/lotteries
    - GET /api/lotteries/history
    - GET /api/lotteries/{lotteries_id}
    - POST /api/lotteries/{lotteries_id}/buy
    - GET /api/lotteries/{lotteries_id}/my-tickets
  - Для POST /buy установлен флаг IDEMPOTENCY_KEY_REQUIRED.
- Экономический канон:
  - покупка билетов выполняет списания через transactions_service (debit_user_*), прямых UPDATE balances/users и INSERT efhc_transfers_log в обход transactions_service не добавлялось.

## Проверки
- Repo-wide bans: telegram-id / tg_id / user-key / rank* — не добавлялись этим циклом.
- Кеши перед упаковкой ZIP очищены (pycache/pyc/pytest_cache и др.).

## Изменённые файлы
- backend/migrations/versions/0001_init.py
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
- reports/change_cycle_2026-03-01_0940_v149_39_fix_0001_dupe_import_routes_41_45.md
- reports/REPORTS_INDEX.md

