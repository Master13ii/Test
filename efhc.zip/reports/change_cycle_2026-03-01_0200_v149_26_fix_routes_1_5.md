# Change Report v149_26 — Fix routes 1–5

## Scope
Fixes applied to routes 1–5 in the numbered passports list:
1) GET /admin/ads/providers
2) GET /admin/bank/balance
3) POST /admin/bank/mint
4) POST /admin/bank/burn
5) GET /admin/logs/transfers

## What was wrong
- backend/app/routes/admin_routes.py referenced a non-existent dependency
  require_admin_or_nft_or_key (imported from security_core), which would
  crash at runtime and breaks the admin bank routes.
- Admin bank mint/burn used hardcoded admin_tg_id=0 instead of the
  authenticated admin tg_id.

## Fix
- Replaced require_admin_or_nft_or_key with deps.require_admin across
  admin_routes.py and updated documentation comment accordingly.
- Bank endpoints now receive AuthContext and pass admin_tg_id from
  authenticated context.
- admin_bank_service raw SQL now uses explicit fq name
  efhc_admin.bank_balances to make table usage evidence stable.

## Verification
- python -m compileall backend -q (expected PASS in CI).
