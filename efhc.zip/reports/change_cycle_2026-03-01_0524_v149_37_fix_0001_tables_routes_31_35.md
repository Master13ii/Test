# Change cycle 2026-03-01_0524 v149_37

## Источник истины
- HEAD ZIP: EFHC_Bot_v149_37_fix_0001_tables_routes_31_35.zip
- CI logs: logs_58934886722.zip (подтверждает падение Alembic 0001 sanity)

## Что упало (по logs_58934886722.zip)
- Alembic upgrade head: `0001 sanity failed; tables_count_expected_31_got_17`.

## Root cause
1) `backend/app/models/__init__.py` использует «мягкий» автоимпорт моделей и
   не гарантирует загрузку всех `*_models.py` при сборке Base.metadata.
2) `backend/app/models/referral_models.py` содержал ссылку на `SCHEMA` вместо
   `CORE_SCHEMA` (ошибка импорта → модуль пропускался).
3) `backend/app/models/tasks_models.py` использовал отдельную схему tasks и
   запрещённые практики (sqlite-variant, naive datetime), что конфликтовало с
   каноном «2 схемы + 31 таблица в efhc_core».

## Что сделано
### DB / миграции / ORM
- `backend/migrations/versions/0001_init.py`:
  - добавлен жёсткий импорт всех `backend.app.models.*_models` перед create_all.
- `backend/app/models/referral_models.py`:
  - исправлено `ReferralBonusLedger`: schema и ForeignKey теперь `CORE_SCHEMA`.
- `backend/app/models/tasks_models.py`:
  - schema → `settings.DB_SCHEMA_CORE` (канон: tasks в efhc_core);
  - убраны sqlite-variants;
  - время: server_default/onupdate через `func.now()` (tz-aware);
  - поле `tg_id` вместо `user_tg_id` (канон идентификатора).

### Routes №31–№35 (функциональные P0)
- `backend/app/services/referral_service.py`:
  - добавлены `admin_summary`, `admin_manual_bonus`, `admin_reassign_inviter`.
- `backend/app/routes/admin_referral_routes.py`:
  - исправлена передача идентификаторов: сервисы работают по `tg_id`, не по users.id.
- `backend/app/services/tasks_service.py`:
  - добавлены admin CRUD и `moderate_submission_and_pay` для admin_tasks_routes.

### SSOT
- `docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv`:
  - заполнены маршруты №31–№35 (tables + evidence file:line).
- `docs/ssot_pack/SSOT_TABLES_ORM.csv`:
  - регенерирован список 31 ORM-таблицы (schema=efhc_core, file/line).
- `docs/ssot_pack/SSOT_TABLES_MIGRATIONS.csv`:
  - приведено к канону (revision=0001, 2 схемы + 31 таблица).

## Проверка
- Локальные команды в чате не являются источником истины по CI.
- Для подтверждения “PASS” нужен новый logs_*.zip из GitHub Actions по этому ZIP.

## Изменённые файлы (кратко)
- backend/migrations/versions/0001_init.py
- backend/app/models/referral_models.py
- backend/app/models/tasks_models.py
- backend/app/services/referral_service.py
- backend/app/routes/admin_referral_routes.py
- backend/app/services/tasks_service.py
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
- docs/ssot_pack/SSOT_TABLES_ORM.csv
- docs/ssot_pack/SSOT_TABLES_MIGRATIONS.csv
