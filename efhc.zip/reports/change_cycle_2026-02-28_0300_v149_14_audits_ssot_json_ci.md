# Change Cycle 2026-02-28_0300 v149_14

## Scope
SSOT-аудиты: JSON-навигация, автогенерация README, линтеры и CI-
валидация.

## Changes
- Added: docs/audits/audits_index.json (SSOT navigator).
- Added: docs/audits/audits.schema.json (JSON schema).
- Added: ops/audits_index_lint.py (CI lint for index).
- Added: ops/audits_md_lint.py (CI lint for audit-md).
- Added: ops/audits_readme_generate.py (README generator).
- Added: .github/workflows/audits-ssot-lint.yml (CI job).
- Migrated audits to canonical filenames and SSOT structure.
- Moved legacy audit md files to docs/audits/_raw/legacy_md/ (not
  linted).

## Verification
- Lint: python ops/audits_index_lint.py
- Lint: python ops/audits_md_lint.py
- Generate: python ops/audits_readme_generate.py

## Notes
This cycle introduces SSOT governance for audits. Any future audit
changes must update audits_index.json and keep README generated.
