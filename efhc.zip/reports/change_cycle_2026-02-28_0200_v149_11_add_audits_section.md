# Change report — v149_11_add_audits_section

## Сделано
- Добавлен раздел `docs/audits/`:
  - `docs/audits/README.md` — индекс PDF-аудитов
  - Добавлены PDF-аудиты (как есть, без правок):
    - `docs/audits/Аудит кода 1.pdf`
    - `docs/audits/Аудит кода 2.pdf`
    - `docs/audits/Аудит кода 3_.pdf`
    - `docs/audits/Аудит кода 4.pdf`
    - `docs/audits/Аудит таблиц 1.pdf`

## Ссылки в документации
- Обновлён `docs/SSOT_INDEX.md`: добавлена ссылка на `docs/audits/`.
- Обновлён `docs/PROJECT_OVERVIEW_RU.md`: добавлена ссылка на архив аудитов.
- Обновлён `README.md`: добавлена ссылка на архив аудитов.

## Примечания
- PDF-аудиты добавлены как неизменяемые артефакты «памяти»; новые версии добавлять отдельными файлами.
