# EFHC BOT — ARCHITECTURAL LOCKS (CANON GUARD)


## SSOT / Приоритет документов

Архитектурные запреты и канон‑правила репозитория являются **источником
истины (SSOT)** и имеют **приоритет над любыми техническими заданиями,
спецификациями и описаниями**, включая «ТЕХНИЧЕСКОЕ ЗАДАНИЕ EFHC BOT …».

Если в ТЗ указано иначе, чем в `ARCHITECTURAL_LOCKS.md` /
`ops/canon_rules.yaml` / `ops/canon_guard.py` или в действующей
реализации, **ТЗ считается устаревшим** и подлежит обновлению.

Запрещено вносить изменения в код, которые нарушают архитектурные
запреты, даже если ТЗ это допускает.

## LOCK: NO SYMPTOM PATCHES

Запрещено «лечить симптомы» точечными подгонками
(роуты/адаптеры/алиасы), если первопричина — несогласованный контракт,
дублирующаяся логика, разные форматы данных/курсорa, разные источники
истины.

Любое исправление обязано: 1) устранять первопричину в едином источнике
истины (SSOT), и 2) добавлять автоматическую проверку (guard/test),
чтобы проблема не вернулась.

Запрещённые примеры «симптом‑латок»:
- менять импорт в одном файле, если общий контракт слоя не определён
- добавлять преобразование DTO в роуте, если DTO не стандартизирован
  SSOT
- менять формат курсора в одном месте, если курсор не унифицирован
- включать идемпотентность в одном endpoint без обновления SSOT policy и
  guard

Разрешённый (каноничный) подход:
- фикс через SSOT: contracts / standards / utils codecs / db canon /
  guard rules
- массовая синхронизация всех зависимых мест одной миграцией/рефактором
- фиксация регрессии в guard + тест

## LOCK: PYTHON PACKAGES MUST BE IMPORTABLE

1) Директории Python‑пакетов обязаны содержать `__init__.py`.

2) Запрещено «лечить» падение импорта PYTHONPATH‑костылями.

3) Любой PR, где исчез `__init__.py`, считается нарушением канона — CI
обязан падать.

SSOT‑правило пакетности: Если директория содержит `.py` файлы (и это не
`tests`, не `migrations/versions`, не `__pycache__` и не исключение по
правилам guard), то это пакет → `__init__.py` обязателен.

Явный SSOT‑список обязательных `__init__.py` (обязателен, если
директория существует):

- `backend/__init__.py`
- `backend/app/__init__.py`
- `backend/app/routes/__init__.py`
- `backend/app/services/__init__.py`
- `backend/app/crud/__init__.py`
- `backend/app/models/__init__.py`
- `backend/app/schemas/__init__.py`
- `backend/app/utils/__init__.py`
- `backend/app/contracts/__init__.py`
- `backend/app/standards/__init__.py`
- `backend/app/db/__init__.py` (если папка существует)
- `backend/migrations/__init__.py`
- `backend/migrations/versions/__init__.py` (только если папка
  используется как python‑модуль; иначе исключается в правилах guard)

## LOCK: SETTINGS SSOT

Любые derived‑поля/нормализации (например, `env_normalized`) должны
определяться **в одном месте**: `backend/app/core/config_core.py` →
`class Settings`.

Запрещено:
- вычислять env/alias/derived‑поля «по месту» в модулях
- добавлять «латки» в логирование/утилиты вместо SSOT‑свойства Settings

## LOCK: CURSOR CODEC SSOT

Курсоры пагинации — только через `backend/app/utils/cursor_codec.py`.

Инварианты:
- `decode_cursor(cursor)` **всегда** возвращает `dict`
- `encode_cursor(payload)` принимает **только** `dict`
- запрещены tuple‑курсоры (`encode_cursor((...))`)
- запрещена распаковка `a, b = decode_cursor(...)`
- запрещены локальные реализации encode/decode курсоров вне
  `cursor_codec.py`

Этот файл — «конституция запретов» проекта EFHC Bot.

## LOCK: BONUS_EFHC_FULL_SPEND__WITHDRAW_MAIN_ONLY

**Канон:** `bonus_balance` — это полноценный платёжный баланс **для
любых внутренних покупок** (панели, магазин, билеты, услуги).

**SSOT правило списания:** при любой оплате EFHC списание всегда идёт
**bonus → main** (bonus-first), если иное не задано явным SSOT-правилом.

**Жёсткое ограничение:** вывод (withdraw) разрешён **только из
`main_balance`**. Использование `bonus_balance` в контуре вывода
запрещено.

**Требования к реализации:**
- Любая операция оплаты EFHC использует единый контур списаний
  (bank/transactions), соблюдает d8 и ROUND_DOWN.
- Любой денежный POST/админ-денежное действие требует `Idempotency-Key`
  согласно MUST списку SSOT.
- UI обязан показывать `bonus`, `main`, `total`, а в Withdraw отдельно
  `available_to_withdraw = main`.
Нарушение любого пункта = ошибка. Сборка/CI обязаны падать.

## LOCK: TOTAL_GENERATED_KWH_APPEND_ONLY

**Канон экономики (SSOT):** `total_generated_kwh` — это lifetime‑энергия
(append‑only), монотонно неубывающая величина.

**Запрещено** любым действием/операцией/сервисом уменьшать
`total_generated_kwh`.

Любые «списания»/переносы выполняются только через накопительный
«минус‑обмен» и производное значение:

- `exchanged_kwh_total` (накопительно, монотонно растёт)
- `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`

**EXCHANGE_ALL** увеличивает `exchanged_kwh_total` и `main_balance`, но
**никогда** не уменьшает `total_generated_kwh`.

Инварианты:
- `total_generated_kwh(t+Δ) >= total_generated_kwh(t)`
- `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`

## 1) Абсолютные запреты (ABSOLUTE BAN)

### 1.1 Запрещён токен (буквы): l o t t e r y
Запрещено любое появление последовательности букв **l o t t e r y** (без
пробелов) в любом месте репозитория:
- код, комментарии, строки SQL
- docs, tests
- миграции
- имена файлов/папок
- имена объектов БД (схемы/таблицы/колонки/индексы/constraints)

Критерий: Canon Guard должен возвращать **0 нарушений**.

## 2) Канон терминов

### 2.1 Подсистема розыгрышей
В проекте используется термин **draws** (и производные), без
запрещённого токена.

### 2.2 Идентификатор пользователя
Единственная истина во внешнем слое: **tg_id**. Публичные API **не
принимают** и **не возвращают** `tg_id`. "Кто я" определяется только
авторизацией Telegram (initData/session) → `tg_id`.

## 3) DB CANON

Схема: `efhc_draws`

Таблицы:
- `draws`
- `draws_tickets`
- `draws_results`
- `draws_user_stats`
- `draws_nft_claims`

Колонки:
- `tg_id` (везде, где привязка к пользователю)
- `draws_id` (вместо любых исторических *_id)
- `restart_of_draws_id` (для автоклона)

Индексы/constraints/FK/PK: не содержат запрещённого токена.

## 4) PUBLIC API LOCK

Запрещено:
- path/query/body поля `tg_id`
- любые пути `/...` и поля, содержащие запрещённый токен

Разрешено:
- идентификация пользователя только через auth → `tg_id`

## 5) IDEMPOTENCY LOCK

Идемпотентность **разрешена и желательна почти везде** (особенно для
POST/PATCH/DELETE), но **обязательность** определяется **строгим
SSOT-списком критичных команд**.

### 5.1 Классы эндпоинтов

**Класс A (MUST-IDK)** — `Idempotency-Key` обязателен по SSOT списку
путей. Это команды, которые меняют состояние и могут прямо/косвенно
повлиять на деньги (сейчас или позже), включая запуск автоматизаций
(autorun) и любые админские действия, способные изменить финансовые
состояния.

**Класс B (SHOULD-IDK)** — `Idempotency-Key` желателен (guard
предупреждает, но не валит сборку).

**Класс C (EXTERNAL-ID)** — внешние callbacks/webhooks. Для них
`Idempotency-Key` **не требуем**: вместо этого используется
идемпотентность по внешнему `event-id`/`delivery-id`.

### 5.2 SSOT для MUST-IDK

SSOT хранится в `ops/canon_rules.yaml` →
`idempotency.must_path_patterns`.

### 5.3 Единый стандарт

- MUST-IDK: используется только `Depends(require_idempotency_key)`
- SHOULD-IDK: при наличии используется `Depends(accept_idempotency_key)`
- EXTERNAL-ID: требуется dedupe по `event-id` (processed-events) и
  **запрещён** `require_idempotency_key`

Локальные реализации идемпотентности запрещены.

## 6) LOCK: DRAWS AUTO-CYCLE ONLY

Инвариант: draws — самоцикличный процесс.

1) Покупка последнего билета (sold-out) при `auto_draw=true` → **draw
сразу**. 2) Победитель определён → **приз выдан сразу** (EFHC) или
создана **claim-заявка** (NFT). 3) Сразу создан новый активный draw
(restart).

Запрет:
  - Планировщик draws **не является источником истины** и не
    используется для запуска draw по sold-out.
  - Любые `scheduler/*draws*.py` в репозитории считаются нарушением и
    должны валить сборку guard’ом.

Управление:
  - Единственный выключатель цикличности — админ-тумблер
    `auto_draw=false`.

## 7) LOCK: NO TICKET PURCHASE WITHOUT WALLET (NFT)

Инвариант: для draw с `prize_type=NFT` покупка билета невозможна без
кошелька.

Допустимые источники кошелька:
  - `users.ton_wallet` уже привязан
  - `payload.wallet_address` при покупке (если валиден) → допускается
    автопривязка

Запрет:
  - Никаких «потом спросим» и «потом разрулим» без адреса: покупка
    должна быть отклонена.

## 7.1) LOCK: DRAWS WINNER RANDOMNESS (CODE-ONLY)

Инвариант: выбор победителя должен быть **реально случайным** и
выполняться **только внутри нашего кода**.

SSOT-реализация:

- При проведении draw код генерирует CSPRNG‑seed (32 bytes), сохраняет
  его в `draw_results.winner_seed_hex`.
- Из seed вычисляется индекс победителя (sha256(seed + draw_id) → idx),
  затем выбирается билет по `ORDER BY ticket_id ASC OFFSET idx`.
- Повторный запуск draw (retry) **не меняет победителя**: используется
  сохранённый `DrawResult`.

Запрет:

- Запрещены DB‑функции случайности (например, `ORDER BY random()` и
  аналоги) в любых SQL.
- Запрещена «рандомность из клиента» (никаких seed/nonce от
  пользователя).
- Idempotency выдачи приза должна быть привязана к `draw_id` (например,
  `DRAW:{draw_id}:PRIZE`).

### Каноничные пути/интерфейсы

- Тумблер autorun:
  - POST `/admin/draws/{draw_id}/auto-draw`
- Денежная покупка билетов:
  - POST `/draws/{draw_id}/buy` (MUST Idempotency-Key)

## 8) Canon Guard обязателен

Перед тестами и деплоем всегда запускать:

```bash
python ops/canon_guard.py
```


## LOCK: TG_ID ONLY EVERYWHERE (INCLUDING ADMIN)

## LOCK: UI NAVBAR FIXED (6 TABS, ORDER)

**Запрет:** менять состав/порядок нижней навигации.

**Канон (ровно 6 вкладок, фиксированный порядок):** 1) Energy 2) Panels
3) Exchange 4) Tasks 5) Referrals 6) Ranks

Любые изменения допускаются только через обновление ТЗ/SSOT + guard.

## LOCK: UI LABELS ALWAYS ENGLISH

**Запрет:** локализовать кнопки/лейблы/названия вкладок/уровней.

**Канон:**
- UI labels (tabs/buttons/field labels) — **всегда EN**.
- Levels / ranks names — **всегда EN**.
- Выбор языка влияет **только** на descriptions/описания.

## LOCK: PROFILE/SETTINGS ENTRYPOINT + SSOT SETTINGS LIST

**Канон входа:** Profile/Settings открывается **по нажатию на аватар** в
левом верхнем углу.

**SSOT список настроек (утверждён):** 1) Telegram display name (RO) 2)
Username (RO) 3) VIP badge (RO) 4) Avatar (Telegram default + custom +
reset) 5) Descriptions language (13 langs, EN first) 6) UI sounds
(on/off) 7) Sound volume 8) Sound pack 9) Haptics (on/off) 10) Hide
balances 11) Show decimal detail (still 8 decimals) 12) Reduce motion
13) Confirm before purchase 14) Confirm before withdraw request 15)
Confirm before convert kWh→EFHC 16) Confirm before watch ad 17) In-app
toasts 18) Important alerts only 19) FAQ 20) Support chat 21) Terms 22)
Privacy 23) Reset settings

## LOCK: ADMIN ENTRY VIA PROFILE (TG-ID ALLOWLIST)

**Канон:** кнопка/пункт **Admin Panel** видна только если `tg_id` входит
в SSOT allowlist (`NEXT_PUBLIC_ADMIN_tg_idS`), и отображается
**только** внутри Profile/Settings.

- В HTTP-слое (routes/schemas/logs) единственный идентификатор
  пользователя — `tg_id`.
- `tg_id` запрещён везде, включая admin-контур.
- Если нужен внутренний PK БД, используйте нейтральное имя
  `user_pk`/`row_id` и НЕ прокидывайте его наружу.
- Админ-авторизация и allowlist — только по `tg_id` (Settings/ENV).

## Migrations numbering canon

- Правила нумерации: backend/migrations/MIGRATION_RULES.md
- Требование: backend/migrations/versions/NNNN_description.py
- revision == "NNNN", down_revision цепочкой без разрывов.

## Skins canon (Level + Shop)

- Level skins are earned and derived from
  `profile.total_generated_kwh`.
- Level skins control only the UI palette via CSS vars:
  `--gold`, `--gold-2`, `--energy`.
- Shop skins are optional and control only the background image.
- The frontend must combine them:
  - Palette: Level skin.
  - Background: active Shop skin, if any.
- Shop buy/activate must trigger a refresh of active background
  (event: `efhc_shop_skin_changed`).
