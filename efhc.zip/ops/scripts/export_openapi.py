# Export OpenAPI JSON from FastAPI app

