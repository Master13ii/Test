from __future__ import annotations

import ast
import io
import re
import tokenize
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


# Safe, targeted replacements inside STRING tokens.
REPLACEMENTS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"Content\s-\sDisposition"), "Content-Disposition"),
    (re.compile(r"Idempotency\s-\sKey"), "Idempotency-Key"),
    (re.compile(r"If\s-\sNone\s-\sMatch"), "If-None-Match"),
    (re.compile(r"utf\s-\s8"), "utf-8"),
)


def _fix_route_like_hyphens(s: str) -> str:
    # Fix broken hyphens in URL-like segments, e.g. "/by - telegram".
    if "/" not in s:
        return s
    # Replace ' - ' between word chunks when string contains a path.
    return re.sub(r"(?<=\w)\s-\s(?=\w)", "-", s)


def _iter_py_files() -> list[Path]:
    roots = [
        REPO_ROOT / "backend",
        REPO_ROOT / "ops",
        REPO_ROOT / "tests",
    ]
    files: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*.py"):
            is_ignored = any(
                part in {"alembic", "migrations", "__pycache__"}
                for part in path.parts
            )
            if is_ignored:
                continue
            files.append(path)
    return files


def _rewrite_file(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    changed = False

    out_tokens: list[tokenize.TokenInfo] = []
    buf = io.StringIO(text)
    tokens = list(tokenize.generate_tokens(buf.readline))

    for tok in tokens:
        if tok.type != tokenize.STRING:
            out_tokens.append(tok)
            continue

        try:
            value = ast.literal_eval(tok.string)
        except Exception:
            out_tokens.append(tok)
            continue

        if not isinstance(value, str):
            out_tokens.append(tok)
            continue

        new_value = value
        new_value = _fix_route_like_hyphens(new_value)
        for pattern, repl in REPLACEMENTS:
            new_value = pattern.sub(repl, new_value)

        if new_value != value:
            changed = True
            # Keep original quoting style by using repr.
            new_tok = tokenize.TokenInfo(
                type=tokenize.STRING,
                string=repr(new_value),
                start=tok.start,
                end=tok.end,
                line=tok.line,
            )
            out_tokens.append(new_tok)
        else:
            out_tokens.append(tok)

    if not changed:
        return False

    new_text = tokenize.untokenize(out_tokens)
    path.write_text(new_text, encoding="utf-8")
    return True


def main() -> None:
    changed_files = 0
    for path in _iter_py_files():
        if _rewrite_file(path):
            changed_files += 1
    print(f"fixed_files={changed_files}")


if __name__ == "__main__":
    main()
