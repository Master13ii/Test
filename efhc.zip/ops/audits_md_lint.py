#!/usr/bin/env python3
"""
CI linter for docs/audits/*.md.

Validates:
- canonical filename
- SSOT header keys (Audit-Id, Date, Version, Topic,
  Status, Superseded-By, Confidence)
  Scope, Sources, Owner, Confidence)
- section order
- Findings/Decisions have [[EV-###]] references
- Evidence Index contains referenced EV ids
- forbidden tokens absent
- Appendix size hygiene
- max line length (72)
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUD_DIR = ROOT / "docs" / "audits"

TOPICS = {
  "db-inventory","db-ssot","routes-inventory","admin-surface",
  "ci-failures","guards-ssot","security","performance","data-migration",
}
STATUS = {"ACTIVE","SUPERSEDED","ARCHIVED"}
CONF = {"HIGH","MEDIUM"}

FILENAME_RE = re.compile(
    r"^(?P<date>\d{4}-\d{2}-\d{2})_(?P<topic>[a-z0-9\-]+)"
    r"_v(?P<ver>\d+_\d+)__(?P<slug>[a-z0-9_]{3,60})\.md$"
)

HEADER_KEYS = [
  "Audit-Id","Date","Version","Topic","Status","Superseded-By",
  "Scope","Sources","Owner","Confidence",
]

SECTIONS = [
  "## Executive Summary",
  "## Findings (FACTS)",
  "## Evidence Index",
  "## Decisions (SSOT)",
  "## Actions (P0/P1/P2)",
  "## Impact & Risks",
  "## Verification",
  "## Appendix: Raw Extract (optional)",
]

FORBIDDEN = [
  re.compile(r"citeturn", re.I),
  re.compile(r"oaicite", re.I),
  re.compile(r"turn\d+view", re.I),
  re.compile(r"BEGIN:VCALENDAR", re.I),
]

EV_REF_RE = re.compile(r"\[\[(EV-\d{3})\]\]")
EV_LINE_RE = re.compile(r"^(EV-\d{3})\s*\|", re.M)

def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(2)

def warn(msg: str) -> None:
    print(f"WARN: {msg}", file=sys.stderr)

def main() -> None:
    if not AUD_DIR.exists():
        die("docs/audits/ missing")

    md_files = [
        p for p in AUD_DIR.glob("*.md")
        if p.name != "README.md"
    ]
    if not md_files:
        die("No audit md files found in docs/audits/")

    for p in sorted(md_files):
        name = p.name
        m = FILENAME_RE.match(name)
        if not m:
            die(f"Bad audit filename: {name}")

        topic = m.group("topic")
        if topic not in TOPICS:
            die(f"{name}: topic not allowed: {topic}")

        text = p.read_text(encoding="utf-8")
        lines = text.splitlines()

        # max line length 72 (strict)
        for i, ln in enumerate(lines, start=1):
            if len(ln) > 72:
                die(f"{name}:{i}: line longer than 72 chars")

        # forbidden tokens
        for rx in FORBIDDEN:
            if rx.search(text):
                die(f"{name}: forbidden token matched: {rx.pattern}")

        # header parse (first block until blank line)
        header = {}
        idx = 0
        while idx < len(lines) and lines[idx].strip():
            line = lines[idx]
            if ":" not in line:
                die(f"{name}: bad header line: {line}")
            k, v = line.split(":", 1)
            header[k.strip()] = v.strip()
            idx += 1

        for k in HEADER_KEYS:
            if k not in header:
                die(f"{name}: missing header key: {k}")

        if header["Topic"] not in TOPICS:
            die(f"{name}: header Topic not allowed: {header['Topic']}")

        if header["Status"] not in STATUS:
            die(f"{name}: header Status invalid: {header['Status']}")

        if header["Confidence"] not in CONF:
            die(
                f"{name}: header Confidence invalid: "
                f"{header['Confidence']}"
            )

        if header["Status"] == "SUPERSEDED" and (
            header["Superseded-By"] in ("", "null")
        ):
            die(f"{name}: SUPERSEDED requires Superseded-By")

        # section order
        pos = []
        for s in SECTIONS:
            pidx = text.find(s)
            if pidx == -1:
                die(f"{name}: missing section: {s}")
            pos.append(pidx)
        if pos != sorted(pos):
            die(f"{name}: sections out of order")

        # EV references in Findings + Decisions
        def section_text(
            start_heading: str,
            end_heading: str,
            _text: str = text,
        ) -> str:
            sidx = _text.find(start_heading)
            eidx = _text.find(end_heading)
            if sidx == -1 or eidx == -1:
                return ""
            return _text[sidx:eidx]

        findings = section_text(SECTIONS[1], SECTIONS[2])
        decisions = section_text(SECTIONS[3], SECTIONS[4])
        ev_refs = set(EV_REF_RE.findall(findings + decisions))
        if not ev_refs:
            die(
                f"{name}: no [[EV-###]] references in "
                "Findings/Decisions"
            )

        # Evidence Index must contain all referenced EV ids
        evidence = section_text(SECTIONS[2], SECTIONS[3])
        ev_defined = set(EV_LINE_RE.findall(evidence))
        missing = sorted(ev_refs - ev_defined)
        if missing:
            die(f"{name}: EV ids referenced but not defined: {missing}")

        # Appendix hygiene: max 50 consecutive lines (should be
        # references)
        appendix = text[text.find(SECTIONS[7]):]
        # crude check for big dumps
        run = 0
        for ln in appendix.splitlines():
            if ln.strip():
                run += 1
                if run > 50:
                    die(
                        f"{name}: appendix has >50 consecutive "
                        "non-empty lines"
                    )
            else:
                run = 0

    print("OK: audits md lint passed")

if __name__ == "__main__":
    main()
