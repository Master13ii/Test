#!/usr/bin/env python3
"""
Generate docs/audits/README.md from docs/audits/audits_index.json.
"""
from __future__ import annotations

import json
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "docs" / "audits" / "audits_index.json"
README = ROOT / "docs" / "audits" / "README.md"

def wrap72(s: str) -> str:
    out=[]
    for ln in s.splitlines():
        if not ln.strip():
            out.append("")
            continue
        if (
            ln.startswith("#")
            or ln.startswith(">")
            or ln.startswith("|")
        ):
            out.append(ln.rstrip())
            continue
        out.extend(textwrap.fill(ln.strip(), width=72).splitlines())
    return "\n".join(out).rstrip()+"\n"

def table(items):
    if not items:
        return "_None._\n"
    lines=[
      (
          "| Audit-Id | Date | Topic | Scope-Key | Version | File | "
          "Summary |"
      ),
      "|---|---|---|---|---|---|---|",
    ]
    for a in items:
        md=a["files"]["md"]
        lines.append(
          f"| {a['audit_id']} | {a['date']} | {a['topic']} | "
          f"{a.get('scope_key','')} | {a['version']} | "
          f"[md]({md}) | {a['summary']} |"
        )
    return "\n".join(lines)+"\n"

def main():
    data=json.loads(INDEX.read_text(encoding="utf-8"))
    audits=data["audits"]
    active=[a for a in audits if a["status"]=="ACTIVE"]
    supers=[a for a in audits if a["status"]=="SUPERSEDED"]
    arch=[a for a in audits if a["status"]=="ARCHIVED"]

    active = sorted(
        active,
        key=lambda x: (
            x["topic"],
            x.get("scope_key") or "",
            x["audit_id"],
        ),
    )
    supers = sorted(
        supers,
        key=lambda x: (
            x["topic"],
            x.get("scope_key") or "",
            x["audit_id"],
        ),
    )
    arch = sorted(
        arch,
        key=lambda x: (
            x["topic"],
            x.get("scope_key") or "",
            x["audit_id"],
        ),
    )

    topics="\n".join([f"- `{t}`" for t in data["topics"]])

    body=f"""# EFHC Audits

> AUTO-GENERATED from audits_index.json. Do not edit by hand.

## ACTIVE

{table(active)}

## SUPERSEDED

{table(supers)}

## ARCHIVED

{table(arch)}

## Topics dictionary

{topics}

## How to add a new audit

1. Create md file in docs/audits/ with canonical name:
   YYYY-MM-DD_<topic>_v<repo_version>__<short_slug>.md
2. Fill SSOT header + required sections + Evidence Index.
3. Add entry to audits_index.json.
4. Run:
   - python ops/audits_index_lint.py
   - python ops/audits_md_lint.py
5. Regenerate this README:
   - python ops/audits_readme_generate.py
"""
    README.write_text(wrap72(body), encoding="utf-8")

if __name__ == "__main__":
    main()
