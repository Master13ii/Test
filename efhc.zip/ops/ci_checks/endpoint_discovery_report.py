import csv
from pathlib import Path


def _read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main() -> int:
    root = Path(__file__).resolve().parents[2]
    pack = root / "docs" / "ssot_pack"
    tables_path = pack / "SSOT_TABLES_ORM.csv"
    map_path = pack / "SSOT_ROUTE_TABLE_MAP.csv"

    print("Endpoint discovery (report-only)")
    print("tables:", tables_path)
    print("map:", map_path)

    if not tables_path.exists() or not map_path.exists():
        print("WARN: SSOT pack missing, skipping")
        return 0

    tables = _read_rows(tables_path)
    mapped = _read_rows(map_path)

    expected: set[str] = set()
    for row in tables:
        schema = (row.get("schema") or "").strip()
        table = (row.get("table") or "").strip()
        if schema and table:
            expected.add(f"{schema}.{table}")

    seen: set[str] = set()
    for row in mapped:
        schema = (row.get("schema") or "").strip()
        table = (row.get("table") or "").strip()
        if schema and table:
            seen.add(f"{schema}.{table}")

    missing = sorted(expected - seen)
    print("tables_total:", len(expected))
    print("tables_mapped:", len(seen))
    print("tables_missing:", len(missing))
    if missing:
        for name in missing:
            print("MISSING:", name)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
