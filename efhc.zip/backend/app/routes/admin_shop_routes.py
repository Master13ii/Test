# backend/app/routes/admin_shop_routes.py
# ======================================================================
# EFHC Bot — Admin: Shop
# ----------------------------------------------------------------------
# Назначение:
# Админские ручки магазина: управление ценами карточек и обзор заказов.
#
# Канон:
# • Только tg_id во внешнем слое.
# • Настройки/цены — админ‑операции, требуют Idempotency-Key.
# ======================================================================

from __future__ import annotations

from decimal import Decimal
from typing import Any

from app.deps import (
    get_db,
    require_admin,
    require_idempotency_key_header_only,
)
from app.services.admin.admin_shop_service import (
    admin_list_orders,
    admin_set_price,
)
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/admin/shop", tags=["admin:shop"])


class SetPriceIn(BaseModel):
    code: str = Field(..., min_length=1, max_length=64)
    price_efhc: Decimal | None = None
    price_ton: Decimal | None = None
    price_usdt: Decimal | None = None
    pay_currencies: list[str] | None = None
    is_active: bool | None = None


@router.get("/orders")
async def admin_orders(
    limit: int = Query(default=50, ge=1, le=200),
    cursor: str | None = None,
    status: str | None = None,
    item_type: str | None = None,
    tg_id: int | None = None,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
) -> dict[str, Any]:
    """Админский список заказов магазина с курсорной пагинацией."""
    try:
        return await admin_list_orders(
            db,
            limit=int(limit),
            cursor=cursor,
            status=status,
            item_type=item_type,
            tg_id=tg_id,
        )
    except Exception as e:
        raise HTTPException( from e
            status_code=500,
            detail=(
                f"admin orders failed: {e}"
            ),
        )


@router.post("/items/set-price")
async def admin_set_item_price(
    payload: SetPriceIn,
    db: AsyncSession = Depends(get_db),
    _auth: Any = Depends(require_admin),
    _idk: str = Depends(require_idempotency_key_header_only),
) -> dict[str, Any]:
    """Обновить цену/валюты оплаты товара (по code)."""
    try:
        return await admin_set_price(
            db,
            code=payload.code,
            price_efhc=payload.price_efhc,
            price_ton=payload.price_ton,
            price_usdt=payload.price_usdt,
            pay_currencies=payload.pay_currencies,
            is_active=payload.is_active,
        )
    except Exception as e:
        raise HTTPException( from e
            status_code=500,
            detail=(
                f"admin set price failed: {e}"
            ),
        )
