# backend/app/routes/nft_routes.py
# =====================================================================
# Read-only эндпоинты NFT/VIP: проверка наличия NFT у кошелька.
# Никакой выдачи/доставки NFT здесь нет.
# =====================================================================

from __future__ import annotations

from app.core.config_core import get_settings
from app.integrations.nft_api import wallet_has_nft_in_collection
from fastapi import APIRouter, HTTPException, Query

settings = get_settings()
router = APIRouter(prefix="/nft", tags=["nft"])


@router.get("/has_vip")
async def has_vip_nft(
    wallet: str = Query(..., description="TON wallet address"),
) -> dict:
    collection = getattr(settings, "VIP_NFT_COLLECTION", None)
    if not collection:
        raise HTTPException(
            status_code=500,
            detail="VIP_NFT_COLLECTION not configured",
        )
    ok = await wallet_has_nft_in_collection(
        wallet_address=wallet,
        collection_address=collection,
    )
    return {
        "wallet": wallet,
        "collection": collection,
        "has_vip": bool(ok),
        "has_nft": bool(ok),
    }
