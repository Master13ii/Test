# backend/app/routes/ads_routes.py
# =====================================================================
# EFHC Bot — Роуты рекламы (rewarded ads)
# ---------------------------------------------------------------------
# Что делает модуль:
# • GET  /ads/slot — выдаёт слот рекламы для пользователя.
#   - provider=builtin_timer → подписанный токен для фронта.
#   - provider=adsgram → конфиг/placement для мини-аппа Adsgram.
#   Выбор: ?provider=..., иначе берём первый включённый.
#
# • POST /ads/callback/{provider} — приём колбэков провайдера:
#   - verify через integrations/ads_providers.py
#   - начисление ИДЕМПОТЕНТНО через
#     tasks_service.confirm_ad_view_and_credit(...)
#
# Канон/инварианты:
# • Денежные операции — только через tasks_service (bonus_balance).
# • Идемпотентность: provider_ref → idempotency_key.
# • Суммы: Decimal с 8 знаками, округление вниз.
# • P2P нет; только «пользователь ↔ банк».
#
# Идентификация пользователя:
# 1) Telegram WebApp initData (заголовок X-Telegram-Init-Data).
# 2) Запасной tg_id (query/body) — если initData недоступна.
# =====================================================================

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import ROUND_DOWN, Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8, etag, get_current_tg_id, get_db
from app.integrations.ads_providers import (
    get_verified_event,
    issue_builtin_timer_token,
)
from app.services.tasks_service import (
    confirm_ad_view_and_credit,
)
from fastapi import (
    APIRouter,
    Depends,
    Header,
    HTTPException,
    Request,
    Response,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# ---------------------------------------------------------------------
# Конфиги провайдеров (из env)
# ---------------------------------------------------------------------

_ENABLED_RAW = getattr(
    settings,
    "ADS_ENABLED_PROVIDERS",
    "adsgram,builtin_timer",
)
ENABLED = [x.strip() for x in str(_ENABLED_RAW).split(",") if x.strip()]
DEFAULT_PROVIDER = ENABLED[0] if ENABLED else "builtin_timer"

BUILTIN_TTL_SEC = int(
    getattr(settings, "ADS_BUILTIN_TOKEN_TTL_SEC", 600) or 600
)
BUILTIN_MIN_VIEW_SEC = int(
    getattr(settings, "ADS_BUILTIN_MIN_VIEW_SEC", 20) or 20
)
ADSGRAM_PLACEMENT_ID = getattr(settings, "ADSGRAM_PLACEMENT_ID", None)

Q8 = Decimal("0.00000001")

HDR_TG_INIT = "X-Telegram-Init-Data"


class AdSlotOut(BaseModel):
    provider: str = Field(..., description="adsgram | builtin_timer")
    task_code: str
    tg_id: int
    reward_bonus_efhc: str

    # builtin_timer
    token: str | None = Field(
        None,
        description="Подписанный токен (builtin_timer)",
    )
    expires_at: str | None = Field(
        None,
        description="ISO-время истечения токена (builtin_timer)",
    )
    min_view_sec: int | None = Field(
        None,
        description="Минимальное время просмотра (builtin_timer)",
    )

    # adsgram
    placement_id: str | None = Field(
        None,
        description="ID плейсмента Adsgram (если задан)",
    )


class AdCallbackResultOut(BaseModel):
    ok: bool
    provider: str
    task_code: str
    provider_ref: str
    reward_bonus_efhc: str
    replayed: bool = False


router = APIRouter(prefix="/ads", tags=["ads"])


@router.get(
    "/slot",
    response_model=AdSlotOut,
    summary="Выдать слот рекламы (token/config) для пользователя",
)
async def get_ad_slot(
    request: Request,
    response: Response,
    task_code: str,
    provider: str | None = None,
    tg_id: int = Depends(get_current_tg_id),
    db: AsyncSession = Depends(get_db),
):
    """Выдаёт слот рекламы: builtin_timer или adsgram."""

    _ = request

    prov = (provider or DEFAULT_PROVIDER).strip().lower()
    if prov not in ENABLED:
        raise HTTPException(
            status_code=400,
            detail=f"Провайдер '{prov}' не активен",
        )

    sql = (
        "SELECT task_code, reward_bonus_efhc, is_active, type, meta "
        f"FROM {SCHEMA}.tasks "
        "WHERE task_code = :code "
        "LIMIT 1"
    )
    row = (await db.execute(text(sql), {"code": task_code})).fetchone()
    if not row:
        raise HTTPException(
            status_code=404,
            detail="Задание не найдено",
        )
    if not bool(row[2]):
        raise HTTPException(status_code=400, detail="Задание отключено")
    if str(row[3] or "") != "watch_ad":
        raise HTTPException(
            status_code=400,
            detail="Неверный тип задания (ожидается watch_ad)",
        )

    reward = Decimal(str(row[1])).quantize(Q8, rounding=ROUND_DOWN)

    if prov == "builtin_timer":
        token = issue_builtin_timer_token(
            tg_id=tg_id,
            task_code=task_code,
            reward_bonus_efhc=reward,
            ttl_sec=BUILTIN_TTL_SEC,
        )
        exp_iso = (
            datetime.now(tz=UTC)
            + timedelta(seconds=BUILTIN_TTL_SEC)
        ).isoformat()
        et = etag(
            f"slot:{tg_id}:{task_code}:{prov}:{reward}:{exp_iso}"
        )
        if request.headers.get("If-None-Match") == et:
            response.status_code = status.HTTP_304_NOT_MODIFIED
            response.headers["ETag"] = et
            return
        response.headers["ETag"] = et
        return AdSlotOut(
            provider="builtin_timer",
            task_code=task_code,
            tg_id=tg_id,
            reward_bonus_efhc=str(d8(reward)),
            token=token,
            expires_at=exp_iso,
            min_view_sec=BUILTIN_MIN_VIEW_SEC,
        )

    placement_id = ADSGRAM_PLACEMENT_ID
    et = etag(
        f"slot:{tg_id}:{task_code}:{prov}:{reward}:{placement_id or ''}"
    )
    if request.headers.get("If-None-Match") == et:
        response.status_code = status.HTTP_304_NOT_MODIFIED
        response.headers["ETag"] = et
        return
    response.headers["ETag"] = et
    return AdSlotOut(
        provider="adsgram",
        task_code=task_code,
        tg_id=tg_id,
        reward_bonus_efhc=str(d8(reward)),
        placement_id=(placement_id or None),
    )


@router.post(
    "/callback/{provider}",
    response_model=AdCallbackResultOut,
    summary="Колбэк провайдера рекламы (идемпотентное начисление)",
)
async def ads_callback(
    provider: str,
    request: Request,
    response: Response,
    body: dict[str, Any],
    db: AsyncSession = Depends(get_db),
    idempotency_key_hdr: str | None = Header(
        default=None,
        convert_underscores=False,
        alias="Idempotency-Key",
    ),
):
    """Verify у провайдера → начисление через tasks_service."""

    client_ip = request.client.host if request.client else None

    try:
        evt = await get_verified_event(
            provider,
            payload=body or {},
            headers=dict(request.headers),
            client_ip=client_ip,
        )
    except ValueError as e:
        reason = str(e)
        forbidden = {
            "provider_disabled",
            "ip_not_allowed",
            "missing_token",
            "token_expired",
            "signature_mismatch",
            "token_signature_mismatch",
            "missing_signature",
            "hash_mismatch",
            "invalid_tg_id",
        }
        code = 403 if reason in forbidden else 400
        raise HTTPException(status_code=code, detail=reason) from e
    except Exception as e:
        logger.error(
            "ads.callback verify failed prov=%s",
            provider,
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail="internal_error") from e

    idk = evt.idempotency_key
    if idempotency_key_hdr and idempotency_key_hdr.strip():
        hdr = idempotency_key_hdr.strip()
        idk = f"{evt.idempotency_key}|hdr:{hdr}"

    try:
        result = await confirm_ad_view_and_credit(
            db,
            tg_id=int(evt.tg_id),
            task_code=str(evt.task_code),
            provider=str(evt.provider),
            provider_ref=str(evt.provider_ref),
            reward_bonus_efhc=evt.reward_bonus_efhc,
            idempotency_key=idk,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            "ads.callback credit failed prov=%s tg_id=%s task=%s",
            provider,
            evt.tg_id,
            evt.task_code,
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail="credit_failed") from e

    replayed = bool(result.get("replayed", False))
    et = etag(
        f"ads_cb:{evt.provider}:{evt.provider_ref}:"
        f"{evt.tg_id}:{evt.task_code}:{replayed}"
    )
    response.headers["ETag"] = et

    return AdCallbackResultOut(
        ok=True,
        provider=str(evt.provider),
        task_code=str(evt.task_code),
        provider_ref=str(evt.provider_ref),
        reward_bonus_efhc=str(
            d8(result.get("reward_bonus_efhc", evt.reward_bonus_efhc))
        ),
        replayed=replayed,
    )
