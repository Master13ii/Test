# backend/app/routes/payment_intents_routes.py
# ----------------------------------------------------------------------
# Payment intents status (owner-only).
# Используется для UX "ожидание подтверждения".
# ----------------------------------------------------------------------

from __future__ import annotations

from app.deps import get_current_tg_id, get_db
from app.schemas.payment_intents_schemas import (
    PaymentIntentStatusOut,
)
from app.services.payment_intents_service import (
    get_intent_status_for_user,
)
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/payment-intents", tags=["payment_intents"])


@router.get(
    "/{intent_id}",
    response_model=PaymentIntentStatusOut,
    summary="Get payment intent status (owner-only)",
)
async def get_payment_intent_status(
    intent_id: int,
    db: AsyncSession = Depends(get_db),
    tg_id: int = Depends(get_current_tg_id),
) -> PaymentIntentStatusOut:
    row = await get_intent_status_for_user(
        db,
        tg_id=int(tg_id),
        intent_id=int(intent_id),
    )
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"code": "INTENT_NOT_FOUND"},
        )
    return PaymentIntentStatusOut(**row)
