# backend/app/routes/tasks_routes.py
# ======================================================================
# EFHC Bot — Tasks: каталог, статусы пользователя, получение наград.
#
# Канон:
# - Денежные операции (в т.ч. бонусы) только через банковский сервис.
# - Все денежные POST требуют заголовок Idempotency-Key.
# - Пагинация списков строго cursor-based.
# - Здесь нет генерации, только бонусы за задания.
# ======================================================================

from __future__ import annotations

from typing import Any

from app.core.logging_core import get_logger
from app.deps import (
    d8,
    get_current_tg_id,
    get_db,
    make_etag,
    require_idempotency_key,
)
from app.services.tasks_service import (
    claim_task_reward,
    list_tasks_catalog,
    list_user_tasks,
)
from app.utils.cursor_codec import decode_cursor, encode_cursor
from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(prefix="/tasks", tags=["tasks"])


class TaskItem(BaseModel):
    id: int
    code: str
    title: str
    description: str | None = None
    reward_efhc: str
    is_active: bool
    kind: str | None = None
    meta: dict[str, Any] | None = None


class CursorPage(BaseModel):
    items: list[TaskItem]
    next_cursor: str | None = None
    etag: str | None = None


class UserTaskItem(BaseModel):
    id: int
    task_id: int
    status: str
    progress: dict[str, Any] | None = None
    reward_efhc: str
    can_claim: bool


class UserTasksPage(BaseModel):
    items: list[UserTaskItem]
    next_cursor: str | None = None
    etag: str | None = None


class ClaimIn(BaseModel):
    task_id: int = Field(
        ...,
        ge=1,
        description="ID задания для получения награды",
    )


class ClaimOut(BaseModel):
    ok: bool
    tg_id: int
    task_id: int
    reward_efhc: str
    bonus_balance: str
    main_balance: str
    detail: str = "ok"


def _clamp_limit(limit: int) -> int:
    if limit < 1:
        return 1
    if limit > 100:
        return 100
    return limit


def _decode_after_id(cursor: str | None) -> int | None:
    if not cursor:
        return None
    try:
        payload = decode_cursor(cursor)
        return int(payload.get("after_id"))
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail="Некорректный cursor",
        ) from exc


@router.get(
    "/catalog",
    response_model=CursorPage,
    summary="Каталог активных заданий",
)
async def get_tasks_catalog(
    response: Response,
    cursor: str | None = None,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
) -> CursorPage:
    limit = _clamp_limit(limit)
    after_id = _decode_after_id(cursor)

    try:
        items_raw, next_after_id = await list_tasks_catalog(
            db,
            after_id=after_id,
            limit=limit,
        )
    except Exception as exc:
        logger.warning("tasks.catalog failed: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите попытку.",
        ) from exc

    items: list[TaskItem] = []
    for it in items_raw:
        items.append(
            TaskItem(
                id=int(it["id"]),
                code=str(it["code"]),
                title=str(it["title"]),
                description=(
                    it.get("description")
                    if it.get("description") is not None
                    else None
                ),
                reward_efhc=str(d8(it["reward_efhc"])),
                is_active=bool(it.get("is_active", True)),
                kind=(it.get("kind") or None),
                meta=(it.get("meta") or None),
            )
        )

    next_cursor = (
        encode_cursor({"after_id": int(next_after_id)})
        if next_after_id
        else None
    )
    etag = make_etag(
        {
            "items": [it.model_dump() for it in items],
            "next_cursor": next_cursor,
        }
    )
    response.headers["ETag"] = etag

    return CursorPage(
        items=items,
        next_cursor=next_cursor,
        etag=etag,
    )


@router.get(
    "/my/{tg_id}",
    response_model=UserTasksPage,
    summary="Мои задания и статусы",
)
async def get_user_tasks(
    response: Response,
    tg_id: int,
    cursor: str | None = None,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
) -> UserTasksPage:
    limit = _clamp_limit(limit)
    after_id = _decode_after_id(cursor)

    try:
        items_raw, next_after_id = await list_user_tasks(
            db,
            tg_id=int(tg_id),
            after_id=after_id,
            limit=limit,
        )
    except Exception as exc:
        logger.warning("tasks.my failed tg_id=%s: %s", tg_id, exc)
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите попытку.",
        ) from exc

    items: list[UserTaskItem] = []
    for it in items_raw:
        items.append(
            UserTaskItem(
                id=int(it["id"]),
                task_id=int(it["task_id"]),
                status=str(it["status"]),
                progress=(
                    it.get("progress")
                    if it.get("progress") is not None
                    else None
                ),
                reward_efhc=str(d8(it["reward_efhc"])),
                can_claim=bool(it.get("can_claim", False)),
            )
        )

    next_cursor = (
        encode_cursor({"after_id": int(next_after_id)})
        if next_after_id
        else None
    )
    etag = make_etag(
        {
            "items": [it.model_dump() for it in items],
            "next_cursor": next_cursor,
        }
    )
    response.headers["ETag"] = etag

    return UserTasksPage(
        items=items,
        next_cursor=next_cursor,
        etag=etag,
    )


@router.post(
    "/claim/{tg_id}",
    response_model=ClaimOut,
    summary="Получить награду за задание",
)
async def post_claim_task(
    tg_id: int,
    payload: ClaimIn,
    db: AsyncSession = Depends(get_db),
    idempotency_key: str = Depends(require_idempotency_key),
    current_tg_id: int = Depends(get_current_tg_id),
) -> ClaimOut:
    if int(tg_id) != int(current_tg_id):
        raise HTTPException(
            status_code=403,
            detail="Доступ запрещён",
        )

    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Idempotency-Key header is strictly required by canon "
                "for monetary operations."
            ),
        )

    try:
        result = await claim_task_reward(
            db,
            tg_id=int(tg_id),
            task_id=int(payload.task_id),
            idempotency_key=idempotency_key.strip(),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error(
            "tasks.claim failed tg_id=%s task_id=%s: %s",
            tg_id,
            payload.task_id,
            exc,
        )
        raise HTTPException(
            status_code=500,
            detail="Временная ошибка. Повторите попытку.",
        ) from exc

    return ClaimOut(
        ok=bool(result.ok),
        tg_id=int(result.tg_id),
        task_id=int(payload.task_id),
        reward_efhc=str(d8(result.reward_efhc)),
        bonus_balance=str(d8(result.user_bonus_balance)),
        main_balance=str(d8(result.user_main_balance)),
        detail=result.detail or "ok",
    )
