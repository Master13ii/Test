"""
Standards package.

Holds shared conventions / standards helpers used across the backend.
No runtime side effects in package initialization.
"""
__all__: list[str] = []
