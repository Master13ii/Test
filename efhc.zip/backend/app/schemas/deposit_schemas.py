# backend/app/schemas/deposit_schemas.py
# ----------------------------------------------------------------------
# Deposit EFHC (on-chain) — схемы для A+B контура.
# ----------------------------------------------------------------------

from __future__ import annotations

from typing import Any, Literal

from app.schemas.common_schemas import EfhcBaseModel
from pydantic import ConfigDict, Field


class DepositPackageOut(EfhcBaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    title: str
    asset: str
    price_asset_d8: str
    efhc_amount_d8: str
    is_active: bool


class DepositPackagesOut(EfhcBaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[DepositPackageOut]


class DepositEFHCIn(EfhcBaseModel):
    """Запрос на создание deposit-intent EFHC (on-chain)."""

    model_config = ConfigDict(extra="forbid")

    package_id: int = Field(..., ge=1)


class TonConnectTxOut(EfhcBaseModel):
    model_config = ConfigDict(extra="allow")

    validUntil: int
    messages: list[dict[str, Any]]


class DepositEFHCOut(EfhcBaseModel):
    """Ответ deposit-intent + TonConnect tx."""

    model_config = ConfigDict(extra="forbid")

    purpose: Literal["deposit_efhc"] = "deposit_efhc"
    status: Literal["PENDING"] = "PENDING"
    intent_id: int
    asset: str
    amount_asset_d8: str
    efhc_amount_d8: str
    payload: str
    tonconnect_tx: TonConnectTxOut
