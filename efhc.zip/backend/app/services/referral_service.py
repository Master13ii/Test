# backend/app/services/referral_service.py
# ======================================================================
# Назначение кода:
# Сервис реферальной системы EFHC Bot:
# • Курсорные выборки «Активные / Неактивные» рефералы
#   для пригласившего.
# • Регистрация реферальной связи при старте бота по ссылке
#   (без бонуса).
# • Автоматическое начисление 0.1 EFHC за КАЖДОГО АКТИВНОГО реферала
# (купил ≥1 панель), но только для первых 10 000 активных рефералов.
# • Ранги (уровни 0–5) по количеству АКТИВНЫХ рефералов + разовые бонусы
# за достижение уровней и прогресс до следующего уровня для фронтенда.
# • Генерация постоянного реферального кода/ссылки для пользователя.
#
# Канон/инварианты:
# • «Активный реферал» — тот, кто купил хотя бы одну панель (статус
# постоянный).
# • Бонусы:
# • За КАЖДОГО активного реферала:
# +0.1 EFHC (bonus balance) пригласившему, но максимум для первых
# 10 000 активных рефералов.
# • Уровни:
# 1 уровень: 10 активных рефералов   → +1 EFHC
# 2 уровень: 100 активных рефералов  → +10 EFHC
# 3 уровень: 1000 активных рефералов → +100 EFHC
# 4 уровень: 3000 активных рефералов → +300 EFHC
# 5 уровень: 10000 активных рефералов→ +1000 EFHC
#
# • Любые начисления идут ТОЛЬКО через банк (transactions_service),
# Decimal(30,8), округление вниз, bonus-first.
# • Пользователь НЕ может уйти в минус; Банк МОЖЕТ
#   (операции не блокируем).
# • Денежные операции — строго идемпотентны (idempotency-key банка).
#
# ИИ-защита/самовосстановление:
# • Курсорная пагинация без OFFSET: (invited_at, referred_tg_id) как
# курсор.
# • «Мягкие» SQL: сервис использует текстовые запросы, легко
#   адаптируется миграциями.
# • on_user_first_panel_purchase(...) построен по принципу read-through:
# повторный вызов с теми же ключами безопасен (idempotency_key).
# • Ранги начисляются отдельным helper’ом с идемпотентными ключами
#   на уровень.
#
# Запреты:
# • Нет P2P-переводов; никаких прямых операций user→user.
# • Нет «суточных» расчётов; сервис не знает про генерацию энергии.
# ======================================================================

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from app.services.transactions_service import (
    credit_user_bonus_from_bank,
)
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")

# ----------------------------------------------------------------------
# Константы реферальной системы
# ----------------------------------------------------------------------

# 0.1 EFHC за КАЖДОГО АКТИВНОГО реферала (после покупки панели)
REF_BONUS_PER_ACTIVE_UNIT_RAW = (
    getattr(settings, "REFERRAL_BONUS_PER_ACTIVE_UNIT", "0.1")
    or "0.1"
)
REF_BONUS_PER_ACTIVE_UNIT = d8(REF_BONUS_PER_ACTIVE_UNIT_RAW)

# Ограничение количества АКТИВНЫХ рефералов с бонусом 0.1 EFHC
REF_MAX_ACTIVE_FOR_UNIT_BONUS: int = int(
    getattr(settings, "REFERRAL_MAX_ACTIVE_FOR_UNIT_BONUS", 10_000)
    or 10_000
)

# Конфигурация уровней 1–5 (по ЧИСЛУ АКТИВНЫХ рефералов)
@dataclass(frozen=True)


class ReferralLevelConfig:
    level: int
    required_active: int
    bonus: Decimal  # EFHC, начисляется разово при достижении уровня


REF_LEVELS: tuple[ReferralLevelConfig, ...] = (
    ReferralLevelConfig(level=1, required_active=10, bonus=d8("1")),
    ReferralLevelConfig(level=2, required_active=100, bonus=d8("10")),
    ReferralLevelConfig(level=3, required_active=1000, bonus=d8("100")),
    ReferralLevelConfig(level=4, required_active=3000, bonus=d8("300")),
    ReferralLevelConfig(
        level=5,
        required_active=10000,
        bonus=d8("1000"),
    ),
)

# Настройки реферального кода/ссылки
REF_CODE_LENGTH: int = int(
    getattr(settings, "REFERRAL_CODE_LENGTH", 8) or 8
)
REF_CODE_ALPHABET: str = (
    "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
)
REF_SALT: str = (
    getattr(settings, "REFERRAL_SALT", "efhc_ref_salt")
    or "efhc_ref_salt"
)
BOT_USERNAME: str = getattr(settings, "BOT_USERNAME", "") or ""

# ----------------------------------------------------------------------
# DTO курсорных ответов и статистики
# ----------------------------------------------------------------------

@dataclass


class ReferralItem:
    child_tg_id: int
    tg_id: int
    username: str | None
    joined_at: datetime
    is_active: bool
    total_generated_kwh: Decimal
    panels_count: int
    invited_at: datetime
    activated_at: datetime | None


CursorTuple = tuple[str, int]  # (created_at_iso, referred_tg_id)


@dataclass


class ReferralStats:
    inviter_tg_id: int
    total_referrals: int  # все рефералы (по ссылке)
    active_referrals: int  # активные (купили ≥ 1 панель)
    level: int  # 0..5
    next_level: int | None  # None, если достигнут 5 уровень
    # Сколько активных нужно для текущего уровня (0 для уровня 0).
    current_level_min: int
    # Сколько активных нужно для следующего уровня.
    next_level_min: int | None
    # Сколько активных не хватает до следующего уровня (0, если max).
    refs_to_next: int
    progress: float  # 0.0–1.0 прогресс от текущего уровня до следующего
    referral_code: str  # стабильный код
    referral_link: str | None  # t.me-ссылка, если BOT_USERNAME задан


# ----------------------------------------------------------------------
# Внутренние SQL-хелперы для списков рефералов
# ----------------------------------------------------------------------

# Таблицы по канону:
# • {SCHEMA}.referral_links(
# inviter_tg_id BIGINT,
# referred_tg_id BIGINT,
# created_at TIMESTAMPTZ,
# activated_at TIMESTAMPTZ NULL
# )
# • {SCHEMA}.users(id PK, tg_id BIGINT, username TEXT, ...)
# • {SCHEMA}.panels(id PK, tg_id FK users.id, is_active BOOL, ...)
#
# Активность считаем исторически: «активный» = есть хотя бы одна панель
# (в т.ч. архивная).
SQL_BASE = f"""
WITH ref AS (
  SELECT
    rl.referred_tg_id AS ref_tg,
    rl.inviter_tg_id  AS inv_tg,
    rl.created_at           AS invited_at,
    rl.activated_at         AS activated_at
  FROM {SCHEMA}.referral_links rl
  WHERE rl.inviter_tg_id = :inviter_tg
),
u AS (
  SELECT
    u.tg_id AS tg,
    u.username    AS username,
    u.id          AS u_pk,
    u.created_at  AS joined_at,
    COALESCE(u.total_generated_kwh, 0) AS total_generated_kwh
  FROM {SCHEMA}.users u
  WHERE u.tg_id IN (SELECT ref_tg FROM ref)
),
p AS (
  SELECT
    u.tg AS tg,
    COUNT(p.id) AS panels_count
  FROM u
  LEFT JOIN {SCHEMA}.panels p ON p.tg_id = u.u_pk
  GROUP BY u.tg
)
SELECT
  u.u_pk                AS child_tg_id,
  ref.ref_tg            AS tg_id,
  u.username            AS username,
  u.joined_at           AS joined_at,
  (COALESCE(p.panels_count,0) > 0) AS is_active,
  u.total_generated_kwh AS total_generated_kwh,
  COALESCE(p.panels_count,0) AS panels_count,
  ref.invited_at        AS invited_at,
  ref.activated_at      AS activated_at
FROM ref
LEFT JOIN u  ON u.tg = ref.ref_tg
LEFT JOIN p  ON p.tg = ref.ref_tg
WHERE
  (ref.invited_at, ref.ref_tg) < (:cursor_ts, :cursor_id)
  OR (:cursor_ts IS NULL AND :cursor_id IS NULL)
  -- фильтр активности подставляется снаружи
ORDER BY ref.invited_at DESC, ref.ref_tg DESC
LIMIT :limit
"""

# ----------------------------------------------------------------------
# Публичные функции: списки рефералов для фронтенда
# ----------------------------------------------------------------------

async def svc_list_referrals_active(
    db: AsyncSession,
    inviter_tg_id: int,
    limit: int,
    cursor: CursorTuple | None,
) -> tuple[list[ReferralItem], CursorTuple | None]:
    """Курсорная выдача активных рефералов.

    Активный = купил ≥1 панель (исторический статус).
    Cursor: (invited_at_iso, referred_tg_id) в порядке DESC.
    """
    cur_ts, cur_id = _normalize_cursor(cursor)

    sql = SQL_BASE + "\nAND (COALESCE(p.panels_count,0) > 0)"
    rows = await db.execute(
        text(sql),
        {
            "inviter_tg": int(inviter_tg_id),
            "cursor_ts": cur_ts,
            "cursor_id": cur_id,
            "limit": int(limit),
        },
    )
    items = [
        ReferralItem(
            child_tg_id=int(r[0]),
            tg_id=int(r[1]),
            username=(r[2] if r[2] is not None else None),
            joined_at=r[3],
            is_active=bool(r[4]),
            total_generated_kwh=Decimal(str(r[5])),
            panels_count=int(r[6]),
            invited_at=r[7],
            activated_at=r[8],
        )
        for r in rows.fetchall()
    ]
    next_cur = _next_cursor(items)
    return items, next_cur


async def svc_list_referrals_inactive(
    db: AsyncSession,
    inviter_tg_id: int,
    limit: int,
    cursor: CursorTuple | None,
) -> tuple[list[ReferralItem], CursorTuple | None]:
    """Курсорная выдача неактивных рефералов.

    Неактивный = не купил ни одной панели.
    Cursor: (invited_at_iso, referred_tg_id) в порядке DESC.
    """
    cur_ts, cur_id = _normalize_cursor(cursor)

    sql = SQL_BASE + "\nAND (COALESCE(p.panels_count,0) = 0)"
    rows = await db.execute(
        text(sql),
        {
            "inviter_tg": int(inviter_tg_id),
            "cursor_ts": cur_ts,
            "cursor_id": cur_id,
            "limit": int(limit),
        },
    )
    items = [
        ReferralItem(
            child_tg_id=int(r[0]),
            tg_id=int(r[1]),
            username=(r[2] if r[2] is not None else None),
            joined_at=r[3],
            is_active=bool(r[4]),
            total_generated_kwh=Decimal(str(r[5])),
            panels_count=int(r[6]),
            invited_at=r[7],
            activated_at=r[8],
        )
        for r in rows.fetchall()
    ]
    next_cur = _next_cursor(items)
    return items, next_cur



# ----------------------------------------------------------------------
# Публичные функции: API-обёртки (имена из routes/referrals_routes.py)
# ----------------------------------------------------------------------

@dataclass
class ReferralsPage:
    items: list[ReferralItem]
    next_cursor: str | None


@dataclass
class ReferralCounters:
    total: int
    active: int
    inactive: int


def _parse_cursor_str(cursor: str | None) -> CursorTuple | None:
    if not cursor:
        return None
    raw = str(cursor).strip()
    if not raw:
        return None
    sep = '|' if '|' in raw else (',' if ',' in raw else None)
    if not sep:
        return None
    parts = raw.split(sep, 1)
    if len(parts) != 2:
        return None
    ts = parts[0].strip()
    try:
        rid = int(parts[1].strip())
    except Exception:
        return None
    return (ts, rid)


def _format_cursor(cur: CursorTuple | None) -> str | None:
    if not cur:
        return None
    ts, rid = cur
    return f"{ts}|{int(rid)}"


def _normalize_cursor(
    cursor: CursorTuple | None,
) -> tuple[datetime | None, int | None]:
    if not cursor:
        return None, None
    ts_raw, rid = cursor
    try:
        ts = datetime.fromisoformat(str(ts_raw))
    except Exception:
        ts = None
    try:
        cid = int(rid) if rid is not None else None
    except Exception:
        cid = None
    return ts, cid


def _next_cursor(
    items: list[ReferralItem],
) -> CursorTuple | None:
    if not items:
        return None
    last = items[-1]
    try:
        ts = last.invited_at
        ts_s = ts.isoformat() if isinstance(ts, datetime) else str(ts)
        return (ts_s, int(last.tg_id))
    except Exception:
        return None


def build_referral_link(code: str) -> str:
    uname = str(BOT_USERNAME).lstrip("@").strip()
    return f"https://t.me/{uname}?start=ref_{code}"


def _generate_referral_code(length: int = 10) -> str:
    import secrets
    import string

    alphabet = string.ascii_uppercase + string.digits
    n = max(6, min(32, int(length)))
    return "".join(secrets.choice(alphabet) for _ in range(n))


async def ensure_consistency(
    db: AsyncSession,
    *,
    parent_tg_id: int,
) -> None:
    # Best-effort: гарантируем наличие таблицы и кода.
    await ensure_referral_codes_table(db)
    await get_or_create_referral_code(
        db,
        inviter_tg_id=int(parent_tg_id),
    )


async def list_active_referrals(
    db: AsyncSession,
    *,
    parent_tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
) -> ReferralsPage:
    cur = _parse_cursor_str(cursor)
    items, next_cur = await svc_list_referrals_active(
        db,
        inviter_tg_id=int(parent_tg_id),
        limit=int(limit),
        cursor=cur,
    )
    return ReferralsPage(
        items=items,
        next_cursor=_format_cursor(next_cur),
    )


async def list_inactive_referrals(
    db: AsyncSession,
    *,
    parent_tg_id: int,
    limit: int = 100,
    cursor: str | None = None,
) -> ReferralsPage:
    cur = _parse_cursor_str(cursor)
    items, next_cur = await svc_list_referrals_inactive(
        db,
        inviter_tg_id=int(parent_tg_id),
        limit=int(limit),
        cursor=cur,
    )
    return ReferralsPage(
        items=items,
        next_cursor=_format_cursor(next_cur),
    )


async def get_counters(
    db: AsyncSession,
    *,
    parent_tg_id: int,
) -> ReferralCounters:
    total = await _count_total_referrals(
        db, inviter_tg_id=int(parent_tg_id)
    )
    active = await _count_active_referrals(
        db, inviter_tg_id=int(parent_tg_id)
    )
    inactive = max(int(total) - int(active), 0)
    return ReferralCounters(
        total=int(total),
        active=int(active),
        inactive=int(inactive),
    )

# ----------------------------------------------------------------------
# Регистрация нового реферала по ссылке (БЕЗ бонуса)
# Вызывается из регистрации пользователя, если в /start есть реф-код.
# ----------------------------------------------------------------------

async def register_referral_and_reward(
    db: AsyncSession,
    *,
    inviter_tg_id: int,
    referred_tg_id: int,
    created_at: datetime | None = None,
) -> None:
    """Регистрирует referral_links.

    Бонусов за регистрацию нет по канону.
    Бонусы только после покупки первой панели (активации).
    """
    created_at = created_at or datetime.now(tz=UTC)

    await db.execute(
        text(
            f"""  # nosec B608
            INSERT INTO {SCHEMA}.referral_links (
                inviter_tg_id,
                referred_tg_id,
                created_at
            )
            VALUES (:inv, :ref, :ts)
            ON CONFLICT DO NOTHING
            """
        ),
        {
            "inv": int(inviter_tg_id),
            "ref": int(referred_tg_id),
            "ts": created_at,
        },
    )
    # Денежных операций нет: бонус начисляется только при активации.


# ----------------------------------------------------------------------
# Авто-активация и бонусы при первой покупке панели приглашённым
# Вызывается panels_service после успешной покупки ПЕРВОЙ панели.
# ----------------------------------------------------------------------

async def on_user_first_panel_purchase(
    db: AsyncSession,
    buyer_tg_id: int,
    activation_dt: datetime | None = None,
) -> None:
    """Помечает реферала активным и начисляет бонусы.

    Действия:
    • Unit-бонус 0.1 EFHC (до 10 000 активных рефералов).
    • Синхронизация уровеньных бонусов 1–5.
    """
    act_ts = activation_dt or datetime.utcnow()

    # 1) Найти пригласившего для buyer_tg_id
    row = await db.execute(
        text(
            f"""  # nosec B608
            SELECT
                inviter_tg_id,
                referred_tg_id,
                created_at,
                activated_at
            FROM {SCHEMA}.referral_links
            WHERE referred_tg_id = :tg
            LIMIT 1
            """
        ),
        {"tg": int(buyer_tg_id)},
    )
    ref = row.fetchone()
    if not ref:
        # Покупатель пришёл без реф-ссылки — нечего активировать
        logger.debug("referral: no link for buyer tg=%s", buyer_tg_id)
        return

    inviter_tg = int(ref[0])

    # 2) Проставить activated_at (если ещё пусто)
    await db.execute(
        text(
            f"""  # nosec B608
            UPDATE {SCHEMA}.referral_links
            SET activated_at = COALESCE(activated_at, :ts)
            WHERE referred_tg_id = :tg
            """
        ),
        {
            "tg": int(buyer_tg_id),
            "ts": act_ts,
        },
    )

    # 3) Начислить 0.1 EFHC за АКТИВНОГО реферала (unit-бонус)
    try:
        await _maybe_reward_active_unit_bonus(
            db=db,
            inviter_tg_id=inviter_tg,
            buyer_tg_id=buyer_tg_id,
        )
    except Exception as e:
        # Не роняем покупку панели; бонус догоним ретраем
        logger.warning(
            (
                "referral unit bonus failed (will retry later): "
                "buyer=%s err=%s"
            ),
            buyer_tg_id,
            e,
        )

    # 4) Синхронизировать уровень и уровеньные бонусы (1–5)
    #    пригласившего
    try:
        await _sync_inviter_level_rewards(
            db=db,
            inviter_tg_id=inviter_tg,
        )
    except Exception as e:
        logger.warning(
            (
                "referral levels sync failed (will retry later): "
                "inviter=%s err=%s"
            ),
            inviter_tg,
            e,
        )


# ----------------------------------------------------------------------
# Статистика для фронтенда: уровни, прогресс, ссылка
# ----------------------------------------------------------------------

async def get_referral_stats(
    db: AsyncSession,
    *,
    inviter_tg_id: int,
) -> ReferralStats:
    """
    Возвращает агрегированную статистику для реферального раздела:
      • total_referrals      — общее число рефералов (по ссылке)
      • active_referrals     — активные (купили ≥1 панель)
      • level (0–5)
      • next_level / refs_to_next / progress (0.0–1.0)
      • referral_code, referral_link
    """
    total_refs = await _count_total_referrals(
        db,
        inviter_tg_id=inviter_tg_id,
    )
    active_refs = await _count_active_referrals(
        db,
        inviter_tg_id=inviter_tg_id,
    )

    (
        level,
        current_min,
        next_level,
        next_min,
        refs_to_next,
        progress,
    ) = _compute_level_and_progress(active_refs)

    code = await get_or_create_referral_code(
        db,
        inviter_tg_id=inviter_tg_id,
    )
    link = build_referral_link(code) if code and BOT_USERNAME else None

    return ReferralStats(
        inviter_tg_id=int(inviter_tg_id),
        total_referrals=total_refs,
        active_referrals=active_refs,
        level=level,
        next_level=next_level,
        current_level_min=current_min,
        next_level_min=next_min,
        refs_to_next=refs_to_next,
        progress=progress,
        referral_code=code,
        referral_link=link,
    )


# ----------------------------------------------------------------------
# Денежная логика: 0.1 EFHC за активного реферала и уровеньные бонусы
# ----------------------------------------------------------------------

async def _maybe_reward_active_unit_bonus(
    db: AsyncSession,
    inviter_tg_id: int,
    buyer_tg_id: int,
) -> None:
    """Идемпотентно начисляет 0.1 EFHC за активного реферала.

    Условия:
    • Покупатель стал активным (первая панель).
    • Активных у пригласившего ≤ REF_MAX_ACTIVE_FOR_UNIT_BONUS.
    Ключ: REF_ACT_UNIT:<buyer_tg>.
    """
    inviter_tg_id = await _get_tg_id_by_telegram(db, inviter_tg_id)
    if inviter_tg_id is None:
        logger.warning(
            "referral: inviter not found for unit bonus, tg=%s",
            inviter_tg_id,
        )
        return

    # Считаем активных рефералов после активации
    active_refs = await _count_active_referrals(
        db,
        inviter_tg_id=inviter_tg_id,
    )
    if active_refs > REF_MAX_ACTIVE_FOR_UNIT_BONUS:
        logger.info(
            (
                "referral: max active - unit bonus reached for "
                "inviter=%s (active_refs=%s)"
            ),
            inviter_tg_id,
            active_refs,
        )
        return

    if d8("0") >= REF_BONUS_PER_ACTIVE_UNIT:
        return

    await credit_user_bonus_from_bank(
        db=db,
        tg_id=int(inviter_tg_id),
        amount=REF_BONUS_PER_ACTIVE_UNIT,
        reason="referral_active_unit",
        idempotency_key=f"REF_ACT_UNIT:{int(buyer_tg_id)}",
        meta={
            "inviter_tg": int(inviter_tg_id),
            "buyer_tg": int(buyer_tg_id),
        },
    )


async def _sync_inviter_level_rewards(
    db: AsyncSession,
    inviter_tg_id: int,
) -> None:
    """Начисляет уровеньные бонусы 1–5 (идемпотентно).

    Ключ на уровень: REF_LVL:<tg_id>:<level>.
    Повторный вызов безопасен.
    """
    inviter_tg_id = await _get_tg_id_by_telegram(db, inviter_tg_id)
    if inviter_tg_id is None:
        logger.warning(
            "referral: inviter not found for level sync, tg=%s",
            inviter_tg_id,
        )
        return

    active_refs = await _count_active_referrals(
        db,
        inviter_tg_id=inviter_tg_id,
    )
    if active_refs <= 0:
        return

    for cfg in REF_LEVELS:
        if active_refs >= cfg.required_active:
            try:
                await credit_user_bonus_from_bank(
                    db=db,
                    tg_id=int(inviter_tg_id),
                    amount=cfg.bonus,
                    reason="referral_level_bonus",
                    idempotency_key=(
                        f"REF_LVL:{int(inviter_tg_id)}:"
                        f"{int(cfg.level)}"
                    ),
                    meta={
                        "inviter_tg": int(inviter_tg_id),
                        "level": int(cfg.level),
                        "required_active": int(cfg.required_active),
                        "active_refs": int(active_refs),
                    },
                )
            except Exception as e:
                # Не роняем поток; при следующем вызове ещё раз
                # попробуем.
                logger.warning(
                    (
                        "referral level bonus failed "
                        "(will retry later): "
                        "inviter=%s level=%s err=%s"
                    ),
                    inviter_tg_id,
                    cfg.level,
                    e,
                )


# ----------------------------------------------------------------------
# Подсчёт total/active рефералов и ранговая логика
# ----------------------------------------------------------------------

async def _count_total_referrals(
    db: AsyncSession,
    inviter_tg_id: int,
) -> int:
    """Возвращает общее число рефералов (по ссылке)."""
    row = await db.execute(
        text(
            f"""  # nosec B608
            SELECT COUNT(*)
            FROM {SCHEMA}.referral_links
            WHERE inviter_tg_id = :tg
            """
        ),
        {"tg": int(inviter_tg_id)},
    )
    val = row.scalar() or 0
    return int(val)


async def _count_active_referrals(
    db: AsyncSession,
    inviter_tg_id: int,
) -> int:
    """Возвращает число активных рефералов.

    Активный = есть хотя бы одна панель (исторически).
    """
    rows = await db.execute(
        text(
            f"""  # nosec B608
            SELECT COUNT(DISTINCT u.id)
            FROM {SCHEMA}.referral_links rl
            JOIN {SCHEMA}.users u
              ON u.tg_id = rl.referred_tg_id
            JOIN {SCHEMA}.panels p
              ON p.tg_id = u.id
            WHERE rl.inviter_tg_id = :tg
            """
        ),
        {"tg": int(inviter_tg_id)},
    )
    val = rows.scalar() or 0
    return int(val)


def _compute_level_and_progress(
    active_refs: int,
) -> tuple[int, int, int | None, int | None, int, float]:
    """
    Возвращает:
      level, current_min, next_level, next_min, refs_to_next,
      progress(0..1)
    Логика:
      • Уровень 0 — до достижения первой ступени (10 активных).
      • Для уровней 1–5 используется граница
        REF_LEVELS.required_active.
      • progress считает путь от текущего уровня к следующему.
    """
    if active_refs < 0:
        active_refs = 0

    if not REF_LEVELS:
        return 0, 0, None, None, 0, 0.0

    current_level = 0
    current_min = 0
    for cfg in REF_LEVELS:
        if active_refs >= cfg.required_active:
            current_level = cfg.level
            current_min = cfg.required_active
        else:
            break

    next_cfg: ReferralLevelConfig | None = None
    for cfg in REF_LEVELS:
        if cfg.required_active > active_refs:
            next_cfg = cfg
            break

    if not next_cfg:
        # достигнут максимум (5 уровень)
        return current_level, current_min, None, None, 0, 1.0

    next_level = next_cfg.level
    next_min = next_cfg.required_active
    refs_to_next = max(0, next_min - active_refs)

    span = max(1, next_min - current_min)
    done = max(0, active_refs - current_min)
    progress = float(done) / float(span)
    if progress < 0.0:
        progress = 0.0
    if progress > 1.0:
        progress = 1.0

    return (
        current_level,
        current_min,
        next_level,
        next_min,
        refs_to_next,
        progress,
    )

# ----------------------------------------------------------------------
# Реферальный код и ссылка (постоянные)
# ----------------------------------------------------------------------

async def ensure_referral_codes_table(db: AsyncSession) -> None:
    """Канон: таблица referral_codes из 0001 (ORM-only).


    Сервис не выполняет DDL. Функция оставлена как «мягкий» якорь
    обратной совместимости для существующих вызовов.
    """
    return


async def get_or_create_referral_code(
    db: AsyncSession,
    inviter_tg_id: int,
) -> str:
    """Возвращает стабильный реферальный код пользователя.

    Канон:
    - Таблица efhc_core.referral_codes существует из 0001 (ORM).
    - Никакого CREATE TABLE в сервисе.
    """
    from app.models.referral_codes_models import ReferralCode
    # локальный импорт

    # 1) Уже есть?
    row = await db.execute(
        select(ReferralCode.code).where(
            ReferralCode.inviter_tg_id == int(inviter_tg_id)
        ).limit(1)
    )
    code = row.scalar()
    if code:
        return str(code)

    # 2) Создаём новый (с защитой от коллизий)
    for _ in range(10):
        code = _generate_referral_code()
        try:
            db.add(
                ReferralCode(
                    code=str(code),
                    inviter_tg_id=int(inviter_tg_id),
                )
            )
            await db.commit()
            return str(code)
        except Exception:
            await db.rollback()
            continue

    raise RuntimeError("failed_to_generate_referral_code")


async def _get_tg_id_by_telegram(
    db: AsyncSession,
    tg_id: int,
) -> int | None:
    """Возвращает users.id по tg_id (или None)."""
    row = await db.execute(
        text(
            f"""  # nosec B608
            SELECT id
            FROM {SCHEMA}.users
            WHERE tg_id = :tg
            LIMIT 1
            """
        ),
        {"tg": int(tg_id)},
    )
    rec = row.fetchone()
    if not rec:
        return None
    return int(rec[0])


# ======================================================================
# Пояснения «для чайника»:
# ----------------------------------------------------------------------
# • Бонусы только за АКТИВНЫХ рефералов:
# Регистрация по ссылке ничего не даёт финансово.
# Бонусы начинаются только после первой покупки панели рефералом
# (on_user_first_panel_purchase).
#
# • 0.1 EFHC:
# За КАЖДОГО активного реферала пригласивший получает 0.1 EFHC
# на bonus-баланс,
# но только для первых 10 000 активных рефералов. Лимит задаётся
# REF_MAX_ACTIVE_FOR_UNIT_BONUS.
#
# • Уровни 1–5:
# Считаются по ЧИСЛУ АКТИВНЫХ рефералов. При достижении порога уровня
# разово начисляется бонус (1, 10, 100, 300, 1000 EFHC) на bonus-баланс
# пригласившего. Идемпотентность: "REF_LVL:<tg_id>:<level>".
#
# • Прогресс-бар:
# get_referral_stats(...) отдаёт:
# level (0–5), next_level, refs_to_next и progress (0.0–1.0),
# чтобы фронтенд мог показать шкалу от текущего уровня к следующему.
#
# • Реферальная ссылка:
# get_referral_stats(...) также даёт referral_code и referral_link.
# Формат ссылки: https://t.me/<BOT_USERNAME>?start=ref_<code>.
#
# • Идемпотентность:
# Все денежные операции используют жёсткие Idempotency-Key:
# - "REF_ACT_UNIT:<buyer_tg>"         — 0.1 EFHC за активного реферала.
# - "REF_LVL:<tg_id>:<level>"      — бонус за достижение уровня.
# Повторные вызовы безопасны — банк не создаст дубль записи.
# ======================================================================

__all__ = [
    # Списки для фронтенда
    "ReferralItem",
    "CursorTuple",
    "svc_list_referrals_active",
    "svc_list_referrals_inactive",
    # Триггеры
    "register_referral_and_reward",
    "on_user_first_panel_purchase",
    # Статистика / ссылка
    "ReferralStats",
    "get_referral_stats",
    "get_or_create_referral_code",
    "build_referral_link",
]


# ----------------------------------------------------------------------
# Admin API (используется backend/app/routes/admin_referral_routes.py)
# Канон:
# - tg_id единственный идентификатор.
# - таблицы только ORM (efhc_core.referral_links,
# efhc_core.referral_bonus_ledger, efhc_core.users).
# - любые записи должны быть явно детерминированы и проверяемы.
# ----------------------------------------------------------------------

import contextlib

from app.models.referral_models import ReferralBonusLedger, ReferralLink
from app.models.user_models import User
from sqlalchemy import func, select


async def admin_summary(
    db: AsyncSession,
    *,
    limit: int = 50,
    after: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Агрегированная сводка по инвайтерам (cursor-based).

    Курсор: {"after_inviter_tg_id": <int>}
    """
    lim = max(1, min(200, int(limit)))
    after_id: int | None = None
    if after:
        try:
            raw = after.get("after_inviter_tg_id")
            after_id = int(raw) if raw is not None else None
        except Exception:
            after_id = None

    # Группируем по inviter_tg_id
    stmt = (
        select(
            ReferralLink.inviter_tg_id.label("inviter_tg_id"),
            func.count()
            .filter(ReferralLink.activated_at.isnot(None))
            .label("active_count"),
            func.count()
            .filter(ReferralLink.activated_at.is_(None))
            .label("inactive_count"),
            func.max(ReferralLink.created_at).label("last_invited_at"),
        )
        .group_by(ReferralLink.inviter_tg_id)
        .order_by(ReferralLink.inviter_tg_id.asc())
        .limit(lim)
    )
    if after_id is not None:
        stmt = stmt.where(ReferralLink.inviter_tg_id > after_id)

    rows = (await db.execute(stmt)).mappings().all()

    items: list[dict[str, Any]] = []
    last_inviter: int | None = None

    for r in rows:
        inviter_tg_id = int(r["inviter_tg_id"])
        last_inviter = inviter_tg_id

        # Сумма бонусов по ledger (если нет — 0)
        sum_stmt = select(
            func.coalesce(
                func.sum(ReferralBonusLedger.amount_efhc),
                0,
            )
        ).where(
            ReferralBonusLedger.tg_id == inviter_tg_id
        )
        total_bonus = (await db.execute(sum_stmt)).scalar() or 0

        items.append(
            {
                "inviter_tg_id": inviter_tg_id,
                "active_count": int(r["active_count"] or 0),
                "inactive_count": int(r["inactive_count"] or 0),
                "total_bonus_efhc": str(d8(total_bonus)),
                "last_invited_at": (
                    r["last_invited_at"].isoformat()
                    if r["last_invited_at"]
                    else None
                ),
            }
        )

    next_after = None
    if rows and len(rows) == lim and last_inviter is not None:
        next_after = {"after_inviter_tg_id": last_inviter}

    return {"items": items, "next_after": next_after}


async def admin_manual_bonus(
    db: AsyncSession,
    user_tg_id: int,
    *,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> None:
    """Ручное начисление бонуса (админ).

    Денежная операция через банк.
    """
    # 1) Проверяем, что пользователь существует
    exists_stmt = (
        select(User.tg_id)
        .where(User.tg_id == int(user_tg_id))
        .limit(1)
    )
    row = (await db.execute(exists_stmt)).first()
    if not row:
        raise ValueError("user not found")

    # 2) Начисление бонуса через банк (идемпотентно)
    await credit_user_bonus_from_bank(
        db,
        tg_id=int(user_tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=idempotency_key,
        meta={"admin": True, "kind": "referral_manual_bonus"},
    )

    # 3) Доп. факт в ledger (не банк, но отчётность). Не ломаем основной
    # поток.
    try:
        await db.begin()
        db.add(
            ReferralBonusLedger(
                tg_id=int(user_tg_id),
                amount_efhc=d8(amount),
                kind="admin_manual_bonus",
                meta=reason or None,
            )
        )
        await db.commit()
    except Exception:
        with contextlib.suppress(Exception):
            await db.rollback()
        logger.warning(
            "ReferralBonusLedger insert failed",
            exc_info=True,
        )


async def admin_reassign_inviter(
    db: AsyncSession,
    *,
    invitee_tg_id: int,
    new_inviter_tg_id: int,
    note: str | None = None,
    idempotency_key: str | None = None,
) -> None:
    """Переназначить пригласившего для invitee (tg_id → tg_id).

    Идемпотентность:
    - если связь уже указывает на new_inviter_tg_id — no-op.
    """
    if int(invitee_tg_id) == int(new_inviter_tg_id):
        raise ValueError("self-invite forbidden")

    # invitee должен существовать
    stmt = (
        select(User.tg_id)
        .where(User.tg_id == int(invitee_tg_id))
        .limit(1)
    )
    row = (await db.execute(stmt)).first()
    if not row:
        raise ValueError("invitee not found")

    # inviter должен существовать
    stmt = (
        select(User.tg_id)
        .where(User.tg_id == int(new_inviter_tg_id))
        .limit(1)
    )
    row = (await db.execute(stmt)).first()
    if not row:
        raise ValueError("inviter not found")

    await db.begin()
    # lock existing link
    link_row = (
        await db.execute(
        stmt = (
            select(ReferralLink)
            .where(
                ReferralLink.invitee_tg_id == int(invitee_tg_id)
            )
            .with_for_update()
        )
        )
    ).scalar_one_or_none()

    if link_row is None:
        # создаём новую связь
        db.add(
            ReferralLink(
                inviter_tg_id=int(new_inviter_tg_id),
                invitee_tg_id=int(invitee_tg_id),
                campaign=None,
                meta={"note": note} if note else None,
            )
        )
        await db.commit()
        return

    if int(link_row.inviter_tg_id) == int(new_inviter_tg_id):
        await db.commit()
        return

    link_row.inviter_tg_id = int(new_inviter_tg_id)
    if note:
        try:
            # meta может быть None
            cur = dict(link_row.meta or {})
            cur["note"] = note
            link_row.meta = cur
        except Exception:
            link_row.meta = {"note": note}

    await db.commit()
