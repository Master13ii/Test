# backend/app/services/admin/admin_lotteries_service.py
# ======================================================================
# EFHC Bot — Лотереи (админ-сервис)
# -----------------------------------------------------------------
# Назначение:
# • Канонический сервис управления лотереями в EFHC:
# - создание/редактирование лотерей;
# - включение/выключение/пауза;
# - розыгрыш с идемпотентной фиксацией победителя;
# - постановка в очередь призов:
# • EFHC_BONUS → bonus_awards (только бонусный счёт),
# • NFT_VIP    → prize_claims (NFT по кошельку).
# - ручная коррекция билетов (БЕЗ P2P и без прямого трогания балансов).
#
# Жёсткие инварианты (ИИ-защита):
# 1) Никаких внутренних переводов между пользователями:
# ПОЛЬЗОВАТЕЛЬ ↔ БАНК — единственно допустимое направление.
# 2) Призы EFHC в лотереях ВСЕГДА бонусные:
# EFHC_BONUS → только на бонусный баланс пользователя.
# 3) Денежные операции (EFHC) — ТОЛЬКО через transactions_service,
# но сам модуль ЛОТЕРЕЙ не меняет балансы напрямую:
# • Он лишь создаёт bonus_awards / prize_claims.
# • Фактическое начисление/списание делает WithdrawalsService/
#   BankService.
# 4) Розыгрыш идемпотентен:
# • Повторный вызов lotteries_lotteries при наличии winner
#   в lotteries_winners
# просто возвращает того же победителя и НЕ создаёт новые записи.
# 5) Лотерея может автоматически перезапускаться (auto_restart), если
# флаг включён; новые лотереи создаются как копия шаблона.
#
# Таблицы (ожидаемая структура, без строгой привязки к миграциям):
# • {SCHEMA_LOT}.lotteries(
# id, title, prize_type, prize_value, ticket_price,
# max_participants, max_tickets_per_user,
# status,                -- DRAFT/ACTIVE/PAUSED/CLOSED/FINISHED
# auto_restart BOOLEAN,  -- авто-перезапуск после FINISHED
# auto_restart_delay_sec INT,  -- задержка перед авто-стартом (опц.)
# created_at, finished_at
# )
#
# • {SCHEMA_LOT}.lotteries_tickets(
# id, lotteries_id, tg_id,
# created_at,
# idempotency_key TEXT NULL -- для user-side, если используется
# )
#
# • {SCHEMA_LOT}.lotteries_winners(
# id, lotteries_id, ticket_id, tg_id,
# prize_type, prize_value, created_at
# )
#
# • {SCHEMA_ADMIN}.bonus_awards(
# id, tg_id, source, amount, status,
# created_at, processed_at, meta_json,
# processing_idempotency_key
# )
#
# • {SCHEMA_ADMIN}.prize_claims(
# id, lotteries_id, tg_id, prize_type, prize_value,
# wallet_address, status, created_at, processed_at,
# reject_reason, tx_hash
# )
#
# Важное замечание:
# • Покупка билетов пользователями (списание EFHC) реализуется в
# пользовательском сервисе (не здесь). Этот модуль даёт админам:
# - управление метаданными лотерей,
# - честный розыгрыш,
# - ручную коррекцию билетов (без движения средств).
# ======================================================================

from __future__ import annotations

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.utils_core import (
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, ROUND_DOWN
from typing import Any, Literal

    format_decimal_str,
    quantize_decimal,
)
from pydantic import BaseModel, Field, field_validator

LotteriesStatus = Literal[
    "DRAFT",
    "ACTIVE",
    "PAUSED",
    "CLOSED",
    "FINISHED",
]

from sqlalchemy import text  # noqa: E402
from sqlalchemy.engine import Result  # noqa: E402
from sqlalchemy.ext.asyncio import AsyncSession  # noqa: E402

from .admin_logging import AdminLogger  # noqa: E402
from .admin_notifications import AdminNotifier  # noqa: E402
from .admin_rbac import RBAC, AdminRole, AdminUser  # noqa: E402

logger = get_logger(__name__)
S = get_settings()

_DEFAULT_SCHEMA_LOT = "efhc_core"
_DEFAULT_SCHEMA_CORE = "efhc_core"
_DEFAULT_SCHEMA_ADMIN = "efhc_admin"

SCHEMA_LOT: str = (
    getattr(S, "DB_SCHEMA_CORE", _DEFAULT_SCHEMA_LOT)
    or _DEFAULT_SCHEMA_LOT
)
SCHEMA_CORE: str = (
    getattr(S, "DB_SCHEMA_CORE", _DEFAULT_SCHEMA_CORE)
    or _DEFAULT_SCHEMA_CORE
)
SCHEMA_ADMIN: str = (
    getattr(S, "DB_SCHEMA_ADMIN", _DEFAULT_SCHEMA_ADMIN)
    or _DEFAULT_SCHEMA_ADMIN
)

EFHC_DECIMALS: int = int(
    getattr(S, "EFHC_DECIMALS", 8) or 8
)
_Q = Decimal(1).scaleb(-EFHC_DECIMALS)


def d8(x: Any) -> Decimal:
    """Округление вниз до EFHC_DECIMALS знаков."""
    return Decimal(str(x)).quantize(_Q, rounding=ROUND_DOWN)

# -----------------------------------------------------------------
# Перечисления и DTO
# -----------------------------------------------------------------


class Lotteriestatus(str):
    """Статусы лотереи (управление жизненным циклом)."""
    DRAFT = "DRAFT"  # черновик (неактивна)
    ACTIVE = "ACTIVE"  # принимает билеты
    PAUSED = "PAUSED"  # временная пауза (билеты не принимаются)
    # приём билетов завершён, розыгрыш ещё не проведён
    CLOSED = "CLOSED"
    FINISHED = "FINISHED"  # розыгрыш проведён, победитель зафиксирован


class LotteriesPrizeType(str):
    """Типы призов лотереи: бонусные EFHC или NFT VIP."""
    EFHC_BONUS = "EFHC_BONUS"  # бонусные EFHC на бонусный счёт
    NFT_VIP = "NFT_VIP"  # NFT VIP (по привязанному кошельку)


class LotteriesListFilters(BaseModel):
    """Фильтры списка лотерей для админки."""
    status: LotteriesStatus | None = None
    title_substr: str | None = None
    limit: int = Field(100, ge=1, le=500)
    offset: int = Field(0, ge=0)
    sort_desc: bool = True


class LotteriesInfo(BaseModel):
    """Краткая карточка лотереи для списка."""
    id: int
    title: str
    prize_type: str
    prize_value: str
    ticket_price: str
    max_participants: int
    max_tickets_per_user: int
    status: str
    auto_restart: bool
    auto_restart_delay_sec: int
    created_at: str
    finished_at: str | None = None



class LotteriestatusSummary(BaseModel):
    """SSOT: сводка статусов лотерей.

    Поля не используются в критической бизнес-логике;
    нужны для админ-дашборда и
    совместимости импорта в admin_facade.
    """

    total: int = 0
    active: int = 0
    paused: int = 0
    finished: int = 0

class CreateLotteriesRequest(BaseModel):
    """
    Создание лотереи.

    prize_type:
      • EFHC_BONUS — призом будет бонусный EFHC на бонусный баланс.
      • NFT_VIP    — призом будет NFT VIP (запись в prize_claims).

    prize_value:
      • для EFHC_BONUS — Decimal (сколько EFHC начислить победителю),
      • для NFT_VIP    — произвольный маркер (по умолчанию 'NFT_VIP').
    """
    title: str = Field(..., min_length=1, max_length=120)
    prize_type: Literal["EFHC_BONUS", "NFT_VIP"]
    prize_value: Any = Field(
        ...,
        description=(
            "Decimal для EFHC_BONUS или строковый маркер "
            "для NFT_VIP"
        ),
    )
    ticket_price: Any = Field(
        ...,
        description="Цена билета в EFHC (обычный EFHC)",
    )
    max_participants: int = Field(500, ge=1, le=100000)
    max_tickets_per_user: int = Field(10, ge=1, le=1000)
    # Авто-перезапуск
    auto_restart: bool = Field(
        False,
        description="Авто-перезапуск новой лотереи после FINISHED",
    )
    auto_restart_delay_sec: int = Field(0, ge=0, le=7 * 24 * 3600)

    @field_validator("ticket_price", mode="before")
    def _v_ticket_price(cls, v: Any) -> Decimal:
        """Validate ticket_price to Decimal."""
        return quantize_decimal(v, EFHC_DECIMALS, "DOWN")

    @field_validator("prize_value", mode="before")
    def _v_prize_value(cls, v: Any, values: dict[str, Any]) -> Any:
        """Validate prize_value based on prize_type."""
        pt = values.get("prize_type")
        if pt == LotteriesPrizeType.EFHC_BONUS:
            dec = quantize_decimal(v, EFHC_DECIMALS, "DOWN")
            if dec <= 0:
                raise ValueError(
                    "Значение prize_value для EFHC_BONUS "
                    "должно быть > 0"
                )
            return dec
        # NFT_VIP — любое нефустое строковое значение
        if isinstance(v, str) and v.strip():
            return v.strip()
        return "NFT_VIP"


class UpdateLotteriesRequest(BaseModel):
    """Частичное обновление лотереи (только админ)."""
    title: str | None = Field(
        default=None,
        min_length=1,
        max_length=120,
    )
    ticket_price: Any | None = Field(default=None)
    max_participants: int | None = Field(
        default=None,
        ge=1,
        le=100000,
    )
    max_tickets_per_user: int | None = Field(
        default=None,
        ge=1,
        le=1000,
    )
    status: LotteriesStatus | None = None
    auto_restart: bool | None = None
    auto_restart_delay_sec: int | None = Field(
        default=None,
        ge=0,
        le=7 * 24 * 3600,
    )

    @field_validator("ticket_price", mode="before")
    def _v_ticket_price(cls, v: Any) -> Decimal | None:
        """Validate ticket_price if provided."""
        if v is None:
            return None
        return quantize_decimal(v, EFHC_DECIMALS, "DOWN")


class LotteriesTicketCorrectionRequest(BaseModel):
    """
    Ручная корректировка билетов админом (БЕЗ движения средств):

      • delta_tickets > 0  → добавить N билетов пользователю;
      • delta_tickets < 0  → пометить N последних билетов пользователя
                             как отменённые (реализуется через таблицу
                             lotteries_tickets_corrections или
                             soft delete — реализуется БД/миграциями).
    ВАЖНО:
      • Эта операция не трогает EFHC-баланс. Если нужно компенсировать
        или доначислить EFHC, это делается отдельно через банк
        (admin_bank_service).
    """
    tg_id: int
    lotteries_id: int
    delta_tickets: int = Field(
        ...,
        description="Положительное или отрицательное значение",
    )
    reason: str = Field(..., min_length=1, max_length=500)

@dataclass
class WinnerTicket:
    """Описание победителя (для возврата в админ - панель)."""
    lotteries_id: int
    ticket_id: int
    tg_id: int
    prize_type: str
    prize_value: str
    user_wallet: str | None


# -----------------------------------------------------------------
# Вспомогательные утилиты
# -----------------------------------------------------------------


def _now_utc() -> datetime:
    """Return current UTC time."""
    return datetime.now(tz=UTC)

# -----------------------------------------------------------------
# Основной сервис лотерей
# -----------------------------------------------------------------


class AdminLotterieservice:
    """Admin lotteries service."""

    # -----------------------------------------------------------------
    # Список / чтение лотерей
    # -----------------------------------------------------------------

    @staticmethod
    async def list_lotteries(
        db: AsyncSession,
        filters: LotteriesListFilters,
    ) -> list[LotteriesInfo]:
        """Список лотерей с фильтрами."""
        where: list[str] = ["1 = 1"]
        params: dict[str, Any] = {
            "limit": filters.limit,
            "offset": filters.offset,
        }

        if filters.status:
            where.append("status = :st")
            params["st"] = filters.status
        if filters.title_substr:
            where.append("title ILIKE :t")
            params["t"] = f"%{filters.title_substr}%"

        order = "DESC" if filters.sort_desc else "ASC"

        sql = text(f""" # nosec
            SELECT
                id,
                title,
                prize_type,
                prize_value,
                ticket_price,
                max_participants,
                max_tickets_per_user,
                status,
                COALESCE(auto_restart, FALSE) AS auto_restart,
                COALESCE(auto_restart_delay_sec, 0)
                AS auto_restart_delay_sec,
                created_at,
                finished_at
            FROM {SCHEMA_LOT}.lotteries
            WHERE {" AND ".join(where)}
            ORDER BY id {order}
            LIMIT :limit OFFSET :offset
            """)

        r: Result = await db.execute(sql, params)
        out: list[LotteriesInfo] = []
        for row in r.fetchall():
            created_at = (
                row.created_at.isoformat()
                if hasattr(row.created_at, "isoformat")
                else str(row.created_at)
            )
            finished_at = None
            if getattr(row, "finished_at", None) and hasattr(
                row.finished_at,
                "isoformat",
            ):
                finished_at = row.finished_at.isoformat()

            out.append(
                LotteriesInfo(
                    id=int(row.id),
                    title=str(row.title),
                    prize_type=str(row.prize_type),
                    prize_value=str(row.prize_value),
                    ticket_price=str(row.ticket_price),
                    max_participants=int(row.max_participants),
                    max_tickets_per_user=int(row.max_tickets_per_user),
                    status=str(row.status),
                    auto_restart=bool(row.auto_restart),
                    auto_restart_delay_sec=int(
                        row.auto_restart_delay_sec or 0
                    ),
                    created_at=created_at,
                    finished_at=finished_at,
                )
            )
        return out

    # -----------------------------------------------------------------
    # Создание / обновление / управление статусом
    # -----------------------------------------------------------------

    @staticmethod
    async def create_lotteries(
        db: AsyncSession,
        req: CreateLotteriesRequest,
        admin: AdminUser,
    ) -> int:
        """
        Создаёт новую лотерею.

        Канон:
          • prize_type:
              - EFHC_BONUS — приз только бонусными EFHC;
              - NFT_VIP    — приз только NFT (через prize_claims).
          • Лотерея сразу становится ACTIVE (по умолчанию), чтобы не
            плодить статус-классику. DRAFT можно поставить через update.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        ticket_price = quantize_decimal(
            req.ticket_price,
            EFHC_DECIMALS,
            "DOWN",
        )
        if ticket_price <= 0:
            raise ValueError("Цена билета должна быть > 0")

        if req.prize_type == LotteriesPrizeType.EFHC_BONUS:
            prize_val_str = format_decimal_str(
                req.prize_value,
                EFHC_DECIMALS,
            )
        else:
            prize_val_str = str(req.prize_value)

        sql = text(f""" # nosec
            INSERT INTO {SCHEMA_LOT}.lotteries
                (title,
                 prize_type,
                 prize_value,
                 ticket_price,
                 max_participants,
                 max_tickets_per_user,
                 status,
                 auto_restart,
                 auto_restart_delay_sec,
                 created_at)
            VALUES
                (:title,
                 :ptype,
                 :pvalue,
                 :tprice,
                 :max_part,
                 :max_tpu,
                 'ACTIVE',
                 :auto_restart,
                 :auto_delay,
                 NOW() AT TIME ZONE 'UTC')
            RETURNING id
            """)
        r: Result = await db.execute(
            sql,
            {
                "title": req.title,
                "ptype": req.prize_type,
                "pvalue": prize_val_str,
                "tprice": format_decimal_str(
                    ticket_price,
                    EFHC_DECIMALS,
                ),
                "max_part": req.max_participants,
                "max_tpu": req.max_tickets_per_user,
                "auto_restart": bool(req.auto_restart),
                "auto_delay": int(req.auto_restart_delay_sec or 0),
            },
        )
        lid = int(r.scalar_one())

        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="LOTTERIES_CREATE",
            entity="lotteries",
            entity_id=lid,
            details=f"title={req.title}",
        )

        await AdminNotifier.notify_generic(
            db,
            event="LOTTERIES_CREATED",
            message=(
                f"Создана лотерея #{lid} «{req.title}» "
                f"({req.prize_type})"
            ),
        )

        return lid

    @staticmethod
    async def update_lotteries(
        db: AsyncSession,
        lotteries_id: int,
        req: UpdateLotteriesRequest,
        admin: AdminUser,
    ) -> None:
        """
        Частичное обновление параметров лотереи.

        Особенности:
          • Статусы FINISHED/CLOSED считаются «почти финальными».
            Менять
            финансовые параметры после розыгрыша крайне нежелательно.
          • Код не запрещает обновление статуса,
            но админ должен понимать
            последствия (поэтому всё логируется).
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        sets: list[str] = []
        params: dict[str, Any] = {"id": lotteries_id}

        if req.title is not None:
            sets.append("title = :title")
            params["title"] = req.title

        if req.ticket_price is not None:
            tprice = quantize_decimal(
                req.ticket_price,
                EFHC_DECIMALS,
                "DOWN",
            )
            if tprice <= 0:
                raise ValueError("Цена билета должна быть > 0")
            sets.append("ticket_price = :tprice")
            params["tprice"] = format_decimal_str(tprice, EFHC_DECIMALS)

        if req.max_participants is not None:
            sets.append("max_participants = :max_participants")
            params["max_participants"] = req.max_participants

        if req.max_tickets_per_user is not None:
            sets.append("max_tickets_per_user = :max_tpu")
            params["max_tpu"] = req.max_tickets_per_user

        if req.status is not None:
            sets.append("status = :status")
            params["status"] = req.status

        if req.auto_restart is not None:
            sets.append("auto_restart = :auto_restart")
            params["auto_restart"] = bool(req.auto_restart)

        if req.auto_restart_delay_sec is not None:
            sets.append("auto_restart_delay_sec = :auto_delay")
            params["auto_delay"] = int(req.auto_restart_delay_sec)

        if not sets:
            return

        sql = text(f""" # nosec
            UPDATE {SCHEMA_LOT}.lotteries
            SET {", ".join(sets)}
            WHERE id = :id
            """)
        await db.execute(sql, params)

        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="LOTTERIES_UPDATE",
            entity="lotteries",
            entity_id=lotteries_id,
            details=str(params),
        )

    @staticmethod
    async def activate_lotteries(
        db: AsyncSession,
        lotteries_id: int,
        admin: AdminUser,
    ) -> None:
        """Включает лотерею (status = ACTIVE)."""
        RBAC.require_role(admin, AdminRole.MODERATOR)
        await db.execute(
            text(
                f""" # nosec
                UPDATE {SCHEMA_LOT}.lotteries
                SET status = 'ACTIVE'
                WHERE id = :id
                """
            ),
            {"id": lotteries_id},
        )
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="LOTTERIES_ACTIVATE",
            entity="lotteries",
            entity_id=lotteries_id,
            details="",
        )

    @staticmethod
    async def pause_lotteries(
        db: AsyncSession,
        lotteries_id: int,
        admin: AdminUser,
    ) -> None:
        """Ставит лотерею на паузу (status=PAUSED)."""
        RBAC.require_role(admin, AdminRole.MODERATOR)
        await db.execute(
            text(
                f""" # nosec
                UPDATE {SCHEMA_LOT}.lotteries
                SET status='PAUSED'
                WHERE id = :id
                """
            ),
            {"id": lotteries_id},
        )
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="LOTTERIES_PAUSE",
            entity="lotteries",
            entity_id=lotteries_id,
            details="",
        )

    @staticmethod
    async def close_lotteries(
        db: AsyncSession,
        lotteries_id: int,
        admin: AdminUser,
    ) -> None:
        """
        Закрывает приём билетов (status=CLOSED),
        но ещё не проводит розыгрыш.

        Обычно вызывается автоматически после достижения лимита
        участников или по истечении времени.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)
        await db.execute(
            text(
                f""" # nosec
                UPDATE {SCHEMA_LOT}.lotteries
                SET status='CLOSED'
                WHERE id = :id
                """
            ),
            {"id": lotteries_id},
        )
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="LOTTERIES_CLOSE",
            entity="lotteries",
            entity_id=lotteries_id,
            details="",
        )

    # -----------------------------------------------------------------
    # РОЗЫГРЫШ ЛОТЕРЕИ
    # -----------------------------------------------------------------

    @staticmethod
    async def _get_existing_winner(
        db: AsyncSession,
        lotteries_id: int,
    ) -> WinnerTicket | None:
        """Return existing winner for idempotency, if any."""
        sql = text(f""" # nosec
            SELECT
                w.ticket_id,
                w.tg_id,
                w.prize_type,
                w.prize_value
            FROM {SCHEMA_LOT}.lotteries_winners w
            WHERE w.lotteries_id = :lid
            LIMIT 1
            """)
        r: Result = await db.execute(sql, {"lid": lotteries_id})
        row = r.fetchone()
        if not row:
            return None

        # Кошелёк ищем по tg_id (primary)
        r2: Result = await db.execute(text(f""" # nosec
                SELECT address
                FROM {SCHEMA_CORE}.crypto_wallets
                WHERE tg_id = :tg_id AND is_primary = TRUE
                ORDER BY id DESC
                LIMIT 1
                """),
            {"tg_id": row.tg_id},)
        wrow = r2.fetchone()
        wallet = wrow.address if wrow else None

        return WinnerTicket(
            lotteries_id=lotteries_id,
            ticket_id=int(row.ticket_id),
            tg_id=int(row.tg_id),
            prize_type=str(row.prize_type),
            prize_value=str(row.prize_value),
            user_wallet=wallet,
        )

    @staticmethod
    async def lotteries_lotteries(
        db: AsyncSession,
        *,
        lotteries_id: int,
        admin: AdminUser,
    ) -> WinnerTicket | None:
        """
        Проводит честный розыгрыш лотереи:

          1) Проверяет, не был ли уже выбран победитель
             (lotteries_winners).
             Если да — возвращает его (идемпотентный повтор).
          2) Выбирает случайный билет (code-only randomness).
          3) Записывает победителя в lotteries_winners.
          4) Ставит лотерею в статус FINISHED + finished_at.
          5) Создаёт запись:
               • EFHC_BONUS → bonus_awards (PENDING),
               • NFT_VIP    → prize_claims  (PENDING).
          6) При включённом auto_restart создаёт новую лотерею - клон.

        Возвращает WinnerTicket или None, если билетов не было.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        # 1) Проверяем существующего победителя
        existing = await AdminLotterieservice._get_existing_winner(
            db,
            lotteries_id,
        )
        if existing:
            logger.info(
                (
                    "lotteries_lotteries(%s): winner already exists "
                    "→ idempotent return"
                ),
                lotteries_id,
            )
            return existing

        # 2) Читаем метаданные лотереи
        rmeta: Result = await db.execute(text(f""" # nosec
                SELECT
                    id,
                    title,
                    prize_type,
                    prize_value,
                    ticket_price,
                    max_participants,
                    max_tickets_per_user,
                    status,
                    COALESCE(auto_restart, FALSE) AS auto_restart,
                    COALESCE(auto_restart_delay_sec, 0)
                    AS auto_restart_delay_sec
                FROM {SCHEMA_LOT}.lotteries
                WHERE id = :lid
                LIMIT 1
                """),
            {"lid": lotteries_id},)
        meta = rmeta.fetchone()
        if not meta:
            raise ValueError("Лотерея не найдена")

        if meta.status not in (
            Lotteriestatus.ACTIVE,
            Lotteriestatus.CLOSED,
        ):
            # Не даём случайно переиграть FINISHED/DRAFT/PAUSED
            raise ValueError(
                f"Лотерея в статусе {meta.status}, "
                f"розыгрыш невозможен"
            )

        # 3) Ищем «случайный» билет — строго code-only randomness.
        # Канон: DB-random (случайная сортировка в SQL) запрещён.
        import hashlib
        import secrets

        sold_r: Result = await db.execute(text(f""" # nosec
                SELECT COUNT(1) AS sold
                FROM {SCHEMA_LOT}.lotteries_tickets lt
                WHERE lt.lotteries_id = :lid
                """),
            {"lid": lotteries_id},)
        sold = int(sold_r.scalar() or 0)
        if sold <= 0:
            logger.info(
                (
                    "lotteries_lotteries(%s): нет билетов, "
                    "победитель не выбран"
                ),
                lotteries_id,
            )
            return None

        seed = secrets.token_bytes(32)
        lid_bytes = int(lotteries_id).to_bytes(8, "big")
        h = hashlib.sha256(seed + lid_bytes).digest()
        idx = int.from_bytes(h[: 8], "big") % sold

        rt: Result = await db.execute(text(f""" # nosec
                SELECT lt.id AS ticket_id, lt.tg_id
                FROM {SCHEMA_LOT}.lotteries_tickets lt
                WHERE lt.lotteries_id = :lid
                ORDER BY lt.id ASC
                OFFSET :idx
                LIMIT 1
                """),
            {"lid": lotteries_id, "idx": int(idx)},)
        ticket = rt.fetchone()
        if not ticket:
            logger.info(
                (
                    "lotteries_lotteries(%s): нет билетов, "
                    "победитель не выбран"
                ),
                lotteries_id,
            )
            # Логически можно перевести лотерею в CLOSED/FINISHED,
            # но оставим
            # на усмотрение админов.
            return None

        ticket_id = int(ticket.ticket_id)
        tg_id = int(ticket.tg_id)

        # 4) Записываем победителя.
        # ON CONFLICT на lotteries_id — защита от гонок.
        await db.execute(text(f""" # nosec
                INSERT INTO {SCHEMA_LOT}.lotteries_winners
                    (
                        lotteries_id,
                        ticket_id,
                        tg_id,
                        prize_type,
                        prize_value,
                        created_at
                    )
                VALUES
                    (
                        :lid,
                        :tid,
                        :tg_id,
                        :ptype,
                        :pvalue,
                        NOW() AT TIME ZONE 'UTC'
                    )
                ON CONFLICT (lotteries_id) DO NOTHING
                """),
            {
                "lid": lotteries_id,
                "tid": ticket_id,
                "tg_id": tg_id,
                "ptype": meta.prize_type,
                "pvalue": str(meta.prize_value),
            },)

        # На случай гонки: если кто-то опередил,
        # просто вернём существующего
        # победителя
        existing_after = await (
            AdminLotterieservice._get_existing_winner(
                db,
                lotteries_id,
            )
        )
        if existing_after and (
            existing_after.ticket_id != ticket_id
            or existing_after.tg_id != tg_id
        ):
            logger.warning(
                (
                    "lotteries_lotteries(%s): race detected, "
                    "another winner already stored "
                    "(ticket_id=%s,tg_id=%s) → returning stored"
                ),
                lotteries_id,
                existing_after.ticket_id,
                existing_after.tg_id,
            )
            return existing_after

        # 5) Переводим лотерею в FINISHED
        await db.execute(text(f""" # nosec
                UPDATE {SCHEMA_LOT}.lotteries
                SET status = 'FINISHED',
                    finished_at = NOW() AT TIME ZONE 'UTC'
                WHERE id = :lid
                """),
            {"lid": lotteries_id},)

        # 6) Создаём запись о призе
        user_wallet: str | None = None

        if meta.prize_type == LotteriesPrizeType.EFHC_BONUS:
            # Приз: бонусные EFHC → bonus_awards
            prize_amount = d8(meta.prize_value)
            await db.execute(text(f""" # nosec
                    INSERT INTO {SCHEMA_ADMIN}.bonus_awards
                        (
                            tg_id,
                            source,
                            amount,
                            status,
                            created_at,
                            meta_json
                        )
                    VALUES
                        (
                            :tg_id,
                            'LOTTERIES',
                            :amt,
                            'PENDING',
                            NOW() AT TIME ZONE 'UTC',
                            jsonb_build_object('lotteries_id', :lid)
                        )
                    """),
                {
                    "tg_id": tg_id,
                    "amt": format_decimal_str(
                        prize_amount,
                        EFHC_DECIMALS,
                    ),
                    "lid": lotteries_id,
                },)
        elif meta.prize_type == LotteriesPrizeType.NFT_VIP:
            # Приз — NFT VIP → prize_claims
            r2: Result = await db.execute(text(f""" # nosec
                    SELECT address
                    FROM {SCHEMA_CORE}.crypto_wallets
                    WHERE tg_id = :tg_id AND is_primary = TRUE
                    ORDER BY id DESC
                    LIMIT 1
                    """),
                {"tg_id": tg_id},)
            wrow = r2.fetchone()
            user_wallet = wrow.address if wrow else None

            await db.execute(text(f""" # nosec
                    INSERT INTO {SCHEMA_ADMIN}.prize_claims
                        (
                            lotteries_id,
                            tg_id,
                            prize_type,
                            prize_value,
                            wallet_address,
                            status,
                            created_at
                        )
                    VALUES
                        (
                            :lid,
                            :tg_id,
                            'NFT_VIP',
                            'NFT_VIP',
                            :wallet,
                            'PENDING',
                            NOW() AT TIME ZONE 'UTC'
                        )
                    """),
                {
                    "lid": lotteries_id,
                    "tg_id": tg_id,
                    "wallet": user_wallet,
                },
            )

        # Логи + уведомления
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="LOTTERIES_LOTTERIES",
            entity="lotteries",
            entity_id=lotteries_id,
            details=f"winner_tg_id={tg_id}; ticket_id={ticket_id}",
        )

        await AdminNotifier.notify_lotteries_winner(
            db,
            lotteries_id=lotteries_id,
            tg_id=tg_id,
            prize=str(meta.prize_value),
            title=meta.title,
        )

        # 7) Авто-перезапуск, если включён
        if bool(meta.auto_restart):
            await AdminLotterieservice._auto_restart_clone(db, meta)

        return WinnerTicket(
            lotteries_id=lotteries_id,
            ticket_id=ticket_id,
            tg_id=tg_id,
            prize_type=str(meta.prize_type),
            prize_value=str(meta.prize_value),
            user_wallet=user_wallet,
        )

    @staticmethod
    async def _auto_restart_clone(db: AsyncSession, meta: Any) -> None:
        """Create a new lotteries clone when auto_restart is enabled."""
        delay = int(getattr(meta, "auto_restart_delay_sec", 0) or 0)
        # created_at всё равно NOW(), delay реализуется на уровне
        # планировщика/роутов
        sql = text(f""" # nosec
            INSERT INTO {SCHEMA_LOT}.lotteries
                (title,
                 prize_type,
                 prize_value,
                 ticket_price,
                 max_participants,
                 max_tickets_per_user,
                 status,
                 auto_restart,
                 auto_restart_delay_sec,
                 created_at)
            VALUES
                (:title,
                 :ptype,
                 :pvalue,
                 :tprice,
                 :max_part,
                 :max_tpu,
                 'ACTIVE',
                 :auto_restart,
                 :auto_delay,
                 NOW() AT TIME ZONE 'UTC')
            """)
        await db.execute(sql,
            {
                "title": meta.title,
                "ptype": meta.prize_type,
                "pvalue": str(meta.prize_value),
                "tprice": str(meta.ticket_price),
                "max_part": meta.max_participants,
                "max_tpu": meta.max_tickets_per_user,
                "auto_restart": True,
                "auto_delay": delay,
            },)
        logger.info(
            "auto_restart: создан клон лотереи из шаблона id=%s",
            meta.id
        )

    # -----------------------------------------------------------------
    # РУЧНАЯ КОРРЕКЦИЯ БИЛЕТОВ (БЕЗ ДВИЖЕНИЯ EFHC)
    # -----------------------------------------------------------------

    @staticmethod
    async def adjust_tickets_admin(
        db: AsyncSession,
        req: LotteriesTicketCorrectionRequest,
        admin: AdminUser,
    ) -> dict[str, Any]:
        """
        Ручная корректировка билетов админом.

        Инварианты:
          • НИКАКИХ денежных операций здесь нет — только операции
            над билетами.
          • Для компенсации/доначисления EFHC использовать банк
            (admin_bank_service).
          • Действия логируются в admin_logs.

        Логика:
          • delta_tickets > 0:
               - добавляем N новых билетов пользователю
                 в указанной лотерее;
          • delta_tickets < 0:
               - помечаем N последних билетов как
                 «исправленные/отменённые».
                 Реализация через:
                   - отдельную таблицу lotteries_tickets_corrections,
                    - или поле is_cancelled в lotteries_tickets
                      (зависит от миграций).
                 В этом коде предполагается флаг is_cancelled BOOLEAN.
        """
        RBAC.require_role(admin, AdminRole.MODERATOR)

        if req.delta_tickets == 0:
            raise ValueError("delta_tickets не может быть 0")

        # Проверяем, что лотерея существует
        rlot: Result = await db.execute(text(f""" # nosec
                SELECT id, status
                FROM {SCHEMA_LOT}.lotteries
                WHERE id = :lid
                LIMIT 1
                """),
            {"lid": req.lotteries_id},)
        lrow = rlot.fetchone()
        if not lrow:
            raise ValueError("Лотерея не найдена")

        # Для finished/closed — админ должен понимать последствия,
        # но мы не
        # запрещаем.
        affected = 0

        if req.delta_tickets > 0:
            # Добавляем N билетов
            sql = text(f""" # nosec
                INSERT INTO {SCHEMA_LOT}.lotteries_tickets
                    (lotteries_id, tg_id, created_at)
                VALUES
                    (:lid, :tg_id, NOW() AT TIME ZONE 'UTC')
                """)
            for _ in range(req.delta_tickets):
                await db.execute(
                    sql,
                    {
                        "lid": req.lotteries_id,
                        "tg_id": req.tg_id,
                    },
                )
                affected += 1
        else:
            # delta_tickets < 0 → отмена N последних билетов
            # пользователя
            to_cancel = abs(req.delta_tickets)
            sql_sel = text(f""" # nosec
                SELECT id
                FROM {SCHEMA_LOT}.lotteries_tickets
                WHERE lotteries_id = :lid
                  AND tg_id   = :tg_id
                  AND COALESCE(is_cancelled, FALSE) = FALSE
                ORDER BY id DESC
                LIMIT :lim
                """)
            rtk: Result = await db.execute(
                sql_sel,
                {
                    "lid": req.lotteries_id,
                    "tg_id": req.tg_id,
                    "lim": to_cancel,
                },
            )
            ticket_ids = [int(x.id) for x in rtk.fetchall()]
            if ticket_ids:
                sql_upd = text(f""" # nosec
                    UPDATE {SCHEMA_LOT}.lotteries_tickets
                    SET is_cancelled = TRUE
                    WHERE id = ANY(:ids)
                    """)
                await db.execute(sql_upd, {"ids": ticket_ids})
                affected = len(ticket_ids)

        details = (
            f"tg_id={req.tg_id}; delta={req.delta_tickets}; "
            f"reason={req.reason}"
        )
        await AdminLogger.write(
            db,
            admin_id=admin.id,
            action="LOTTERIES_TICKETS_ADJUST",
            entity="lotteries_tickets",
            entity_id=req.lotteries_id,
            details=details,
        )

        return {"ok": True, "affected": affected}




# Канонический алиас имени класса (SSOT ожидает AdminLotteriesService)
AdminLotteriesService = AdminLotterieservice
__all__ = [
    "Lotteriestatus",
    "LotteriesPrizeType",
    "LotteriesListFilters",
    "LotteriesInfo",
    "LotteriestatusSummary",
    "CreateLotteriesRequest",
    "UpdateLotteriesRequest",
    "LotteriesTicketCorrectionRequest",
    "WinnerTicket",
    "AdminLotterieservice",
    "AdminLotteriesService",
]
