"""backend/app/services/skins_service.py

Домен «Skins»: каталог, покупка, активация.

Канон оплаты при покупке: списание EFHC по правилу
«сначала bonus, затем main», атомарно через transactions_service.

Важно:
- Каталог строится автоматически по наличию файлов
  (см. standards/skins_catalog.py) — без ручного кода
  на каждую картинку.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from app.core.errors_core import EFHCError
from app.models.skins_models import UserCosmetics, UserSkin
from app.standards.skins_catalog import build_catalog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


def _d8(x: str | Decimal) -> Decimal:
    return Decimal(str(x)).quantize(Decimal("0.00000001"))


def get_catalog() -> list[dict[str, Any]]:
    # без кэша: каталог должен подхватывать новые файлы
    return [i.__dict__ for i in build_catalog()]


async def get_my(db: AsyncSession, *, tg_id: int) -> dict[str, Any]:
    # active
    res = await db.execute(
        select(UserCosmetics).where(UserCosmetics.tg_id == int(tg_id))
    )
    row = res.scalar_one_or_none()
    active_skin_id = int(row.active_skin_id) if row else 1

    res2 = await db.execute(
        select(UserSkin)
        .where(UserSkin.tg_id == int(tg_id))
        .order_by(UserSkin.skin_id.asc())
    )
    owned_rows = res2.scalars().all()
    owned = [
        {"skin_id": int(r.skin_id), "purchased_at": r.purchased_at}
        for r in owned_rows
    ]
    return {"active_skin_id": active_skin_id, "owned": owned}


async def buy_skin(
    db: AsyncSession,
    *,
    tg_id: int,
    skin_id: int,
    idempotency_key: str,
) -> None:
    sid = int(skin_id)
    if sid < 1:
        raise EFHCError(
            "SKIN_NOT_FOUND",
            detail="Skin id is out of range",
        )

    catalog = {int(i["skin_id"]): i for i in get_catalog()}
    item = catalog.get(sid)
    if not item:
        raise EFHCError("SKIN_NOT_FOUND", detail="Skin not found")

    price = _d8(item["price_efhc"])

    # free skin
    if price <= Decimal("0"):
        await _ensure_owned(db, tg_id=int(tg_id), skin_id=sid)
        await db.commit()
        return

    # already owned -> idempotent
    res = await db.execute(
        select(UserSkin).where(
            UserSkin.tg_id == int(tg_id),
            UserSkin.skin_id == sid,
        )
    )
    if res.scalar_one_or_none():
        return

    # Канон оплаты: сначала bonus, затем main (атомарно)
    from app.services.transactions_service import (
        spend_user_to_bank_bonus_then_main,
    )

    await spend_user_to_bank_bonus_then_main(
        db,
        tg_id=int(tg_id),
        amount=price,
        reason=f"skin_purchase:{sid}",
        idempotency_key=str(idempotency_key),
        meta={"skin_id": sid},
    )

    await _ensure_owned(db, tg_id=int(tg_id), skin_id=sid)
    await db.commit()


async def _ensure_owned(
    db: AsyncSession,
    *,
    tg_id: int,
    skin_id: int,
) -> None:
    res = await db.execute(
        select(UserSkin).where(
            UserSkin.tg_id == int(tg_id),
            UserSkin.skin_id == int(skin_id),
        )
    )
    if res.scalar_one_or_none():
        return
    db.add(UserSkin(tg_id=int(tg_id), skin_id=int(skin_id)))


async def activate_skin(
    db: AsyncSession,
    *,
    tg_id: int,
    skin_id: int,
) -> None:
    sid = int(skin_id)
    if sid < 1:
        raise EFHCError(
            "SKIN_NOT_FOUND",
            detail="Skin id is out of range",
        )

    # must own (skin 1 is free)
    if sid != 1:
        res = await db.execute(
            select(UserSkin).where(
                UserSkin.tg_id == int(tg_id),
                UserSkin.skin_id == sid,
            )
        )
        if res.scalar_one_or_none() is None:
            raise EFHCError("SKIN_NOT_OWNED", detail="Skin not owned")

    res = await db.execute(
        select(UserCosmetics).where(UserCosmetics.tg_id == int(tg_id))
    )
    row = res.scalar_one_or_none()
    if row is None:
        db.add(UserCosmetics(tg_id=int(tg_id), active_skin_id=sid))
    else:
        row.active_skin_id = sid
    await db.commit()
