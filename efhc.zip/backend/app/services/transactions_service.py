# backend/app/services/transactions_service.py
# =====================================================================
# EFHC Bot — Банковский сервис
# (READ-THROUGH идемпотентность)
# ---------------------------------------------------------------------
# ЕДИНСТВЕННАЯ точка входа
# для денежных движений EFHC.
# Канон (функции):
# • credit_user_from_bank(...)        — кредит на MAIN
# • credit_user_bonus_from_bank(...)  — кредит на BONUS
# • debit_user_to_bank(...)           — дебет с MAIN
# • debit_user_bonus_to_bank(...)     — дебет с BONUS
# • exchange_kwh_to_efhc(...) — кредит EFHC
#   1:1 за энергию
# ---------------------------------------------------------------------
# Правила:
# • Пользователь не может уйти в минус
#   (main/bonus).
# • Банк может уйти в минус
#   операции не блокируются.
# • Операция идемпотентна по idempotency_key
#   (UNIQUE в логе).
# • Decimal(30,8), округление вниз — deps.d8().
# • Зеркальный лог Банка: mirror:<idempotency_key>.
# • Никаких P2P
#   только «пользователь ↔ банк».
# =====================================================================

from __future__ import annotations

import asyncio
import contextlib
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.deps import d8
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)

# ---------------------------------------------------------------------
# Tx context helper
# ---------------------------------------------------------------------
# AsyncSession начинает транзакцию автоматически при первом execute()
# (autobegin). Поэтому прямой await db.begin() часто падает ошибкой
# "A transaction is already begun on this Session.".
#
# Канон: денежные операции атомарны.
# Решение: если транзакция уже есть — используем SAVEPOINT
# (begin_nested). Если нет — обычный begin().
def _tx_context(db: AsyncSession):
    if getattr(db, "in_transaction", None) and db.in_transaction():
        return db.begin_nested()
    return db.begin()

settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")


async def _safe_rollback(db: AsyncSession, ctx: str) -> None:
    try:
        await db.rollback()
    except Exception as exc:
        logger.warning("DB rollback failed (%s): %s", ctx, exc)

# Telegram ID банковского аккаунта (из .env)
BANK_EFHC = int(
    getattr(settings, "BANK_EFHC", "0") or "0"
)
if BANK_EFHC <= 0:
    logger.warning(
            "BANK_EFHC не задан — "
"зеркальные логи банка "
"отключены."
    )


# ---------------------------------------------------------------------
# Системный объект bank_balance (вариант A).
# Истина баланса банка хранится в efhc_core.bank_balance.
# В банке есть ТОЛЬКО EFHC main.
# BANK_EFHC используется только как логический алиас (tg_id)
# для зеркальных записей в efhc_transfers_log и витрин.
KEY_BANK_MAIN = "EFHC_MAIN"

_BANK_GET_SQL = text(
    "SELECT key, balance FROM " # nosec
    f"{SCHEMA}.bank_balance "
    "WHERE key = :k "
    "FOR UPDATE"
)

_BANK_UPD_SQL = text(
    "UPDATE " # nosec
    f"{SCHEMA}.bank_balance "
    "SET balance = :bal, "
    "updated_at = timezone('utc', now()) "
    "WHERE key = :key"
)

_BANK_INS_SQL = text(
    "INSERT INTO " # nosec
    f"{SCHEMA}.bank_balance (key, balance) "
    "VALUES (:key, :bal) "
    "ON CONFLICT (key) DO NOTHING"
)

async def _ensure_bank_locked(
    db: AsyncSession,
) -> tuple[Decimal, Decimal]:
    """Блокирует и возвращает баланс банка (main, bonus=0)."""
    await db.execute(
        _BANK_INS_SQL,
        {"key": KEY_BANK_MAIN, "bal": "0"},
    )
    res = await db.execute(
        _BANK_GET_SQL,
        {"k": KEY_BANK_MAIN},
    )
    row = res.first()
    main = Decimal(str(row[1])) if row else Decimal("0")
    return (main, Decimal("0"))

async def _update_bank_balances(
    db: AsyncSession,
    *,
    new_main: Decimal,
    new_bonus: Decimal,
) -> None:
    """Обновляет баланс банка (истина = bank_balance)."""
    await db.execute(
        _BANK_UPD_SQL,
        {"key": KEY_BANK_MAIN, "bal": str(d8(new_main))},
    )

# ---------------------------------------------------------------------
# Канон direction в efhc_transfers_log: только credit/debit.
# Контрагентность (банк<->пользователь) фиксируется в reason/meta.
# Для зеркальной записи банка используем инверсию:
#   user credit  => bank debit
#   user debit   => bank credit
# ---------------------------------------------------------------------

def _invert_direction(direction: str) -> str:
    if direction == "credit":
        return "debit"
    return "credit"

# ---------------------------------------------------------------------
# DTO результата операции
# ---------------------------------------------------------------------


@dataclass
class TxResult:
    ok: bool
    tg_id: int
    amount: Decimal
    balance_type: str  # "main" | "bonus"
    reason: str
    idempotency_key: str
    user_main_balance: Decimal
    user_bonus_balance: Decimal
    bank_main_balance: Decimal | None = None
    created_log_id: int | None = None
    detail: str = "ok"
    processed_with_deficit: bool = False


def _idempotent_detail(detail: str) -> bool:
    return str(detail or "").startswith("idempotent")


# ---------------------------------------------------------------------
# Низкоуровневые SQL
# (осознанно без ORM, ради прозрачности)
# ---------------------------------------------------------------------

_GET_USER_FOR_UPDATE_SQL = text(
    f"""
    SELECT
        tg_id,
        COALESCE(main_balance, 0)  AS main_balance,
        COALESCE(bonus_balance, 0) AS bonus_balance
    FROM {SCHEMA}.users
            WHERE tg_id = :tg_id
    FOR UPDATE
    """
)

_GET_USER_SQL = text(
    f"""
    SELECT
        tg_id,
        COALESCE(main_balance, 0)  AS main_balance,
        COALESCE(bonus_balance, 0) AS bonus_balance
    FROM {SCHEMA}.users
    WHERE tg_id = :tg_id
    """
)

_UPSERT_USER_SQL = text(
    f"""
    INSERT INTO {SCHEMA}.users (
        tg_id,
        username,
        is_vip,
        is_active,
        main_balance,
        bonus_balance,
        total_generated_kwh,
        created_at,
        updated_at
    )
    VALUES (
                :tg_id,
        :username,
        FALSE,
        TRUE,
        0,
        0,
        0,
        NOW(),
        NOW()
    )
    ON CONFLICT (tg_id) DO NOTHING
    """
)




_UPDATE_USER_BALANCES_SQL = text(
    f"""
    UPDATE {SCHEMA}.users
    SET
        main_balance  = :mb,
        bonus_balance = :bb,
        updated_at    = NOW()
            WHERE tg_id = :tg_id
    """
)



_INSERT_LOG_SQL = text(
    f"""
    INSERT INTO {SCHEMA}.efhc_transfers_log (
        tg_id,
        amount,
        direction,
        balance_type,
        reason,
        idempotency_key,
        created_at,
        meta
    )
    VALUES (
        :tg_id,
        :amount,
        :direction,
        :balance_type,
        :reason,
        :idk,
        NOW(),
        COALESCE(CAST(:meta AS text), '{{}}')
    )
    ON CONFLICT (idempotency_key)
    DO NOTHING
    RETURNING id
    """
)

_SELECT_LOG_BY_IDK_SQL = text(
    f"""
    SELECT
        id,
        tg_id,
        amount,
        direction,
        balance_type,
        reason,
        idempotency_key,
        created_at
    FROM {SCHEMA}.efhc_transfers_log
    WHERE idempotency_key = :idk
    LIMIT 1
    """
)

_MARK_IDK_CONFLICT_SQL = text(
    f"""
    UPDATE {SCHEMA}.efhc_transfers_log
    SET meta = (
        COALESCE(CAST(meta AS jsonb), '{{}}'::jsonb)
        || '{{"idk_conflict":"true"}}'::jsonb
    )::text
    WHERE idempotency_key = :idk
    """
)


_APPEND_LOG_EXTRA_PG_SQL = text(
    f"""
    UPDATE {SCHEMA}.efhc_transfers_log
    SET meta = (
        COALESCE(CAST(meta AS jsonb), '{{}}'::jsonb)
        || CAST(:extra AS jsonb)
    )::text
    WHERE id = :log_id
    """
)


_APPEND_LOG_EXTRA_BY_IDK_PG_SQL = text(
    f"""
    UPDATE {SCHEMA}.efhc_transfers_log
    SET meta = (
        COALESCE(CAST(meta AS jsonb), '{{}}'::jsonb)
        || CAST(:extra AS jsonb)
    )::text
    WHERE idempotency_key = :idk
    """
)


async def append_transfer_meta(
    db: AsyncSession,
    *,
    log_id: int,
    meta: dict[str, Any],
) -> None:
    """Каноничный путь модификации efhc_transfers_log.meta.

    Правило проекта: любые записи/правки efhc_transfers_log должны
    происходить только через transactions_service.

    Реализация:
    - Postgres: jsonb merge (||)
        """

    if not log_id or int(log_id) <= 0:
        return

    payload = dict(meta or {})


    await db.execute(
        _APPEND_LOG_EXTRA_PG_SQL,
        {"log_id": int(log_id), "extra": json.dumps(payload)},
    )



async def append_transfer_extra_info(
    db,
    transfer_id: int,
    extra_info: dict,
) -> None:
    """Backward compatible name. Calls append_transfer_meta."""
    await append_transfer_meta(
        db,
        log_id=int(transfer_id),
        meta=dict(extra_info or {}),
    )

async def append_transfer_meta_by_idempotency_key(
    db: AsyncSession,
    *,
    idempotency_key: str,
    meta: dict[str, Any],
) -> None:
    """Каноничный путь модификации efhc_transfers_log.meta по
    idempotency_key."""

    if not idempotency_key or not str(idempotency_key).strip():
        return
    payload = dict(meta or {})



    await db.execute(
        _APPEND_LOG_EXTRA_BY_IDK_PG_SQL,
        {"idk": str(idempotency_key), "extra": json.dumps(payload)},
    )




def _available_from_total_exchanged(
    total_generated_kwh: Decimal,
    exchanged_kwh_total: Decimal,
) -> Decimal:
    """SSOT mirror: available_kwh = max(total - exchanged, 0).

    All values are scale=8 (DOWN) via d8().
    """
    total_v = d8(total_generated_kwh)
    exch_v = d8(exchanged_kwh_total)
    avail = d8(total_v - exch_v)
    return avail if avail > Decimal('0') else Decimal('0')
# ---------------------------------------------------------------------
# Утилиты блокировки пользователя
# и фиксации балансов
# ---------------------------------------------------------------------


async def _ensure_user_locked(
    db: AsyncSession,
    tg_id: int,
) -> tuple[Decimal, Decimal]:
    """Возвращает (main, bonus) с FOR UPDATE."""
    get_sql = _GET_USER_FOR_UPDATE_SQL
    upsert_sql = _UPSERT_USER_SQL

    res = await db.execute(
        get_sql,
        {"tg_id": int(tg_id)},
    )
    row = res.fetchone()
    if row:
        return d8(row[1] or 0), d8(row[2] or 0)

    await db.execute(
        upsert_sql,
        {"tg_id": int(tg_id), "username": None},
    )
    res2 = await db.execute(
        get_sql,
        {"tg_id": int(tg_id)},
    )
    row2 = res2.fetchone()
    if not row2:
        raise RuntimeError(
                "Не удалось создать/"
                "заблокировать "
                f"пользователя tg_id={tg_id}"
        )

    return d8(row2[1] or 0), d8(row2[2] or 0)

async def _update_user_balances(
    db: AsyncSession,
    tg_id: int,
    main_balance: Decimal,
    bonus_balance: Decimal,
) -> None:
    """Обновляет балансы пользователя."""
    await db.execute(
        _UPDATE_USER_BALANCES_SQL,
        {
            "tg_id": int(tg_id),
            "mb": str(d8(main_balance)),
            "bb": str(d8(bonus_balance)),
        },
    )


async def _insert_log(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    direction: str,
    balance_type: str,
    reason: str,
    idk: str,
    meta: dict[str, Any] | None = None,
) -> int:
    """Пишет операцию в журнал (Postgres-only)."""
    extra_payload = json.dumps(meta or {})
    res = await db.execute(
        _INSERT_LOG_SQL,
        {
            'tg_id': int(tg_id),
            'amount': str(d8(amount)),
            'direction': str(direction),
            'balance_type': str(balance_type),
            'reason': str(reason),
            'idk': str(idk),
            'meta': extra_payload,
        },
    )
    row = res.fetchone()
    if not row:
        existing = await _find_log_by_idk(db, idk)
        if existing:
            return int(existing['id'])
        raise RuntimeError('LOG_INSERT_FAILED')
    return int(row[0])


async def _find_log_by_idk(
    db: AsyncSession,
    idk: str,
) -> dict[str, Any] | None:
    """Ищет операцию по idempotency_key."""
    res = await db.execute(_SELECT_LOG_BY_IDK_SQL, {"idk": idk})
    row = res.fetchone()
    if not row:
        return None
    return {
        "id": int(row[0]),
        "tg_id": (int(row[1]) if row[1] is not None else None),
        "amount": Decimal(str(row[2])),
        "direction": str(row[3]),
        "balance_type": str(row[4]),
        "reason": str(row[5]),
        "idempotency_key": str(row[6]),
        "created_at": row[7],
    }


# ---------------------------------------------------------------------
# READ-THROUGH обвязка
# идемпотентной операции
# ---------------------------------------------------------------------

RunCore = Callable[
    ...,
    Awaitable[tuple[Decimal, Decimal, Decimal, bool]],
]


async def _run_idempotent(
    db: AsyncSession,
    *,
    idempotency_key: str,
    tg_id: int,
    balance_type: str,
    amount: Decimal,
    reason: str,
    direction: str,
    exec_core: RunCore,
) -> TxResult:
    """Выполняет операцию атомарно (с учётом autobegin).

    Важно:
    - Если транзакция уже открыта (autobegin/внешний контекст),
      используем SAVEPOINT (begin_nested), чтобы не падать.
    - Ошибки «недостаточно средств» не ретраим и не заворачиваем
      в RuntimeError — пробрасываем как ValueError.
    """

    max_tries = 3
    backoff = 0.15
    last_exc: Exception | None = None

    for attempt in range(1, max_tries + 1):
        try:
            async with _tx_context(db):
                user_main, user_bonus = await _ensure_user_locked(
                    db,
                    tg_id,
                )

                bank_main = Decimal("0")
                bank_bonus = Decimal("0")
                bank_id = None
                if BANK_EFHC > 0:
                    bank_id = int(BANK_EFHC)
                bank_main, bank_bonus = await _ensure_bank_locked(db)

                (
                    new_user_main,
                    new_user_bonus,
                    new_bank_main,
                    deficit,
                ) = await exec_core(
                    db=db,
                    tg_id=int(tg_id),
                    user_main=user_main,
                    user_bonus=user_bonus,
                    bank_main=bank_main,
                    bank_id=bank_id,
                    bank_bonus=bank_bonus,
                    amount=d8(amount),
                    balance_type=balance_type,
                    reason=reason,
                    idempotency_key=idempotency_key,
                )

                # Канон: пользователь не уходит в минус.
                is_negative = (
                    new_user_main < Decimal("0")
                    or new_user_bonus < Decimal("0")
                )
                if is_negative:
                    raise ValueError(
                        "User balance negative is forbidden"
                    )

                # Канон: банк может уходить в минус.
                # Внешнее дополнительное обеспечение существует вне БД.

                await _update_user_balances(
                    db,
                    tg_id,
                    new_user_main,
                    new_user_bonus,
                )
                await _update_bank_balances(
                    db,
                    new_main=new_bank_main,
                    new_bonus=bank_bonus,
                )

                meta_user: dict[str, Any] = {}
                if deficit:
                    meta_user["bank_deficit_mode"] = "true"

                log_id = await _insert_log(
                    db,
                    tg_id=int(tg_id),
                    amount=d8(amount),
                    direction=direction,
                    balance_type=balance_type,
                    reason=reason,
                    idk=idempotency_key,
                    meta=meta_user,
                )

                if BANK_EFHC > 0:
                    mirror_key = f"mirror:{idempotency_key}"
                    mirror_direction = _invert_direction(direction)
                    meta_bank = {
                        "mirror_for_user": int(tg_id),
                        "mirror_of_idk": idempotency_key,
                    }
                    try:
                        await _insert_log(
                            db,
                            tg_id=int(BANK_EFHC),
                            amount=d8(amount),
                            direction=mirror_direction,
                            balance_type="main",
                            reason=f"mirror:{reason}",
                            idk=mirror_key,
                            meta=meta_bank,
                        )
                    except Exception as me:
                        if "unique" not in str(me).lower():
                            logger.warning(
                                "Mirror log insert error: %s",
                                me,
                            )

                return TxResult(
                    ok=True,
                    tg_id=int(tg_id),
                    amount=d8(amount),
                    balance_type=balance_type,
                    reason=reason,
                    idempotency_key=idempotency_key,
                    user_main_balance=d8(new_user_main),
                    user_bonus_balance=d8(new_user_bonus),
                    bank_main_balance=d8(new_bank_main),
                    created_log_id=int(log_id),
                    processed_with_deficit=bool(deficit),
                    detail="ok",
                )

        except ValueError:
            # Недостаток средств/инварианты: не ретраим.
            raise

        except Exception as e:
            msg = str(e).lower()

            if "unique" in msg and "idempotency_key" in msg:
                try:
                    async with _tx_context(db):
                        await db.execute(
                            _MARK_IDK_CONFLICT_SQL,
                            {"idk": idempotency_key},
                        )
                except Exception:
                    await _safe_rollback(db, "idk_conflict_mark")

                prev = await _find_log_by_idk(db, idempotency_key)
                if prev:
                    um, ub = await _ensure_user_locked(db, tg_id)
                    await _safe_rollback(db, "idk_read_through")
                    return TxResult(
                        ok=True,
                        tg_id=int(tg_id),
                        amount=d8(prev["amount"]),
                        balance_type=str(prev["balance_type"]),
                        reason=str(prev["reason"]),
                        idempotency_key=idempotency_key,
                        user_main_balance=d8(um),
                        user_bonus_balance=d8(ub),
                        bank_main_balance=None,
                        created_log_id=int(prev["id"]),
                        detail="idempotent",
                        processed_with_deficit=False,
                    )

                await asyncio.sleep(backoff * attempt)
                last_exc = e
                continue

            transient = (
                "deadlock" in msg
                or "could not serialize" in msg
                or "serialization" in msg
                or "conflict" in msg
            )
            if transient:
                await asyncio.sleep(backoff * attempt)
                last_exc = e
                continue

            last_exc = e
            logger.error(
                "Bank tx fatal error (attempt %s/%s): %s",
                attempt,
                max_tries,
                e,
            )
            break

    raise RuntimeError(
            f"Bank transaction failed after {max_tries} attempts: "
            f"{last_exc}"
    )

# ---------------------------------------------------------------------
# Бизнес-операции (канон)
# ---------------------------------------------------------------------


async def credit_user_from_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_efhc: Decimal | None = None,
    amount: Decimal | None = None,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Кредит MAIN пользователю из Банка."""
    if amount is None and amount_efhc is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_efhc",
            )
        )
    if amount is None:
        amount = amount_efhc

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        new_user_main = d8(user_main + amount_local)
        new_user_bonus = user_bonus
        new_bank_main = d8(bank_main - amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    return await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="main",
        amount=amt,
        reason=reason,
        direction="credit",
        exec_core=_core,
    )


async def credit_user_bonus_from_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_efhc: Decimal | None = None,
    amount: Decimal | None = None,
    reason: str,
    idempotency_key: str,
    meta: dict[str, Any] | None = None,
) -> TxResult:
    """Кредит BONUS пользователю из Банка."""
    if amount is None and amount_efhc is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_efhc",
            )
        )
    if amount is None:
        amount = amount_efhc

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        new_user_main = user_main
        new_user_bonus = d8(user_bonus + amount_local)
        new_bank_main = d8(bank_main - amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    result = await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="bonus",
        amount=amt,
        reason=reason,
        direction="credit",
        exec_core=_core,
    )

    if meta:
        logger.debug("credit_user_bonus_from_bank meta=%s", meta)

    return result


async def debit_user_to_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_efhc: Decimal | None = None,
    amount: Decimal | None = None,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Дебет MAIN пользователя в Банк."""
    if amount is None and amount_efhc is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_efhc",
            )
        )
    if amount is None:
        amount = amount_efhc

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        if user_main - amount_local < Decimal("0"):
            raise ValueError(
                (
                    "Недостаточно средств ",
                    "на основном балансе",
                )
            )

        new_user_main = d8(user_main - amount_local)
        new_user_bonus = user_bonus
        new_bank_main = d8(bank_main + amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    return await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="main",
        amount=amt,
        reason=reason,
        direction="debit",
        exec_core=_core,
    )


async def debit_user_bonus_to_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_efhc: Decimal | None = None,
    amount: Decimal | None = None,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Дебет BONUS пользователя в Банк."""
    if amount is None and amount_efhc is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_efhc",
            )
        )
    if amount is None:
        amount = amount_efhc

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        if user_bonus - amount_local < Decimal("0"):
            raise ValueError(
                (
                    "Недостаточно средств ",
                    "на бонусном балансе",
                )
            )

        new_user_main = user_main
        new_user_bonus = d8(user_bonus - amount_local)
        new_bank_main = d8(bank_main + amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    return await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="bonus",
        amount=amt,
        reason=reason,
        direction="debit",
        exec_core=_core,
    )


async def exchange_kwh_to_efhc(
    db: AsyncSession,
    *,
    tg_id: int,
    amount_kwh: Decimal | None = None,
    amount: Decimal | None = None,
    reason: str,
    idempotency_key: str,
    strict_kwh_check: bool = False,
) -> TxResult:
    """Обмен kWh → EFHC (1:1)."""
    if amount is None and amount_kwh is None:
        raise ValueError(
            (
                "Необходимо указать amount ",
                "или amount_kwh",
            )
        )
    if amount is None:
        amount = amount_kwh

    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Сумма должна быть > 0")

    async def _core(
        **kwargs: Any,
    ) -> tuple[Decimal, Decimal, Decimal, bool]:
        user_main: Decimal = kwargs["user_main"]
        user_bonus: Decimal = kwargs["user_bonus"]
        bank_main: Decimal = kwargs["bank_main"]
        amount_local: Decimal = kwargs["amount"]

        if strict_kwh_check:
            q = (
                "SELECT COALESCE(available_kwh, 0) " # nosec
                f"FROM {SCHEMA}.users WHERE tg_id = :tg_id"
            )
            row = await db.execute(text(q), {"tg_id": int(tg_id)})
            ak = Decimal(str(row.scalar() or "0"))
            if ak < amount_local:
                raise ValueError(
"Недостаточно доступной " "энергии"
                )

        new_user_main = d8(user_main + amount_local)
        new_user_bonus = user_bonus
        new_bank_main = d8(bank_main - amount_local)
        deficit = new_bank_main < Decimal("0")
        return (new_user_main, new_user_bonus, new_bank_main, deficit)

    return await _run_idempotent(
        db,
        idempotency_key=idempotency_key,
        tg_id=int(tg_id),
        balance_type="main",
        amount=amt,
        reason=reason,
        direction="credit",
        exec_core=_core,
    )


async def exchange_all_available_kwh_to_main(
    db: AsyncSession,
    *,
    tg_id: int,
    idempotency_key: str,
    reason: str = "exchange_all",
) -> TxResult:
    """EXCHANGE_ALL по SSOT:

    - total_generated_kwh (lifetime) НЕ уменьшается (append-only).
    - exchanged_kwh_total растёт (append-only).
    - available_kwh = total_generated_kwh - exchanged_kwh_total.
    - начисление строго в EFHC MAIN 1:1.
    - операция идемпотентна по idempotency_key.

    Важно: атомарность обеспечивается блокировкой строки пользователя.
    """

    if not idempotency_key or not str(idempotency_key).strip():
        raise ValueError("Idempotency-Key обязателен")

    existing = await _find_log_by_idk(db, str(idempotency_key))
    if existing:
        main, _bonus = await get_user_balances_snapshot(
            db,
            tg_id=int(tg_id),
        )
        return TxResult(
            ok=True,
            created_log_id=int(existing["id"]),
            user_main_balance=d8(main),
            user_bonus_balance=Decimal("0"),
        )

    max_tries = 3
    last_exc: Exception | None = None

    for _attempt in range(1, max_tries + 1):
        try:
            bind = db.get_bind()
            dialect = getattr(bind.dialect, "name", "")

            #  не поддерживает FOR UPDATE.
            # Конкурентность в тестах: BEGIN IMMEDIATE + ретраи.
            # обеспечиваем BEGIN IMMEDIATE (с ретраями по max_tries).
            if dialect == "":
                await db.execute(text("BEGIN IMMEDIATE"))
                lock = ""
            else:
                await db.begin()
                lock = " FOR UPDATE"

            q_user = (
                "SELECT " # nosec
                "COALESCE(main_balance, 0), "
                "COALESCE(bonus_balance, 0), "
                "COALESCE(total_generated_kwh, 0), "
                "COALESCE(exchanged_kwh_total, 0) "
                f"FROM {SCHEMA}.users "
                "WHERE tg_id = :tg_id "
                f"{lock}"
            )
            rec = await db.execute(text(q_user), {"tg_id": int(tg_id)})
            row = rec.fetchone()
            if not row:
                raise ValueError("User not found")

            user_main = d8(row[0] or 0)
            user_bonus = d8(row[1] or 0)
            total_kwh = d8(row[2] or 0)
            exchanged_total = d8(row[3] or 0)

            if exchanged_total > total_kwh:
                raise ValueError("SSOT violated: exchanged > total")

            available = _available_from_total_exchanged(
                total_kwh, exchanged_total,
            )

            bank_main = Decimal("0")
            bank_bonus = Decimal("0")
            if BANK_EFHC > 0:
                int(BANK_EFHC)
                bank_main, bank_bonus = await _ensure_user_locked(
                    db,
                    BANK_EFHC,
                )

            if available <= Decimal("0"):
                total_equiv_before = d8(user_main + available)
                audit = {
                    "audit_schema_version": "v1",
                    "exchange_all_audit": True,
                    "op_type": "EXCHANGE_ALL",
                    "status": "rejected",
                    "reason": "no_available_kwh",
                    "before": {
                        "total_generated_kwh": str(total_kwh),
                        "exchanged_kwh_total": str(exchanged_total),
                        "available_kwh": str(available),
                        "main_balance": str(user_main),
                        "total_equivalent": str(total_equiv_before),
                    },
                    "after": {
                        "total_generated_kwh": str(total_kwh),
                        "exchanged_kwh_total": str(exchanged_total),
                        "available_kwh": str(available),
                        "main_balance": str(user_main),
                        "total_equivalent": str(total_equiv_before),
                        "invariant_ok": True,
                    },
                }
                log_id = await _insert_log(
                    db,
                    tg_id=int(tg_id),
                    amount=Decimal("0"),
                    direction="debit",
                    balance_type="main",
                    reason=reason,
                    idk=str(idempotency_key),
                    meta=audit,
                )
                await db.commit()
                return TxResult(
                    ok=False,
                    tg_id=int(tg_id),
                    amount=Decimal("0"),
                    balance_type="main",
                    reason=str(reason),
                    idempotency_key=str(idempotency_key),
                    created_log_id=int(log_id),
                    user_main_balance=user_main,
                    user_bonus_balance=user_bonus,
                    bank_main_balance=(
                        d8(bank_main) if BANK_EFHC > 0 else None
                    ),
                    detail="no_available_kwh",
                )

            new_user_main = d8(user_main + available)
            new_user_bonus = user_bonus

            new_bank_main = d8(bank_main - available)
            deficit = new_bank_main < Decimal("0")

            new_exchanged_total = d8(exchanged_total + available)
            # By definition after exchange-all available becomes 0.
            new_available = _available_from_total_exchanged(
                total_kwh, new_exchanged_total,
            )

            await _update_user_balances(
                db,
                int(tg_id),
                new_user_main,
                new_user_bonus,
            )
            if BANK_EFHC > 0:
                await _update_user_balances(
                    db,
                    int(BANK_EFHC),
                    new_bank_main,
                    bank_bonus,
                )

            q_energy = (
                f"UPDATE {SCHEMA}.users " # nosec
                "SET exchanged_kwh_total = :ex, "
                                "    updated_at = now() "
                "WHERE tg_id = :tg_id"
            )
            await db.execute(
                text(q_energy),
                {
                    "ex": str(d8(new_exchanged_total)),
                                        "tg_id": int(tg_id),
                },
            )

            total_equiv_before = d8(user_main + available)
            total_equiv_after = d8(new_user_main + new_available)

            audit_ok = bool(total_equiv_before == total_equiv_after)
            audit = {
                "audit_schema_version": "v1",
                    "exchange_all_audit": True,
                "op_type": "EXCHANGE_ALL",
                "status": "success",
                "rate": "1.00000000",
                "before": {
                    "total_generated_kwh": str(total_kwh),
                    "exchanged_kwh_total": str(exchanged_total),
                    "available_kwh": str(available),
                    "main_balance": str(user_main),
                    "total_equivalent": str(total_equiv_before),
                },
                "params": {
                    "amount_kwh": str(d8(available)),
                    "amount_efhc": str(d8(available)),
                },
                "after": {
                    "total_generated_kwh": str(total_kwh),
                    "exchanged_kwh_total": str(new_exchanged_total),
                    "available_kwh": str(new_available),
                    "main_balance": str(new_user_main),
                    "total_equivalent": str(total_equiv_after),
                    "invariant_ok": bool(audit_ok),
                },
            }
            extra_user: dict[str, Any] = {}
            if deficit:
                extra_user["bank_deficit_mode"] = "true"
            extra_user.update(audit)

            log_id = await _insert_log(
                db,
                tg_id=int(tg_id),
                amount=d8(available),
                direction="credit",
                balance_type="main",
                reason=reason,
                idk=str(idempotency_key),
                meta=extra_user,
            )

            if BANK_EFHC > 0:
                mirror_key = f"mirror:{idempotency_key}"
                mirror_direction = _invert_direction("credit")
                extra_bank = {
                    "mirror_for_user": int(tg_id),
                    "mirror_of_idk": str(idempotency_key),
                }
                await _insert_log(
                    db,
                    tg_id=int(BANK_EFHC),
                    amount=d8(available),
                    direction=mirror_direction,
                    balance_type="main",
                            reason=f"mirror:{reason}",
                    idk=mirror_key,
                    meta=extra_bank,
                )

            await db.commit()
            return TxResult(
                ok=True,
                created_log_id=int(log_id),
                user_main_balance=new_user_main,
                user_bonus_balance=new_user_bonus,
            )
        except Exception as e:
            last_exc = e
            with contextlib.suppress(Exception):
                await db.rollback()
    raise last_exc or RuntimeError("exchange_all failed")


# ---------------------------------------------------------------------
# Доп. утилита (для роутов/админки)
# ---------------------------------------------------------------------


async def get_user_balances_snapshot(
    db: AsyncSession,
    *,
    tg_id: int,
) -> tuple[Decimal, Decimal]:
    """Возвращает (main_balance, bonus_balance)."""
    """Без блокировки."""
    q = (
        "SELECT " # nosec
        "COALESCE(main_balance, 0), "
        "COALESCE(bonus_balance, 0) "
        f"FROM {SCHEMA}.users "
        "WHERE tg_id = :tg_id"
    )
    row = await db.execute(text(q), {"tg_id": int(tg_id)})
    rec = row.fetchone()
    if not rec:
        return (Decimal("0"), Decimal("0"))
    return d8(rec[0] or 0), d8(rec[1] or 0)


# =====================================================================
# Пояснения:
# • READ-THROUGH:
#   нет предварительного SELECT по idempotency_key.
# • При UNIQUE(idempotency_key) → rollback
#   и возврат существующей записи.
# • Пользователь никогда не уходит
#   в минус; Банк может.
# • direction (строго):
#   - credit: увеличение баланса tg_id
#   - debit:  уменьшение баланса tg_id
# • bank<->user фиксируется в reason/meta, например:
#   reason: контекст операции (bank↔user)
# • зеркальная запись банка (BANK_EFHC) использует
#   инверсию direction (credit<->debit) + reason=mirror:...
# =====================================================================


# =====================================================================
# Канонические операции трат/вывода (SSOT денег)
# =====================================================================

@dataclass(frozen=True)
class SpendBreakdown:
    bonus_part: Decimal
    main_part: Decimal


def split_bonus_then_main(
    *,
    bonus_balance: Decimal,
    main_balance: Decimal,
    amount: Decimal,
) -> SpendBreakdown:
    """Канон: сначала BONUS, затем MAIN.
    Возвращает разбиение суммы на bonus_part + main_part.
    Бросает ValueError при недостатке средств.
    """
    amt = d8(amount)
    if amt <= Decimal("0"):
        raise ValueError("Amount must be > 0")

    b = d8(bonus_balance)
    m = d8(main_balance)
    if b < Decimal("0") or m < Decimal("0"):
        raise ValueError("Balance must be >= 0")

    if d8(b + m) < amt:
        raise ValueError("Insufficient funds (bonus+main)")

    bonus_part = d8(min(b, amt))
    main_part = d8(amt - bonus_part)
    return SpendBreakdown(bonus_part=bonus_part, main_part=main_part)


async def spend_user_to_bank_bonus_then_main(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
    meta: dict[str, Any] | None = None,
) -> TxResult:
    """Списание EFHC при покупках: сначала BONUS, затем MAIN.

    Важно:
    - Атомарно.
    - Идемпотентно по idempotency_key (ключи :bonus/:main).
    - Не падает на autobegin: использует begin_nested при нужде.
    """
    bonus_key = f"{idempotency_key}:bonus"
    main_key = f"{idempotency_key}:main"

    prev_main = await _find_log_by_idk(db, main_key)
    if prev_main:
        um, ub = await _ensure_user_locked(db, int(tg_id))
        return TxResult(
            ok=True,
            tg_id=int(tg_id),
            amount=d8(amount),
            balance_type="mixed",
            reason=reason,
            idempotency_key=idempotency_key,
            user_main_balance=d8(um),
            user_bonus_balance=d8(ub),
            bank_main_balance=None,
            created_log_id=int(prev_main["id"]),
            processed_with_deficit=False,
            detail="idempotent",
        )

    async with _tx_context(db):
        user_main, user_bonus = await _ensure_user_locked(
            db,
            int(tg_id),
        )

        bank_main = Decimal("0")
        bank_bonus = Decimal("0")
        if BANK_EFHC > 0:
            bank_main, bank_bonus = await _ensure_user_locked(
                db,
                int(BANK_EFHC),
            )

        breakdown = split_bonus_then_main(
            bonus_balance=user_bonus,
            main_balance=user_main,
            amount=d8(amount),
        )
        new_user_bonus = d8(user_bonus - breakdown.bonus_part)
        new_user_main = d8(user_main - breakdown.main_part)

        new_bank_main = bank_main
        deficit = False
        if BANK_EFHC > 0:
            new_bank_main = d8(bank_main + d8(amount))
            deficit = new_bank_main < Decimal("0")

        # Канон: банк может уходить в минус.

        await _update_user_balances(
            db,
            int(tg_id),
            new_user_main,
            new_user_bonus,
        )
        if BANK_EFHC > 0:
            await _update_user_balances(
                db,
                int(BANK_EFHC),
                new_bank_main,
                bank_bonus,
            )

        created_id: int | None = None
        extra = dict(meta or {})
        extra.update(
            {
                "spend_bonus_part": str(breakdown.bonus_part),
                "spend_main_part": str(breakdown.main_part),
            }
        )

        if breakdown.bonus_part > Decimal("0"):
            created_id = await _insert_log(
                db,
                tg_id=int(tg_id),
                amount=breakdown.bonus_part,
                direction="debit",
                balance_type="bonus",
                reason=reason,
                idk=bonus_key,
                meta=extra,
            )
        if breakdown.main_part > Decimal("0"):
            created_id = await _insert_log(
                db,
                tg_id=int(tg_id),
                amount=breakdown.main_part,
                direction="debit",
                balance_type="main",
                reason=reason,
                idk=main_key,
                meta=extra,
            )

        if BANK_EFHC > 0:
            mirror_for = int(tg_id)
            if breakdown.bonus_part > Decimal("0"):
                try:
                    await _insert_log(
                        db,
                        tg_id=int(BANK_EFHC),
                        amount=breakdown.bonus_part,
                        direction="debit",
                        balance_type="main",
                            reason=f"mirror:{reason}",
                        idk=f"mirror:{bonus_key}",
                        meta={
                            "mirror_for_user": mirror_for,
                            "mirror_of_idk": bonus_key,
                        },
                    )
                except Exception as me:
                    if "unique" not in str(me).lower():
                        logger.warning(
                            "Mirror log insert error: %s",
                            me,
                        )
            if breakdown.main_part > Decimal("0"):
                try:
                    await _insert_log(
                        db,
                        tg_id=int(BANK_EFHC),
                        amount=breakdown.main_part,
                        direction="debit",
                        balance_type="main",
                            reason=f"mirror:{reason}",
                        idk=f"mirror:{main_key}",
                        meta={
                            "mirror_for_user": mirror_for,
                            "mirror_of_idk": main_key,
                        },
                    )
                except Exception as me:
                    if "unique" not in str(me).lower():
                        logger.warning(
                            "Mirror log insert error: %s",
                            me,
                        )

        return TxResult(
            ok=True,
            tg_id=int(tg_id),
            amount=d8(amount),
            balance_type="mixed",
            reason=reason,
            idempotency_key=idempotency_key,
            user_main_balance=d8(new_user_main),
            user_bonus_balance=d8(new_user_bonus),
            bank_main_balance=(
                d8(new_bank_main) if BANK_EFHC > 0 else None
            ),
            created_log_id=int(created_id or 0),
            processed_with_deficit=bool(deficit),
            detail="ok",
        )

async def withdraw_main_only_to_bank(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
    meta: dict[str, Any] | None = None,
) -> TxResult:
    """Вывод/холд средств: только MAIN (bonus не трогаем)."""
    # Используем каноничный дебет MAIN (он уже атомарен и идемпотентен).
    return await debit_user_to_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=idempotency_key,
        meta=meta,
    )

# ---------------------------------------------------------------------
# Backward-compatible helpers (route-level names)
# ---------------------------------------------------------------------

async def credit_user_main_from_bank_by_tg_id(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Кредит MAIN пользователю из Банка (alias для admin_routes)."""
    return await credit_user_from_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=str(idempotency_key),
    )


async def credit_user_bonus_from_bank_by_tg_id(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Кредит BONUS пользователю из Банка (alias для admin_routes)."""
    return await credit_user_bonus_from_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=str(idempotency_key),
    )


async def debit_user_main_to_bank_by_tg_id(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Дебет MAIN пользователя в Банк (alias для admin_routes)."""
    return await debit_user_to_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=str(idempotency_key),
    )


async def debit_user_bonus_to_bank_by_tg_id(
    db: AsyncSession,
    *,
    tg_id: int,
    amount: Decimal,
    reason: str,
    idempotency_key: str,
) -> TxResult:
    """Дебет BONUS пользователя в Банк (alias для admin_routes)."""
    return await debit_user_bonus_to_bank(
        db,
        tg_id=int(tg_id),
        amount=amount,
        reason=reason,
        idempotency_key=str(idempotency_key),
    )
