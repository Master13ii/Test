# backend/app/scheduler/check_ton_inbox.py
# =====================================================================
# Оркестратор входящих TON-платежей.
# Будит watcher_service, читает новые транзакции и догоняет «хвосты».
# Сам не делает денежных действий и не выдаёт NFT.
# =====================================================================

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass
from typing import Any

from app.core.config_core import get_settings
from app.core.logging_core import get_logger
from app.core.sql_aliases_core import canon_schema
from app.deps import get_db
from app.services import watcher_service as watcher
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
settings = get_settings()
SCHEMA = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")


def _env_int(attr: str, default: int) -> int:
    val = getattr(settings, attr, default)
    try:
        return int(val or default)
    except Exception:
        return int(default)


# ---------------------------------------------------------------------
# Параметры тика/защиты (значения по умолчанию безопасные)
# ---------------------------------------------------------------------
INTERVAL_SEC: int = _env_int("CHECK_TON_INBOX_INTERVAL_SEC", 600)
TASK_TIMEOUT_SEC: int = _env_int("CHECK_TON_INBOX_TIMEOUT_SEC", 900)

TON_POLL_LIMIT: int = _env_int("TON_WATCHER_POLL_LIMIT", 200)
TON_RETRY_LIMIT: int = _env_int("TON_WATCHER_RETRY_LIMIT", 500)

RECONCILE_EVERY_TICKS: int = _env_int("TON_RECONCILE_EVERY_TICKS", 6)
RECONCILE_HOURS: int = _env_int("TON_RECONCILE_HOURS", 24)

LOCK_KEY1: int = _env_int("TON_INBOX_ADVISORY_KEY1", 0xEF0C)
LOCK_KEY2: int = _env_int("TON_INBOX_ADVISORY_KEY2", 0x01)

_LOCAL_LOCK = asyncio.Lock()


@asynccontextmanager
async def _db_session_from_deps() -> AsyncIterator[AsyncSession]:
    """AsyncSession через get_db(), как в FastAPI."""
    agen = get_db()
    db = await agen.__anext__()
    try:
        yield db
    finally:
        try:
            await agen.aclose()
        except Exception:
            logger.debug(
                "deps.get_db: aclose failed; ignored in scheduler",
                exc_info=True,
            )


async def _try_acquire_advisory_lock(db: AsyncSession) -> bool:
    q = "SELECT pg_try_advisory_lock(:k1, :k2)"
    row = await db.execute(
        text(q),
        {"k1": LOCK_KEY1, "k2": LOCK_KEY2},
    )
    return bool(row.scalar())


async def _release_advisory_lock(db: AsyncSession) -> None:
    q = "SELECT pg_advisory_unlock(:k1, :k2)"
    try:
        await db.execute(
            text(q),
            {"k1": LOCK_KEY1, "k2": LOCK_KEY2},
        )
    except Exception:
        # Не критично: лок будет снят при закрытии сессии.
        logger.debug(
            "pg_advisory_unlock failed; ignored in scheduler",
            exc_info=True,
        )


def _json_dump_safe(obj: Any) -> str:
    try:
        return json.dumps(
            obj,
            ensure_ascii=False,
            separators=(",", ":"),
        )
    except Exception:
        return "{}"


async def _insert_scheduler_log(
    db: AsyncSession,
    *,
    status: str,
    error_text: str | None,
    duration_sec: float,
    stats: dict[str, int],
) -> None:
    """Пишем efhc_core.scheduler_task_log, если таблица существует."""
    q = (
        "INSERT INTO " # nosec
        f"{SCHEMA}.scheduler_task_log "
        "(task_name, status, error_text, executed_at, duration_sec, "
        "meta, created_at, updated_at) "
        "VALUES "
        "('check_ton_inbox', :status, :error_text, NOW(), :dur, "
        ":meta::jsonb, NOW(), NOW())"
    )
    with suppress(Exception):
        await db.execute(
            text(q),
            {
                "status": status,
                "error_text": error_text,
                "dur": float(duration_sec),
                "meta": _json_dump_safe(stats),
            },
        )


@dataclass
class TickResult:
    stats: dict[str, int]
    duration_sec: float
    status: str
    error_text: str | None = None


async def run_tick(
    db: AsyncSession,
    *,
    do_reconcile: bool = False,
) -> TickResult:
    start = time.perf_counter()
    stats: dict[str, int] = {}
    try:
        s1 = await watcher.process_incoming_payments(
            db,
            limit=TON_POLL_LIMIT,
            since_utime=None,
        )
        stats["new_ok"] = sum(
            v
            for k, v in s1.items()
            if not k.startswith("error")
        )
        for k, v in s1.items():
            kk = f"new_{k}"
            stats[kk] = stats.get(kk, 0) + int(v)

        s2 = await watcher.reprocess_unfinished_logs(
            db,
            limit=TON_RETRY_LIMIT,
        )
        stats["retry_ok"] = sum(
            v
            for k, v in s2.items()
            if not k.startswith("error")
        )
        for k, v in s2.items():
            kk = f"retry_{k}"
            stats[kk] = stats.get(kk, 0) + int(v)

        if do_reconcile:
            s3 = await watcher.reconcile_last_hours(
                db,
                hours=RECONCILE_HOURS,
                limit=TON_POLL_LIMIT,
            )
            stats["reconcile_ok"] = sum(
                v
                for k, v in s3.items()
                if not k.startswith("error")
            )
            for k, v in s3.items():
                kk = f"reconcile_{k}"
                stats[kk] = stats.get(kk, 0) + int(v)

        dur = time.perf_counter() - start
        await _insert_scheduler_log(
            db,
            status="ok",
            error_text=None,
            duration_sec=dur,
            stats=stats,
        )
        return TickResult(stats=stats, duration_sec=dur, status="ok")

    except asyncio.CancelledError:
        dur = time.perf_counter() - start
        await _insert_scheduler_log(
            db,
            status="cancelled",
            error_text=None,
            duration_sec=dur,
            stats=stats,
        )
        return TickResult(
            stats=stats,
            duration_sec=dur,
            status="cancelled",
        )

    except Exception as e:
        dur = time.perf_counter() - start
        msg = f"{e.__class__.__name__}: {e}"
        logger.exception("check_ton_inbox: tick failed: %s", msg)
        await _insert_scheduler_log(
            db,
            status="error",
            error_text=msg,
            duration_sec=dur,
            stats=stats,
        )
        return TickResult(
            stats=stats,
            duration_sec=dur,
            status="error",
            error_text=msg,
        )


async def run_forever(
    session_factory: (
        Callable[[], AsyncIterator[AsyncSession]]
        | None
    ) = None,
) -> None:
    tick_no = 0
    session_factory = session_factory or _db_session_from_deps

    while True:
        await asyncio.sleep(0)
        tick_no += 1
        do_reconcile = (tick_no % RECONCILE_EVERY_TICKS == 0)

        async with _LOCAL_LOCK, session_factory() as db:
            got_lock = False
            try:
                got_lock = await _try_acquire_advisory_lock(db)
                if not got_lock:
                    logger.info(
                        "check_ton_inbox: skip; advisory lock held",
                    )
                    continue

                try:
                    res = await asyncio.wait_for(
                        run_tick(db, do_reconcile=do_reconcile),
                        timeout=TASK_TIMEOUT_SEC,
                    )
                    logger.info(
                        "check_ton_inbox: ok in %.2fs "
                        "(stats=%s, reconcile=%s)",
                        res.duration_sec,
                        res.stats,
                        "yes" if do_reconcile else "no",
                    )
                except TimeoutError:
                    msg = f"tick timeout > {TASK_TIMEOUT_SEC}s"
                    logger.warning("check_ton_inbox: %s", msg)
                    await _insert_scheduler_log(
                        db,
                        status="timeout_error",
                        error_text=msg,
                        duration_sec=float(TASK_TIMEOUT_SEC),
                        stats={},
                    )

            finally:
                if got_lock:
                    await _release_advisory_lock(db)

        try:
            await asyncio.sleep(INTERVAL_SEC)
        except asyncio.CancelledError:
            logger.info("check_ton_inbox: cancelled; stopping loop")
            break