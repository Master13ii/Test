# backend/app/scheduler/scheduler_core.py
# ----------------------------------------------------------------------
# Назначение кода:
# Совместимый façade для планировщика: registry + единый tick.
# Фактическая оркестрация выполняется в
# backend/app/services/scheduler_service.py.
# ----------------------------------------------------------------------

from __future__ import annotations

from app.services.scheduler_service import SchedulerService


async def tick() -> None:
    """Запустить один тик (10-минутный будильник)."""
    await SchedulerService().run_single_tick()
