# backend/app/contracts/lotteries_contract.py
# ======================================================================
# SSOT контракт подсистемы lotteries: routes ↔ services.
# ======================================================================

from __future__ import annotations

from typing import Any, Protocol

from sqlalchemy.ext.asyncio import AsyncSession


class LotteriesContract(Protocol):
    """Контракт сервисного слоя lotteries.

    Инварианты:
      • Cursor SSOT: cursor payload всегда dict.
      • Публичный слой: tg_id only.
    """

    async def list_active_lotteries(
        self,
        db: AsyncSession,
        *,
        limit: int,
        cursor: dict[str, Any] | None = None,
    ) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        ...

    async def get_lotteries_status(
        self,
        db: AsyncSession,
        *,
        lotteries_id: int,
    ) -> dict[str, Any] | None:
        ...

    async def list_user_tickets(
        self,
        db: AsyncSession,
        *,
        lotteries_id: int,
        tg_id: int,
        limit: int,
        cursor: dict[str, Any] | None = None,
    ) -> tuple[list[int], dict[str, Any] | None]:
        ...

    async def buy_tickets(
        self,
        db: AsyncSession,
        *,
        lotteries_id: int,
        tg_id: int,
        qty: int,
        idempotency_key: str,
    ) -> dict[str, Any]:
        ...
