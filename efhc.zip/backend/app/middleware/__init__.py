# backend/app/middleware/__init__.py

"""Middleware package (канон EFHC Bot)."""


__all__ = []
