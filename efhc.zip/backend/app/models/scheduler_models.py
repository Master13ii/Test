"""backend/app/models/scheduler_models.py

Канон:
- Все ORM-таблицы живут в efhc_core (DB_SCHEMA_CORE).
- Миграция 0001 поднимает таблицы строго из Base.metadata.

Эта модель нужна, потому что /sync/user/{tg_id} ставит фолбэк-задачу
на догон генерации (scheduler_task_log). Таблица обязана быть в ORM,
чтобы не было runtime-DDL и рассинхрона с миграциями.
"""

from __future__ import annotations

from app.core.config_core import get_settings
from app.models import Base
from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Index,
    Integer,
    String,
    Text,
    func,
)

_settings = get_settings()
CORE_SCHEMA = getattr(_settings, "DB_SCHEMA_CORE", "efhc_core")


class SchedulerTaskLog(Base):
    __tablename__ = "scheduler_task_log"
    __table_args__ = (
        Index(
            "ix_scheduler_task_log_status_retry_time",
            "status",
            "retry_time",
        ),
        {"schema": CORE_SCHEMA},
    )

    id = Column(Integer, primary_key=True)
    task_name = Column(String(128), nullable=False)
    status = Column(String(32), nullable=False)
    error_text = Column(Text, nullable=True)
    payload = Column(JSON, nullable=True)

    retry_time = Column(DateTime(timezone=True), nullable=True)
    executed_at = Column(DateTime(timezone=True), nullable=True)
    duration_sec = Column(Integer, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
