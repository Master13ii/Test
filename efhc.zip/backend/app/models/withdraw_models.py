# backend/app/models/withdraw_models.py
# =====================================================================
# Назначение кода:
# ORM-модели заявок на вывод EFHC.
# Канон:
# • Выводы — деньги → через transactions_service.py.
# • Уникальность по idempotency_key.
# =====================================================================

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy import (
    BigInteger,
    DateTime,
    ForeignKey,
    Numeric,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from ..core.config_core import get_settings
from ..core.sql_aliases_core import canon_schema
from . import Base

settings = get_settings()
SCHEMA: str = getattr(settings, "DB_SCHEMA_CORE", "efhc_core")


class WithdrawRequest(Base):
    """Каноничная заявка на вывод EFHC.

    Источник истины: {SCHEMA}.withdraw_requests.

    Важно:
      • idempotency_key хранит Idempotency-Key заявки.
      • Служебные поля: hold/refund/payout/tx/processed/error.
    """

    __tablename__ = "withdraw_requests"
    __table_args__ = {"schema": SCHEMA}

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    tg_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{SCHEMA}.users.tg_id",
            ondelete="CASCADE",
        ),
        nullable=False,
    )

    amount: Mapped[object] = mapped_column(
        Numeric(20, 8),
        nullable=False,
    )
    status: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        server_default="PENDING",
    )

    idempotency_key: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
        unique=True,
    )

    hold_done: Mapped[bool] = mapped_column(
        sa.Boolean,
        nullable=False,
        server_default=sa.text("false"),
    )
    refund_done: Mapped[bool] = mapped_column(
        sa.Boolean,
        nullable=False,
        server_default=sa.text("false"),
    )

    payout_ref: Mapped[object] = mapped_column(
        String(128),
        nullable=True,
    )

    tx_hash: Mapped[object] = mapped_column(String(128), nullable=True)
    processed_at: Mapped[object] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    error_message: Mapped[object] = mapped_column(
        sa.Text,
        nullable=True,
    )

    created_at: Mapped[object] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[object] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class Withdrawal(Base):
    """DEPRECATED: для старых окружений.

    Ранее таблица называлась withdrawals.
    Канонично теперь: withdraw_requests.
    Не используйте этот класс в новом коде.
    """

    __tablename__ = "withdrawals"
    __table_args__ = {"schema": SCHEMA}

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    tg_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey(
            f"{SCHEMA}.users.tg_id",
            ondelete="CASCADE",
        ),
        nullable=False,
    )
    amount_efhc: Mapped[object] = mapped_column(
        Numeric(20, 8),
        nullable=False,
    )
    status: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        server_default="requested",
    )
    idempotency_key: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
    )
    created_at: Mapped[object] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

