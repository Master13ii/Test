"""Wallet models (TonConnect bindings).

SSOT:
- User identifier is tg_id only.
- Wallet connected := at least one active wallet binding.

Notes:
- We keep this model separate from legacy user.ton_wallet.
"""

from __future__ import annotations

from datetime import datetime

from app.core.config_core import get_settings
from app.core.sql_aliases_core import canon_schema
from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from . import Base, TimestampMixin

settings = get_settings()
SCHEMA = canon_schema(
    getattr(settings, "DB_SCHEMA_CORE", "efhc_core"),
)


class WalletBinding(Base, TimestampMixin):
    """TON wallet binding for a Telegram user (tg_id)."""

    __tablename__ = "wallet_bindings"

    __table_args__ = ({"schema": SCHEMA},)

    id: Mapped[int] = mapped_column(primary_key=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, index=True)
    wallet_address: Mapped[str] = mapped_column(Text, unique=True)
    wallet_app: Mapped[str | None] = mapped_column(String(32))

    is_primary: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default="true",
    )

    # created_at/updated_at — из TimestampMixin


class WalletConnectIdempotency(Base):
    """Идемпотентность привязки кошелька (TonConnect).

    Требуется кодом wallets_service.connect_wallet().
    Канон: таблица должна быть ORM и создаваться через 0001.
    """

    __tablename__ = "wallet_connect_idempotency"
    __table_args__ = (
        UniqueConstraint(
            "tg_id",
            "idempotency_key",
            name="uq_wallet_connect_idk",
        ),
        {"schema": SCHEMA},
    )

    tg_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(Text, primary_key=True)
    wallet_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    wallet_address: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("timezone('utc', now())"),
    )
